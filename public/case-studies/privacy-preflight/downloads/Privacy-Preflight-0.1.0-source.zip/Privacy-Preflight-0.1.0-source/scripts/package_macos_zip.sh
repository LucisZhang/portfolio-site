#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
APP_PATH="$("$ROOT_DIR/scripts/build_macos_app.sh" | tail -n 1)"
ZIP_PATH="$ROOT_DIR/apps/macos/build/Privacy-Preflight-0.1.0-macOS-arm64-unnotarized.zip"
STAGE_DIR="$(mktemp -d "${TMPDIR:-/tmp}/privacy-preflight-zip.XXXXXX")"
STAGED_APP_PATH="$STAGE_DIR/$(basename "$APP_PATH")"

cleanup() {
    rm -rf "$STAGE_DIR"
}
trap cleanup EXIT

rm -f "$ZIP_PATH"
COPYFILE_DISABLE=1 ditto --norsrc --noextattr "$APP_PATH" "$STAGED_APP_PATH"
find "$STAGED_APP_PATH" \
    \( -name '._*' -o -name '__MACOSX' -o -name '.DS_Store' \) \
    -prune -exec rm -rf {} +
COPYFILE_DISABLE=1 ditto -c -k --norsrc --noextattr --keepParent "$STAGED_APP_PATH" "$ZIP_PATH"
echo "$ZIP_PATH"
