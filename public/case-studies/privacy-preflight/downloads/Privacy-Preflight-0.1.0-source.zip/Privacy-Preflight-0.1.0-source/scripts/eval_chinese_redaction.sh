#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WORKER_DIR="$ROOT_DIR/services/worker"

if [[ -n "${PYTHON:-}" ]]; then
    PYTHON_BIN="$PYTHON"
elif [[ -x "$WORKER_DIR/.venv/bin/python" ]]; then
    PYTHON_BIN="$WORKER_DIR/.venv/bin/python"
else
    PYTHON_BIN="python3"
fi

cd "$WORKER_DIR"
"$PYTHON_BIN" -m pytest tests/test_chinese_redaction.py::test_chinese_evaluation_fixtures -q
echo "Chinese redaction evaluation fixtures passed."
