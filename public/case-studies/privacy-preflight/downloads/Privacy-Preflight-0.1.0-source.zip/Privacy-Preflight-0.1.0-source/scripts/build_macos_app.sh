#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MACOS_DIR="$ROOT_DIR/apps/macos"
BUILD_DIR="$MACOS_DIR/build"
APP_NAME="Privacy Preflight"
PRODUCT_NAME="PrivacyPreflightApp"
APP_BUNDLE="$BUILD_DIR/$APP_NAME.app"
CONTENTS_DIR="$APP_BUNDLE/Contents"
MACOS_CONTENTS_DIR="$CONTENTS_DIR/MacOS"
RESOURCES_DIR="$CONTENTS_DIR/Resources"
BUNDLED_PYTHON_ROOT="${BUNDLED_PYTHON_ROOT:-}"

if [[ -z "${DEVELOPER_DIR:-}" && -d "/Applications/Xcode.app/Contents/Developer" ]]; then
    export DEVELOPER_DIR="/Applications/Xcode.app/Contents/Developer"
fi
MODULE_CACHE_DIR="$BUILD_DIR/ModuleCache"
mkdir -p "$MODULE_CACHE_DIR"
export CLANG_MODULE_CACHE_PATH="$MODULE_CACHE_DIR"

if [[ -z "$BUNDLED_PYTHON_ROOT" || ! -x "$BUNDLED_PYTHON_ROOT/bin/python3" ]]; then
    echo "BUNDLED_PYTHON_ROOT must point to a relocatable Python tree with bin/python3." >&2
    exit 2
fi

cd "$MACOS_DIR"
swift build -c release --product "$PRODUCT_NAME" --jobs 1 -Xswiftc -gnone
BIN_DIR="$(swift build -c release --show-bin-path --jobs 1)"

rm -rf "$APP_BUNDLE"
mkdir -p "$MACOS_CONTENTS_DIR" "$RESOURCES_DIR"

cp "$BIN_DIR/$PRODUCT_NAME" "$MACOS_CONTENTS_DIR/$PRODUCT_NAME"
# Defense in depth: remove any remaining debug-map source paths before the
# public bundle is signed. Runtime and local non-debug symbols remain intact.
strip -S "$MACOS_CONTENTS_DIR/$PRODUCT_NAME"
cp "$MACOS_DIR/Info.plist" "$CONTENTS_DIR/Info.plist"
cp "$MACOS_DIR/Resources/AppIcon.svg" "$RESOURCES_DIR/AppIcon.svg"

ICONSET_DIR="$BUILD_DIR/AppIcon.iconset"
rm -rf "$ICONSET_DIR"
swift "$ROOT_DIR/scripts/generate_app_icon.swift" "$ICONSET_DIR"
if command -v iconutil >/dev/null 2>&1; then
    iconutil -c icns "$ICONSET_DIR" -o "$RESOURCES_DIR/AppIcon.icns"
fi

mkdir -p "$RESOURCES_DIR/worker"
rsync -a --delete \
    --exclude ".venv" \
    --exclude ".DS_Store" \
    --exclude "__pycache__" \
    --exclude ".pytest_cache" \
    --exclude "*.egg-info" \
    --exclude "tests" \
    "$ROOT_DIR/services/worker/" "$RESOURCES_DIR/worker/"

xcrun swiftc -O \
    -module-cache-path "$MODULE_CACHE_DIR" \
    -framework AppKit \
    -framework Foundation \
    -framework Vision \
    "$ROOT_DIR/services/worker/app/image_ocr_vision.swift" \
    -o "$MACOS_CONTENTS_DIR/image_ocr_vision"

rsync -a --delete \
    --exclude "__pycache__" \
    --exclude "*.pyc" \
    --exclude "lib/python3.12/ensurepip" \
    --exclude "lib/python3.12/idlelib" \
    --exclude "lib/python3.12/tkinter" \
    --exclude "lib/python3.12/turtledemo" \
    --exclude "lib/python3.12/lib-dynload/_tkinter*" \
    --exclude "lib/python3.12/site-packages/pip" \
    --exclude "lib/python3.12/site-packages/pip-*.dist-info" \
    --exclude "lib/tcl*" \
    --exclude "lib/tk*" \
    --exclude "lib/thread*" \
    --exclude "lib/itcl*" \
    --exclude "lib/libtcl*" \
    "$BUNDLED_PYTHON_ROOT/" "$RESOURCES_DIR/python/"

find "$RESOURCES_DIR/python/bin" -mindepth 1 -maxdepth 1 \
    ! -name "python3.12" ! -name "python3" ! -name "python" -delete

# Editable-install provenance points at the build machine and is not required
# to import or run the bundled worker. Keep wheel metadata internally
# consistent by removing its RECORD entry as well.
WORKER_DIST_INFO="$RESOURCES_DIR/python/lib/python3.12/site-packages/privacy_preflight_worker-0.1.0.dist-info"
rm -f "$WORKER_DIST_INFO/direct_url.json"
if [[ -f "$WORKER_DIST_INFO/RECORD" ]]; then
    sed -i '' '/^privacy_preflight_worker-0\.1\.0\.dist-info\/direct_url\.json,/d' "$WORKER_DIST_INFO/RECORD"
fi

# Only native code needs an executable bit in the embedded runtime. Console-
# script wrappers and Python sources remain readable but are not treated as
# unsigned nested executables by Gatekeeper/codesign.
find "$RESOURCES_DIR/python" -type f -print0 | while IFS= read -r -d '' candidate; do
    if ! file "$candidate" | grep -q "Mach-O"; then
        if [[ "$(head -c 2 "$candidate" 2>/dev/null || true)" == "#!" ]]; then
            sed -i '' '1s/^#!/# /' "$candidate"
        fi
        chmod a-x "$candidate"
    fi
done

mkdir -p "$RESOURCES_DIR/Release Notes"
cp "$ROOT_DIR/release/README.md" "$RESOURCES_DIR/Release Notes/README.md"
cp "$ROOT_DIR/release/PRIVACY.md" "$RESOURCES_DIR/Release Notes/PRIVACY.md"
cp "$ROOT_DIR/release/THIRD_PARTY_NOTICES.md" "$RESOURCES_DIR/Release Notes/THIRD_PARTY_NOTICES.md"
cp "$ROOT_DIR/release/DEPENDENCIES.lock" "$RESOURCES_DIR/Release Notes/DEPENDENCIES.lock"
cp "$BUNDLED_PYTHON_ROOT/lib/python3.12/LICENSE.txt" "$RESOURCES_DIR/Release Notes/CPython-LICENSE.txt"

# The release target is Apple silicon only. Some dependency wheels are universal;
# keep their arm64 slice so the distributed runtime has one explicit architecture.
find "$APP_BUNDLE" -type f -print0 | while IFS= read -r -d '' candidate; do
    if file "$candidate" | grep -q "Mach-O universal binary" && lipo "$candidate" -verify_arch arm64 >/dev/null 2>&1; then
        thinned="$candidate.arm64"
        lipo "$candidate" -thin arm64 -output "$thinned"
        chmod --reference="$candidate" "$thinned" 2>/dev/null || chmod 755 "$thinned"
        mv "$thinned" "$candidate"
    fi
done

find "$APP_BUNDLE" -type f -print0 | while IFS= read -r -d '' candidate; do
    if file "$candidate" | grep -q "Mach-O"; then
        codesign --force --sign - "$candidate"
    fi
done

if [[ -n "${SIGN_IDENTITY:-}" ]]; then
    codesign --force --timestamp --options runtime --sign "$SIGN_IDENTITY" "$APP_BUNDLE"
else
    codesign --force --deep --sign - "$APP_BUNDLE"
    echo "Applied ad-hoc signatures. This build is not Developer ID signed or notarized."
fi

echo "$APP_BUNDLE"
