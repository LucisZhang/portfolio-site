#!/usr/bin/env bash
set -euo pipefail

# QA/dev only: run the SwiftUI app with an explicit non-default worker endpoint.
# This avoids LaunchServices reusing an app launch without the targeted QA env.
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
APP_EXECUTABLE="$ROOT_DIR/apps/macos/build/Privacy Preflight.app/Contents/MacOS/PrivacyPreflightApp"

export PRIVACY_PREFLIGHT_WORKER_PORT="${PRIVACY_PREFLIGHT_WORKER_PORT:-8891}"
QA_TMP_ROOT="${TMPDIR:-/tmp}"
export PRIVACY_PREFLIGHT_APP_DATA_DIR="${PRIVACY_PREFLIGHT_APP_DATA_DIR:-$QA_TMP_ROOT/privacy-preflight-targeted-qa}"

if [[ -x "$APP_EXECUTABLE" ]]; then
    exec "$APP_EXECUTABLE"
fi

cd "$ROOT_DIR/apps/macos"
exec swift run PrivacyPreflightApp
