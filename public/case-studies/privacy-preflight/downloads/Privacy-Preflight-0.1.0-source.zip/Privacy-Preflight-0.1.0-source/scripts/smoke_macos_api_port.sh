#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WORKER_DIR="${PRIVACY_PREFLIGHT_WORKER_DIR:-$ROOT_DIR/services/worker}"
PORT="${PRIVACY_PREFLIGHT_WORKER_PORT:-8891}"
APP_DATA_DIR="$(mktemp -d "${TMPDIR:-/tmp}/privacy-preflight-smoke-data.XXXXXX")"
BUILD_DIR="$(mktemp -d "${TMPDIR:-/tmp}/privacy-preflight-smoke-build.XXXXXX")"
HARNESS="$BUILD_DIR/SmokeAPIClientPort.swift"
HARNESS_BIN="$BUILD_DIR/smoke-api-client-port"
WORKER_PID=""

cleanup() {
    if [[ -n "$WORKER_PID" ]] && kill -0 "$WORKER_PID" 2>/dev/null; then
        kill "$WORKER_PID" 2>/dev/null || true
        wait "$WORKER_PID" 2>/dev/null || true
    fi
    rm -rf "$APP_DATA_DIR" "$BUILD_DIR"
}
trap cleanup EXIT

if [[ -n "${PRIVACY_PREFLIGHT_WORKER_PYTHON:-}" ]]; then
    PYTHON="$PRIVACY_PREFLIGHT_WORKER_PYTHON"
elif [[ -x "$WORKER_DIR/.venv/bin/python" ]]; then
    PYTHON="$WORKER_DIR/.venv/bin/python"
else
    PYTHON="python3"
fi

PRIVACY_PREFLIGHT_WORKER_PORT="$PORT" \
PRIVACY_PREFLIGHT_WORKER_BIND_HOST="127.0.0.1" \
PRIVACY_PREFLIGHT_APP_DATA_DIR="$APP_DATA_DIR" \
"$PYTHON" -m uvicorn app.main:app \
    --host 127.0.0.1 \
    --port "$PORT" \
    --log-level warning \
    --no-access-log \
    --app-dir "$WORKER_DIR" &
WORKER_PID="$!"

for _ in {1..40}; do
    if curl -fsS "http://127.0.0.1:$PORT/health" >/dev/null 2>&1; then
        break
    fi
    sleep 0.25
done

curl -fsS "http://127.0.0.1:$PORT/health" >/dev/null

cat > "$HARNESS" <<'SWIFT'
import Foundation

@main
struct SmokeAPIClientPort {
    static func main() async {
        let client = PrivacyPreflightAPIClient()
        guard client.baseURL.host == WorkerEndpoint.loopbackHost,
              client.baseURL.port == 8891
        else {
            fputs("API client base URL was \(client.baseURL.absoluteString), expected http://127.0.0.1:8891\n", stderr)
            exit(2)
        }

        do {
            let health = try await client.checkHealth()
            guard health.status.lowercased() == "ok" else {
                fputs("Unexpected health status: \(health.status)\n", stderr)
                exit(3)
            }

            let redaction = try await client.redactText("Contact qa-port-smoke@example.com", mode: .balanced)
            guard redaction.redactedText.contains("[EMAIL]") else {
                fputs("Redaction endpoint did not mask the synthetic email sample.\n", stderr)
                exit(4)
            }

            _ = try await client.fetchProfile()
        } catch {
            fputs("API smoke failed: \(error.localizedDescription)\n", stderr)
            exit(5)
        }
    }
}
SWIFT

PRIVACY_PREFLIGHT_WORKER_PORT="$PORT" swiftc \
    "$ROOT_DIR/apps/macos/Sources/PrivacyPreflightApp/WorkerLifecycleManager.swift" \
    "$ROOT_DIR/apps/macos/Sources/PrivacyPreflightApp/PrivacyPreflightAPI.swift" \
    "$HARNESS" \
    -o "$HARNESS_BIN"

PRIVACY_PREFLIGHT_WORKER_PORT="$PORT" "$HARNESS_BIN"
echo "Swift API client used http://127.0.0.1:$PORT and redaction/profile smoke passed."
