#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WORKER_DIR="$ROOT_DIR/services/worker"
PORT="${PORT:-8765}"

if [[ -n "${PYTHON:-}" ]]; then
    PYTHON_BIN="$PYTHON"
elif [[ -x "$WORKER_DIR/.venv/bin/python" ]]; then
    PYTHON_BIN="$WORKER_DIR/.venv/bin/python"
else
    PYTHON_BIN="python3"
fi

cd "$WORKER_DIR"
exec "$PYTHON_BIN" -m uvicorn app.main:app --host 127.0.0.1 --port "$PORT" --reload
