import AppKit
import Foundation

let arguments = CommandLine.arguments
guard arguments.count == 2 else {
    FileHandle.standardError.write(Data("usage: generate_app_icon.swift <iconset-dir>\n".utf8))
    exit(2)
}

let outputURL = URL(fileURLWithPath: arguments[1], isDirectory: true)
let fileManager = FileManager.default
try fileManager.createDirectory(at: outputURL, withIntermediateDirectories: true)

let sizes: [(name: String, points: CGFloat, scale: CGFloat)] = [
    ("icon_16x16.png", 16, 1),
    ("icon_16x16@2x.png", 16, 2),
    ("icon_32x32.png", 32, 1),
    ("icon_32x32@2x.png", 32, 2),
    ("icon_128x128.png", 128, 1),
    ("icon_128x128@2x.png", 128, 2),
    ("icon_256x256.png", 256, 1),
    ("icon_256x256@2x.png", 256, 2),
    ("icon_512x512.png", 512, 1),
    ("icon_512x512@2x.png", 512, 2),
]

for size in sizes {
    let pixels = Int(size.points * size.scale)
    let image = NSImage(size: NSSize(width: pixels, height: pixels))
    image.lockFocus()

    let bounds = NSRect(x: 0, y: 0, width: pixels, height: pixels)
    NSColor(calibratedRed: 0.12, green: 0.44, blue: 0.92, alpha: 1).setFill()
    NSBezierPath(roundedRect: bounds, xRadius: CGFloat(pixels) * 0.22, yRadius: CGFloat(pixels) * 0.22).fill()

    let documentRect = NSRect(
        x: CGFloat(pixels) * 0.22,
        y: CGFloat(pixels) * 0.21,
        width: CGFloat(pixels) * 0.56,
        height: CGFloat(pixels) * 0.60
    )
    NSColor(calibratedWhite: 0.98, alpha: 1).setFill()
    NSBezierPath(roundedRect: documentRect, xRadius: CGFloat(pixels) * 0.08, yRadius: CGFloat(pixels) * 0.08).fill()

    NSColor(calibratedRed: 0.12, green: 0.44, blue: 0.92, alpha: 1).setFill()
    NSBezierPath(rect: NSRect(
        x: CGFloat(pixels) * 0.31,
        y: CGFloat(pixels) * 0.54,
        width: CGFloat(pixels) * 0.38,
        height: max(2, CGFloat(pixels) * 0.07)
    )).fill()
    NSBezierPath(rect: NSRect(
        x: CGFloat(pixels) * 0.31,
        y: CGFloat(pixels) * 0.40,
        width: CGFloat(pixels) * 0.25,
        height: max(2, CGFloat(pixels) * 0.07)
    )).fill()

    NSColor(calibratedWhite: 0.07, alpha: 1).setFill()
    let shieldRect = NSRect(
        x: CGFloat(pixels) * 0.54,
        y: CGFloat(pixels) * 0.16,
        width: CGFloat(pixels) * 0.27,
        height: CGFloat(pixels) * 0.27
    )
    NSBezierPath(ovalIn: shieldRect).fill()

    image.unlockFocus()

    guard let tiffData = image.tiffRepresentation,
          let bitmap = NSBitmapImageRep(data: tiffData),
          let pngData = bitmap.representation(using: .png, properties: [:])
    else {
        FileHandle.standardError.write(Data("failed to render \(size.name)\n".utf8))
        exit(1)
    }

    try pngData.write(to: outputURL.appendingPathComponent(size.name), options: .atomic)
}
