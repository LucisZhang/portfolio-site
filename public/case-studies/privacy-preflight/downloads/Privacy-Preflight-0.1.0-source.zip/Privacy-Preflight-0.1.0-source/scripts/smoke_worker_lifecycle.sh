#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WORKER_DIR="$ROOT_DIR/services/worker"
PORT="${PORT:-8876}"

if [[ -n "${PYTHON:-}" ]]; then
    PYTHON_BIN="$PYTHON"
elif [[ -x "$WORKER_DIR/.venv/bin/python" ]]; then
    PYTHON_BIN="$WORKER_DIR/.venv/bin/python"
else
    PYTHON_BIN="python3"
fi

cd "$WORKER_DIR"
"$PYTHON_BIN" -m uvicorn app.main:app --host 127.0.0.1 --port "$PORT" --log-level warning --no-access-log >/tmp/privacy-preflight-worker-smoke.log 2>&1 &
WORKER_PID="$!"

cleanup() {
    kill "$WORKER_PID" >/dev/null 2>&1 || true
    wait "$WORKER_PID" >/dev/null 2>&1 || true
}
trap cleanup EXIT

"$PYTHON_BIN" - "$PORT" <<'PY'
import json
import sys
import time
import urllib.request

port = int(sys.argv[1])
url = f"http://127.0.0.1:{port}/health"
for _ in range(40):
    try:
        with urllib.request.urlopen(url, timeout=1) as response:
            payload = json.loads(response.read().decode("utf-8"))
        if payload == {"status": "ok"}:
            break
    except Exception:
        time.sleep(0.25)
else:
    raise SystemExit("worker health check did not pass")
PY

if command -v lsof >/dev/null 2>&1; then
    LISTENERS="$(lsof -nP -iTCP:"$PORT" -sTCP:LISTEN)"
    echo "$LISTENERS" | grep -q "127.0.0.1:$PORT"
    if echo "$LISTENERS" | grep -Eq "TCP (\\*|0\\.0\\.0\\.0):$PORT"; then
        echo "worker is not loopback-only" >&2
        exit 1
    fi
fi

kill "$WORKER_PID"
wait "$WORKER_PID" >/dev/null 2>&1 || true
trap - EXIT
echo "worker lifecycle smoke passed on 127.0.0.1:$PORT"
