# Privacy Preflight

Privacy Preflight is a local-first macOS privacy redaction app. Its goal is to help people remove sensitive information from text, images, and PDFs before sending content to external AI tools.

This repository currently contains SwiftUI macOS text, image, and PDF redaction workspaces and a local Python FastAPI worker. The worker includes deterministic text redaction, PNG/JPEG OCR-region image redaction, destructive PDF redaction export, a Chinese/mixed-language local detector layer, optional OpenAI Privacy Filter detection, and optional Microsoft Presidio detection.

## Local-first principle

Raw user content should stay on the Mac by default. Local detection, redaction engines, and local review models may process raw content. External/generic model providers receive redacted-only review input by default; sending original text to an external provider requires explicit opt-in.

The worker should not log raw submitted content, and the app should not store raw user content in history by default.

## Architecture

- `apps/macos/` contains the SwiftUI macOS frontend.
- `services/worker/` contains the local FastAPI worker.
- `docs/` contains architecture notes and reference findings.
- `scripts/` contains developer helper scripts.
- `tests/` is reserved for future cross-component tests.

The planned production flow is:

1. User provides text, image, or PDF content in the Mac app.
2. The app sends content to a local worker on `127.0.0.1`.
3. The worker detects candidate sensitive spans locally.
4. The app shows a reviewable preview.
5. The worker exports sanitized output.
6. Optional model review receives original text only for local providers; non-local providers receive redacted-only review input by default.

## Current status

Implemented:

- `GET /health` returns `{"status": "ok"}`.
- `POST /redact/text` performs deterministic local regex redaction for common text patterns.
- `GET /profile`, `PUT /profile`, `POST /profile/rules`, `PUT /profile/rules/{id}`, and `DELETE /profile/rules/{id}` manage local profile rules.
- `POST /profile/learn-from-text` runs local detectors against pasted sample text and returns candidate profile rules without saving them.
- `GET /models/providers`, `POST /models/providers`, `PUT /models/providers/{id}`, `DELETE /models/providers/{id}`, and `POST /models/providers/{id}/test` manage local model provider settings.
- `GET /models/settings` and `PUT /models/settings` manage optional review model selection and the external raw-text opt-in flag.
- `POST /redact/text/review` runs redaction, optionally asks a configured model for structured JSON review suggestions, and returns the initial result, review result, and final result.
- `POST /redact/image` accepts PNG/JPEG files, runs local OCR, returns OCR/redaction boxes, and returns a PNG/JPEG with redaction pixels burned in.
- `POST /redact/pdf/analyze` accepts PDF files, extracts local text/OCR regions, returns page previews, and returns detected redaction regions.
- `POST /redact/pdf/export` accepts PDF files and optional manual page rectangles, rebuilds a destructive image-only redacted PDF, validates that redacted strings are not extractable, and returns validation metadata.
- `POST /revision/parse` and `POST /redact/text/revise` convert natural-language revision instructions into structured commands, then apply them deterministically to the current document or the local profile.
- `GET /gateway/settings`, `PUT /gateway/settings`, `POST /gateway/preview`, `POST /v1/chat/completions`, and `GET /v1/models` provide an optional local OpenAI-compatible preflight gateway.
- `GET /privacy/local-data`, `GET /privacy/diagnostics`, and `POST /privacy/clear-local-data` expose sanitized local maintenance controls.
- Chinese and mixed-language dictionary/address detectors redact a small set of public school aliases and obvious Chinese address spans locally.
- Configurable local dictionary files can add Chinese and mixed-language terms without a heavy NER model.
- Profile rules can always mask, ask for review, or allow specific local terms without storing submitted documents, sample text, or redaction history.
- The macOS image workspace accepts drag/drop or chosen PNG/JPEG files, previews OCR/redaction boxes, supports safe and precise text-region modes, supports simple manual rectangles, and exports the returned redacted image without overwriting the original by default.
- The macOS Profile sheet can learn candidate rules from sample text and save selected candidates explicitly.
- Optional OpenAI Privacy Filter integration can run as an additional local detector source when explicitly enabled and installed locally.
- Optional Presidio Analyzer integration can run as an additional local detector source when explicitly enabled.
- Optional HanLP adapter wiring exists for future local Chinese NER model use.
- Optional LLM review and revision parsing support Ollama, LM Studio through the OpenAI-compatible path, and one generic OpenAI-compatible provider path. Model output can add exact-match missed items or revision commands to the final redaction result, but does not free-form rewrite the text.
- The optional gateway accepts non-streaming OpenAI-compatible chat-completions requests, redacts text messages locally, and forwards through the configured OpenAI-compatible upstream provider.
- The macOS app starts, stops, restarts, and health-checks the local worker in development/dev-bundle mode, and shows the endpoint, last health check, and sanitized latest error.
- A standalone arm64 `.app` bundle can be built at `apps/macos/build/Privacy Preflight.app` with `BUNDLED_PYTHON_ROOT=/path/to/relocatable/python scripts/build_macos_app.sh`.
- Text redaction returns `redacted_text`, structured `entities`, and summary counts by entity type.
- Backend tests cover core regex detectors, local dictionary rules, Chinese fixture evaluation, Privacy Filter adapter mapping, Presidio candidate mapping, conflict-safe replacement, disabling optional detectors, strict mode, provider config storage, review JSON parsing, revision command parsing/application, local/external raw-text rules, API-key non-disclosure, review suggestion application, and gateway privacy red lines.
- SwiftUI text workspace calls the local worker, shows redacted output, accepts natural-language revision commands, highlights detected source spans, summarizes detected entity counts, lists detected spans with type/source/replacement/confidence, shows an entity inspector, can copy redacted text, includes Profile settings for add/edit/delete/enable/disable, sample learning, quick rule capture from a selected result entity, includes Model settings for provider management plus optional LLM review, and includes Gateway settings with dry-run preview.

Not implemented yet:

- Clipboard shortcuts, global hotkeys, or menu bar actions.
- Developer ID signing, notarization, and verified sandboxed distribution. The 0.1.0 preview is ad-hoc signed and intentionally described as unnotarized.
- Model comparison workspace, provider marketplace, routing layer, system-wide proxy, browser extension, OpenRouter-specific client, DashScope-specific client, or Gemini-specific client.

## Backend setup

From the repository root:

```bash
cd services/worker
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -e ".[dev]"
```

To enable optional local Presidio detection, install the Presidio extra and a compatible local NLP model:

```bash
python -m pip install -e ".[dev,presidio]"
export PRIVACY_PREFLIGHT_ENABLE_PRESIDIO=1
```

The default Chinese detector has no heavy dependency. Optional HanLP adapter setup uses:

```bash
python -m pip install -e ".[dev,chinese-ner]"
export PRIVACY_PREFLIGHT_CHINESE_NER_PROVIDER=hanlp
export PRIVACY_PREFLIGHT_CHINESE_NER_MODEL_PATH=/path/to/local/hanlp/model
```

To add local Chinese or mixed-language dictionary terms, create a JSON file and point the worker at it:

```json
{
  "version": 1,
  "rules": [
    {
      "id": "rule_school_bit",
      "label": "BIT",
      "entity_type": "SCHOOL",
      "patterns": ["北京理工大学", "Beijing Institute of Technology"],
      "replacement": "[SCHOOL]",
      "enabled": true,
      "source": "user_dictionary"
    }
  ]
}
```

```bash
export PRIVACY_PREFLIGHT_DICTIONARY_PATH=/path/to/privacy-preflight-dictionary.json
```

The personal redaction profile is stored locally as human-readable JSON. The default macOS path is:

```text
~/Library/Application Support/Privacy Preflight/profile.json
```

For development or tests, override the profile location:

```bash
export PRIVACY_PREFLIGHT_APP_DATA_DIR=/path/to/app-data
export PRIVACY_PREFLIGHT_PROFILE_PATH=/path/to/profile.json
```

Example profile:

```json
{
  "version": 1,
  "rules": [
    {
      "id": "profile_tsinghua_8ad4e391",
      "label": "Tsinghua",
      "entity_type": "SCHOOL",
      "patterns": ["清华大学"],
      "aliases": ["Tsinghua University"],
      "replacement": "[SCHOOL]",
      "action": "mask",
      "enabled": true,
      "scope": "global",
      "created_at": "2026-05-27T12:00:00Z",
      "updated_at": "2026-05-27T12:00:00Z"
    }
  ]
}
```

Profile action semantics:

- `mask`: Always replace matching text with the rule replacement.
- `ask`: Return a reviewable entity with `action = "ask"` while still using the safe replacement in `redacted_text`.
- `allow`: Suppress ordinary overlapping matches, but not high-risk deterministic API-key detections.

The profile stores user-entered rules only. It does not store submitted documents, raw sample text, redaction history, or placeholder-to-original mappings, and it is never sent externally by the worker.

Profile sample learning uses the same local detector stack as text redaction, including regex, optional local OpenAI Privacy Filter, optional local Presidio, Chinese/mixed-language detectors, local dictionary terms, and current profile context. The endpoint returns candidates with a suggested entity type, literal pattern, aliases, replacement, suggested action, detector source, confidence, and reason. It does not mutate the profile; saving a candidate uses `POST /profile/rules`.

To enable optional OpenAI Privacy Filter detection, install the official local runtime separately and point the worker at a local checkpoint:

```bash
git clone https://github.com/openai/privacy-filter.git
cd privacy-filter
python -m pip install -e .
export PRIVACY_PREFLIGHT_ENABLE_PRIVACY_FILTER=1
export PRIVACY_PREFLIGHT_PRIVACY_FILTER_RUNTIME=opf
export PRIVACY_PREFLIGHT_PRIVACY_FILTER_DEVICE=cpu
export PRIVACY_PREFLIGHT_PRIVACY_FILTER_MODEL_PATH=/path/to/privacy_filter/checkpoint
```

Privacy Filter is a detector-layer integration. It returns spans that the worker maps to `source = "privacy_filter"` entities. It is not a chat/review model provider.

## Image redaction backend

The image endpoint is local-only and supports PNG and JPG/JPEG:

```text
POST /redact/image
multipart fields:
  image: file
  mode: safe_text | precise
  manual_rectangles: optional JSON array of {x, y, width, height}
```

Modes:

- `safe_text`: masks every OCR-detected text region.
- `precise`: runs each OCR text box through the existing text redaction pipeline and masks only boxes with detected sensitive text.
- Manual rectangles, when supplied, are always burned into the output pixels.

OCR provider setup:

- Default `PRIVACY_PREFLIGHT_IMAGE_OCR_PROVIDER=auto` uses the macOS Vision bridge on macOS when Swift is available.
- Use `PRIVACY_PREFLIGHT_IMAGE_OCR_PROVIDER=vision` to force macOS Vision.
- Use `PRIVACY_PREFLIGHT_IMAGE_OCR_PROVIDER=tesseract` or `pytesseract` after installing the optional Python extra and a local Tesseract binary.
- Use `PRIVACY_PREFLIGHT_IMAGE_OCR_PROVIDER=none` to disable OCR and return a clear unavailable error.

Optional Tesseract Python adapter setup:

```bash
python -m pip install -e ".[dev,image-ocr]"
# install the local tesseract binary separately, for example with Homebrew:
# brew install tesseract
export PRIVACY_PREFLIGHT_IMAGE_OCR_PROVIDER=tesseract
```

Image export safety:

- The worker decodes the image, draws opaque black rectangles directly into pixel data, and re-encodes the redacted PNG/JPEG.
- Redacted PNG/JPEG outputs are freshly encoded without copying original EXIF, XMP, IPTC, GPS, camera, timestamp, software, thumbnail, comment, or other source metadata.
- The original file is not overwritten by default.
- The worker does not store original images or OCR text in history.
- The Vision bridge uses a temporary local file for OCR and deletes it after processing.
- This phase does not implement external OCR or full-image panic mode. PDF redaction is implemented separately through the local PDF endpoints.

## PDF redaction backend

The PDF endpoints are local-only and support PDF input:

```text
POST /redact/pdf/analyze
multipart fields:
  pdf: file
  mode: balanced | strict

POST /redact/pdf/export
multipart fields:
  pdf: file
  mode: balanced | strict
  manual_rectangles: optional JSON array of {page_index, x, y, width, height}
```

PDF export safety:

- The worker uses pypdfium2/PDFium to render pages and map text coordinates, pypdf to inspect PDF structure, Pillow to burn opaque pixels, and ReportLab to rebuild image-only output.
- The existing text redaction pipeline runs on extracted PDF text and OCR text boxes.
- Scanned or image-containing pages require local OCR through the existing macOS Vision or Tesseract provider path. If OCR is required but unavailable, the worker fails closed.
- The final exported PDF is rebuilt as image-only pages after redaction rectangles are burned into page pixels. It does not rely on removable black rectangle overlays.
- The worker strips metadata on the rebuilt PDF and does not preserve source annotations, forms, embedded files, or the original text layer.
- After export, the worker extracts text from the output PDF, verifies known redacted strings are absent, verifies no text layer remains, and checks that redaction annotations were not left unapplied.
- The original PDF is not overwritten by the worker or app by default.
- This is not legal-grade redaction. See `docs/pdf-redaction.md` for limitations and validation details.

PDF dependency setup:

```bash
cd services/worker
python -m pip install -e ".[dev]"
```

## Model providers and review

The model provider layer is optional and disabled by default. The supported provider types are intentionally narrow:

- Ollama: use `provider_type: "ollama"`, usually `base_url: "http://127.0.0.1:11434"`, and the local Ollama model name.
- LM Studio: use `provider_type: "lm_studio"`, usually `base_url: "http://127.0.0.1:1234/v1"`, and the loaded LM Studio model identifier.
- Generic OpenAI-compatible: use `provider_type: "openai_compatible"`, the compatible `/v1` base URL, model name, and optional API key.

Provider metadata is stored locally at:

```text
~/Library/Application Support/Privacy Preflight/model_providers.json
```

API keys are not written to that JSON. On macOS, the worker stores provider API keys in Keychain under the provider id and only returns `api_key_configured` to the UI.

The review prompt requires structured JSON:

```json
{
  "pass": true,
  "risk_level": "low",
  "missed_items": [],
  "false_positives": [],
  "suggested_policy_updates": []
}
```

Model review never free-form rewrites the full text. The worker only applies valid missed-item suggestions when the suggested text appears as an exact local match, then re-runs deterministic conflict resolution. False positives and policy updates are returned for review but are not auto-applied.

Natural-language revision uses the same provider settings when model parsing is enabled, but the model may only return validated `RevisionCommand` JSON. Without a model, deterministic fallback supports commands such as `mask <text>`, `mask <text> as <label>`, `allow <text>`, `ask <text>`, `replace <text> with <label>`, and `add <text> to profile as <label>`. Current-document commands create transient revision candidates; profile-scope commands save local profile rules.

Privacy behavior:

- Providers marked `is_local: true` may receive original text for review.
- Providers marked `is_local: false` receive redacted-only review input by default.
- `allow_raw_text_for_external_models` defaults to false. Setting it true is an explicit opt-in to send original text to an external/generic provider, and the review result includes a warning.
- External revision parsing is skipped by default because the instruction itself can contain raw sensitive text. It uses deterministic fallback unless raw sharing is explicitly enabled.
- API keys are not included in API responses, test output, worker diagnostics, or UI error details.

## Local OpenAI-compatible preflight gateway

The gateway is optional and disabled by default. It lets compatible clients point at Privacy Preflight first, using the local endpoint shown in the Gateway settings sheet:

```text
http://127.0.0.1:8765/v1
```

Gateway settings are stored in the local model provider JSON. Defaults are:

```json
{
  "enabled": false,
  "bind_host": "127.0.0.1",
  "port": 8765,
  "upstream_provider_id": null,
  "allow_raw_text_to_upstream": false,
  "redact_request_messages": true
}
```

Configure an upstream OpenAI-compatible provider first, then select it in Gateway settings. The gateway overrides the incoming `model` with the configured upstream provider model, redacts supported message text locally, and forwards the redacted request to the upstream provider.

Preview without forwarding:

```bash
curl http://127.0.0.1:8765/gateway/preview \
  -H "Content-Type: application/json" \
  -d '{
    "model": "test-model",
    "messages": [{"role": "user", "content": "Email ada@example.com."}]
  }'
```

Example compatible client request:

```bash
curl http://127.0.0.1:8765/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "test-model",
    "messages": [{"role": "user", "content": "Email ada@example.com."}],
    "stream": false
  }'
```

Gateway privacy behavior:

- Raw message text is not forwarded by default.
- `redact_request_messages` defaults to true and runs the normal local text redaction pipeline before forwarding.
- Disabling redaction requires `allow_raw_text_to_upstream = true`; otherwise requests fail closed.
- Non-local upstream providers receive redacted-only messages by default.
- `POST /gateway/preview` never forwards upstream and does not store prompts.
- Streaming is rejected for now.
- Plain string message content and multipart `{"type": "text"}` parts are supported; image/audio/file parts and other unsupported content fail closed unless a future explicit passthrough design is added.
- Gateway responses return upstream responses as-is, except an optional local `privacy_preflight` debug summary may be added when the request includes `privacy_preflight_debug: true`.
- The worker does not log or store raw gateway prompts.

Run the worker:

```bash
../../scripts/dev_worker.sh
```

The default worker URL is `http://127.0.0.1:8765`.

Check health:

```bash
curl http://127.0.0.1:8765/health
```

Run backend tests:

```bash
../../scripts/test_worker.sh
```

## Text redaction backend

The worker supports:

- `EMAIL`
- `PHONE`
- `URL`
- `IP_ADDRESS`
- `LOCAL_PATH`
- `API_KEY`
- `ID`
- Optional Presidio-detected entities such as `PERSON` when `PRIVACY_PREFLIGHT_ENABLE_PRESIDIO=1`.
- Optional OpenAI Privacy Filter entities such as `PERSON`, `DATE`, `ADDRESS`, `ID`, and `API_KEY` when `PRIVACY_PREFLIGHT_ENABLE_PRIVACY_FILTER=1`.
- Chinese/mixed-language entities such as `SCHOOL`, `ADDRESS`, `PERSON`, `COMPANY`, `ORGANIZATION`, `LOCATION`, and `CUSTOM`.

Use `mode: "balanced"` for high-confidence default redaction and `mode: "strict"` to include broader ID-like token detection. See `docs/text-redaction.md` for endpoint shape, local dictionary setup, limitations, and reference conclusions.

## macOS app

The SwiftUI app lives in `apps/macos/`. It can run from SwiftPM or as a development `.app` bundle:

```bash
cd apps/macos
swift build
swift run PrivacyPreflightApp
```

The app attempts to start the worker automatically when it can find the repository worker and a usable Python environment. Manual worker startup remains available for debugging:

```bash
scripts/dev_worker.sh
```

Build the development app bundle:

```bash
scripts/build_macos_app.sh
```

See `docs/installation.md`, `docs/release-readiness.md`, `docs/privacy-defaults.md`, `docs/troubleshooting.md`, and `docs/dependency-license-audit.md` before packaging or distributing builds. The 0.1.0 preview uses the permissive replacement PDF stack documented in the dependency audit; it remains ad-hoc signed and unnotarized.

Manual text redaction flow:

1. Run the macOS app from `apps/macos` with `swift run PrivacyPreflightApp`, open the package in Xcode, or open the development app bundle.
2. Confirm the worker panel shows the local worker as running. Use `Start`, `Stop`, `Restart`, and `Check` if needed.
3. Paste text into the input editor.
4. Choose `Balanced` or `Strict`.
5. Click `Redact`.
6. Review the redacted output, highlighted source preview, summary counts, and entity list.
7. Select entities in the list to inspect original text, replacement, type, source, confidence, span offsets, and reason.
8. Use the inspector actions to save the selected entity as `Always Mask This`, `Ask Me Next Time`, or `Always Allow This`; redact again to verify `source = "profile"` and `profile_rule_id` appear, or that an allow rule suppresses ordinary future matches.
9. Open `Profile`, use the `Learn` tab with sample text, find candidates, select candidates, and save them as profile rules.
10. Open `Models`, add an Ollama, LM Studio, or generic OpenAI-compatible provider, test it, select it as the review model, and enable LLM review if desired.
11. Open `Gateway`, select an OpenAI-compatible upstream provider, run a dry-run preview, then enable the gateway if desired.
12. Enter a revision such as `mask Project Phoenix`, `allow support@example.com`, `replace all school names with [SCHOOL]`, or `add Project Phoenix to profile as PROJECT`, then apply it and review the parsed commands.
13. Use `Privacy` > `Export Diagnostics` or `Clear Local Data` from the worker panel when needed.
14. Click `Copy` to copy the redacted text.

Manual image redaction flow:

1. Run the app and confirm the worker panel shows the local worker as running.
2. Switch to `Image`.
3. Drop or choose a PNG/JPEG image.
4. Choose `Safe` to mask every OCR text region, or `Precise` to mask only OCR boxes classified by the text pipeline.
5. Drag on the preview to add manual rectangles when needed.
6. Click `Redact Image`.
7. Review the preview boxes and redacted regions.
8. Click `Export` to save a new redacted image file.

Manual PDF redaction flow:

1. Run the app and confirm the worker panel shows the local worker as running.
2. Switch to `PDF`.
3. Drop or choose a PDF.
4. Review the rendered page preview and detected redaction regions.
5. Use the page selector to move between pages.
6. Drag on the preview to add manual rectangles when needed.
7. Click `Export PDF`.
8. Review the validation result, then save the new redacted PDF. The app prevents saving over the original PDF path.

Example mixed-language input:

```text
我的学校是北京理工大学，邮箱 ada@example.com，地址：北京市海淀区中关村南大街5号
```

Expected behavior: the app calls `POST /redact/text`, displays redacted placeholders such as `[SCHOOL]`, `[EMAIL]`, and `[ADDRESS]` when detected, highlights those source spans, and lists the detected span, entity type, source, replacement, and confidence. Selecting a row updates the inspector with the original text, replacement, offsets, and reason. If the worker is not running, the app shows a worker-offline message.

Packaging note: `scripts/build_macos_app.sh` requires a relocatable arm64 Python tree and embeds it in the `.app`. The 0.1.0 preview is self-contained, ad-hoc signed, unsandboxed, and unnotarized; it must not be described as Developer ID or Gatekeeper-approved distribution.

## Reference projects

The Phase 0 architecture was informed by:

- RedactDesk for local Mac/PDF redaction boundaries.
- Microsoft Presidio for analyzer/anonymizer separation.
- doc_redaction for document pipeline and human review cautions.
- CoverUP for rasterization-based PDF redaction safety tradeoffs.
- pypdfium2/PDFium, pypdf, Pillow, and ReportLab for local PDF inspection, rendering, pixel burn-in, image-only rebuild, and validation.
- LLM Guard for scanner and placeholder vault concepts.
- Cherry Studio issue #14910 for local pre-send PII redaction, typed placeholders, review affordances, and in-memory placeholder mapping concepts.

See `docs/references.md` for findings, license notes, and what was intentionally not reused.
