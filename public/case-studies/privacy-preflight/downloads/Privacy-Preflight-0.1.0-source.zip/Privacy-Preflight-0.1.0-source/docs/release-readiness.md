# Release Readiness

Last updated: 2026-05-28.

Privacy Preflight now has a development `.app` bundle path and in-app worker lifecycle controls, but it is not notarized, not sandbox-verified, and not cleared for public distribution.

## Packaging Path

Chosen path: SwiftPM plus an app-wrapper script.

Why this path:

- Keeps the current SwiftPM scaffold intact.
- Produces a normal macOS bundle layout at `apps/macos/build/Privacy Preflight.app`.
- Adds `Contents/Info.plist`, `Contents/MacOS/PrivacyPreflightApp`, `Contents/Resources/AppIcon.icns`, and worker source resources.
- Avoids adding XcodeGen, Tuist, or another build dependency before the target structure stabilizes.

Later release candidates can move to an Xcode project, XcodeGen, or Tuist if signing, sandboxing, helper embedding, and asset catalogs become easier to maintain there.

Build:

```bash
scripts/build_macos_app.sh
```

Zip package:

```bash
scripts/package_macos_zip.sh
```

The zip is a development package, not a notarized public release.

## Worker Lifecycle

The Mac app now attempts to start the local worker on launch and shows worker controls in the main window:

- status: stopped, starting, running, stopping, or needs attention
- endpoint: fixed `http://127.0.0.1:8765` unless `PRIVACY_PREFLIGHT_WORKER_PORT` is set
- last health check time
- start, stop, restart, and health-check buttons
- sanitized latest error
- packaging/development-mode limitation text

The worker is launched with:

```text
python -m uvicorn app.main:app --host 127.0.0.1 --port <port> --log-level warning --no-access-log
```

The app stops the worker on exit unless `PRIVACY_PREFLIGHT_KEEP_WORKER_ALIVE=1` is set. If the worker exits unexpectedly, the app attempts a limited restart.

Current limitation: Python runtime and Python dependencies are not bundled. In normal development, the app uses `services/worker/.venv/bin/python` when present. The dev app bundle can include worker source, but it still needs an available Python environment with worker dependencies installed.

## Localhost Decision

The worker binds only to `127.0.0.1`, not `0.0.0.0`. Uvicorn defaults to `127.0.0.1`, and the lifecycle manager passes `--host 127.0.0.1` explicitly. Gateway settings also default to `bind_host = "127.0.0.1"`.

## Bundle Contents

- Info.plist: `apps/macos/Info.plist`
- Entitlements template: `apps/macos/PrivacyPreflight.entitlements`
- Icon source: `apps/macos/Resources/AppIcon.svg`
- Generated icon: `Contents/Resources/AppIcon.icns`
- Bundled worker source for dev fallback: `Contents/Resources/worker`

The entitlements file documents the intended sandbox shape: app sandbox, outbound local network client, and user-selected read/write files. It is not yet applied or verified in a signed sandboxed build.

## App Data

Default paths:

- app data: `~/Library/Application Support/Privacy Preflight`
- profile rules: `~/Library/Application Support/Privacy Preflight/profile.json`
- model provider settings: `~/Library/Application Support/Privacy Preflight/model_providers.json`
- worker lifecycle log: `~/Library/Application Support/Privacy Preflight/Logs/worker-lifecycle.log`
- temporary OCR/PDF files: system temp directory; temporary Vision OCR files are deleted after use
- API keys: macOS Keychain service `Privacy Preflight Model Providers`

Overrides:

- `PRIVACY_PREFLIGHT_APP_DATA_DIR`
- `PRIVACY_PREFLIGHT_PROFILE_PATH`
- `PRIVACY_PREFLIGHT_MODEL_PROVIDER_PATH`
- `PRIVACY_PREFLIGHT_WORKER_DIR`
- `PRIVACY_PREFLIGHT_WORKER_PYTHON`
- `PRIVACY_PREFLIGHT_WORKER_PORT`

## Privacy Hardening

Implemented or verified:

- API keys are stored in macOS Keychain when possible.
- Provider API keys are not written to `model_providers.json`.
- API responses return only `api_key_configured`, not secret values.
- Worker errors shown to the UI are generic and avoid provider details or raw content.
- The app lifecycle log records worker events only, not submitted text, OCR output, PDF text, prompts, or API keys.
- Raw text/images/PDFs are not stored by default.
- History remains disabled by default.
- Profile learning does not persist raw sample text.
- Gateway preview does not forward upstream.
- External providers receive redacted-only text by default.
- Raw text to non-local providers requires explicit opt-in.
- Image redaction burns black rectangles into pixels and re-encodes without source metadata.
- PDF export rebuilds image-only PDFs with burned-in redactions and validates that redacted strings are not extractable.
- Clear Local Data endpoint and UI action remove profile and model provider settings; Keychain API keys are kept by default.
- Export Diagnostics endpoint and UI action return counts, paths, settings flags, and notes only; profile terms, raw content, prompts, OCR text, PDF text, and API keys are excluded.

## Signing And Notarization Checklist

Not complete for notarized public distribution. The 0.1.0 preview is a separately labeled ad-hoc-signed, unnotarized arm64 artifact.

Before public distribution:

1. Re-run the replacement PDF backend tests and verify the bundle contains only the audited permissive runtime.
2. Verify embedded CPython and worker dependencies are arm64; optional OCR binaries/models remain unbundled.
3. Generate a final app icon and asset catalog if moving to Xcode.
4. Apply and verify sandbox entitlements, or document a deliberate unsandboxed Developer ID distribution.
5. Sign all executable code with Developer ID and hardened runtime.
6. Ensure nested code and helper executables are placed in notarization-safe bundle locations.
7. Include and verify third-party license notices and the exact dependency lock.
8. Build a DMG or signed zip.
9. Submit with `notarytool`, staple the ticket, and verify Gatekeeper behavior on a clean Mac.

## Sources Checked

- Apple bundle content placement: https://developer.apple.com/documentation/bundleresources/placing-content-in-a-bundle
- Apple bundle structure: https://developer.apple.com/library/archive/documentation/CoreFoundation/Conceptual/CFBundles/BundleTypes/BundleTypes.html
- Apple app sandbox entitlements: https://developer.apple.com/documentation/security/app_sandbox
- Apple notarization: https://developer.apple.com/documentation/security/notarizing_macos_software_before_distribution
- Uvicorn host binding: https://www.uvicorn.org/settings/
