# Dependency License Audit

Last reviewed: 2026-07-17 for the exact 0.1.0 arm64 preview runtime.

This audit is for release planning, not legal advice. No referenced project code was copied into Privacy Preflight unless explicitly listed as a direct dependency.

## Summary

| Dependency | Current use | License finding | Distribution risk |
| --- | --- | --- | --- |
| pypdfium2 / PDFium | PDF rendering and character coordinates | BSD-3-Clause plus Apache-2.0 and bundled dependency terms | Low-to-medium. Preserve every license file included by the wheel and record the exact PDFium build. |
| pypdf | Structure inspection, text validation, annotation/image checks | BSD-3-Clause | Low. Preserve license notice. |
| ReportLab | Deterministic image-only PDF rebuild | BSD-style | Low. Preserve package and bundled-font notices. |
| Pillow | Direct PNG/JPEG decode, pixel burn-in, metadata-stripped encode | MIT-CMU / HPND-style permissive | Low. Preserve license notices. |
| python-multipart | FastAPI multipart upload parsing | Apache-2.0 | Low. Preserve license/notice. |
| FastAPI | Worker API framework | MIT | Low. Preserve license notice. |
| Uvicorn | Local ASGI server launched on `127.0.0.1` | BSD-3-Clause | Low. Preserve license notice. |
| Pydantic | Request/response validation | MIT | Low. Preserve license notice. |
| Microsoft Presidio | Optional detector extra | MIT | Low for code. Local NLP model licenses still need separate review before bundling. |
| pytesseract | Optional OCR adapter | Apache-2.0 | Low. Requires separate local Tesseract binary and language data review if bundled. |
| Tesseract OCR | Optional local OCR binary, not bundled | Apache-2.0; Leptonica dependency noted by Tesseract | Low if bundled correctly with notices; currently user-installed only. |
| OpenAI Privacy Filter | Optional local detector adapter, not bundled | Apache-2.0 per OpenAI GitHub/release notes | Low for official package/model; supply-chain risk means only official OpenAI sources should be used. |
| SwiftUI/AppKit/Foundation | macOS app | Apple SDK terms | Normal Apple platform distribution constraints. |
| Packaging scripts added here | Local scripts only | Project code | Low. No third-party packaging dependency added. |

## PDF stack conclusion

The distributed 0.1.0 preview no longer uses or bundles PyMuPDF/fitz. The replacement uses pypdfium2/PDFium, pypdf, Pillow, and ReportLab while preserving rasterized image-only export with burned-in pixels. Exact-package tests and bundle inspection must verify that no `fitz` or `pymupdf` module is present before release. This removes the previously identified AGPL/commercial PyMuPDF blocker; it does not constitute legal advice or notarization readiness.

## OCR Notes

The default macOS Vision bridge is local and uses temporary files that are deleted after OCR. The optional Tesseract path is not bundled. If a future release bundles Tesseract, include Tesseract, Leptonica, language-data, and transitive native library notices.

## OpenAI Privacy Filter Notes

The Privacy Filter adapter is optional and disabled unless configured. Only the official OpenAI GitHub/Hugging Face sources should be used. The model is a detector-layer dependency, not a chat/review provider, and raw text stays local when it is used.

## Reference Projects

Reference projects were used conceptually only:

- RedactDesk informed local Mac redaction boundaries and destructive PDF export expectations.
- Microsoft Presidio informed detector/analyzer separation.
- doc_redaction informed staged document processing and human review cautions; no AGPL code was reused.
- LLM Guard informed local pre-model sanitization and structured scanner boundaries.
- CoverUP informed rasterized manual PDF redaction; no GPL code was reused.
- OpenAI Privacy Filter informed optional local detector behavior; only adapter concepts were used.

## Sources Checked

- pypdfium2 licensing: https://github.com/pypdfium2-team/pypdfium2
- pypdf licensing: https://github.com/py-pdf/pypdf
- ReportLab licensing: https://www.reportlab.com/software/opensource/
- Pillow license: https://github.com/python-pillow/Pillow/blob/main/LICENSE
- FastAPI license: https://github.com/fastapi/fastapi
- Uvicorn license: https://github.com/Kludex/uvicorn
- Pydantic license: https://github.com/pydantic/pydantic/blob/main/LICENSE
- python-multipart package/license metadata: https://github.com/Kludex/python-multipart, https://pypi.org/project/python-multipart/
- Microsoft Presidio license: https://github.com/microsoft/presidio
- pytesseract license: https://github.com/madmaze/pytesseract
- Tesseract license: https://github.com/tesseract-ocr/tesseract
- OpenAI Privacy Filter: https://github.com/openai/privacy-filter, https://openai.com/index/introducing-openai-privacy-filter/
