# PDF Redaction MVP

Phase 7 adds local PDF analysis and export. The implementation is intentionally conservative: exported PDFs are rebuilt as image-only pages after redaction regions are burned into page pixels. This avoids relying on visual overlays or hidden text-layer behavior.

## Implementation Note

### Why black rectangles alone are unsafe

A PDF can contain text, images, annotations, metadata, accessibility data, and hidden or clipped drawing instructions as separate objects. Drawing a black rectangle over a page changes the visible appearance, but it can leave the original text underneath searchable, copyable, screen-reader accessible, or extractable by AI/document parsers. Privacy Preflight therefore treats overlay-only redaction as unsafe final output.

### When text-layer redaction is acceptable

Text-layer redaction is acceptable only when the PDF engine removes affected source content and validation proves the result. This preview deliberately does not preserve or mutate the source text layer: the final trust boundary is an image-only rebuild.

### When rasterization fallback is required

Rasterization is required when the source has scanned pages, mixed image/text content, OCR-derived regions, manual page rectangles, uncertain PDF structure, or any case where native content-stream redaction alone cannot be proven safe. This MVP always uses the rasterized rebuild as the final exported PDF format: pages are rendered locally, redaction rectangles are burned into the rendered pixels, and a new PDF is created from those images.

### Validation method

After export, the worker reopens the output PDF locally and:

1. Extracts text from every output page.
2. Verifies known detector/OCR redacted strings are absent.
3. Verifies no extractable text layer remains in the rebuilt output.
4. Verifies redaction annotations were not left unapplied.
5. Returns `passed`, `warning`, or `failed` validation metadata to the app.

If validation fails, the worker does not return a redacted PDF. If manual-only redaction leaves no known detector strings to check, validation returns a warning while still confirming the output PDF has no extractable text layer.

## Backend Behavior

Endpoints:

```text
POST /redact/pdf/analyze
multipart fields:
  pdf: file
  mode: balanced | strict

POST /redact/pdf/export
multipart fields:
  pdf: file
  mode: balanced | strict
  manual_rectangles: optional JSON array of {page_index, x, y, width, height}
```

Processing flow:

1. Open the PDF in memory with pypdfium2/PDFium and pypdf.
2. Classify pages as text, scanned, or mixed based on extractable text and image objects.
3. Extract word-level text and page coordinates where a text layer exists.
4. Run the existing local text redaction pipeline against extracted page text.
5. Map selected entities back to page rectangles using word coordinates.
6. For scanned or image-containing pages, render locally and run the configured local OCR provider; OCR boxes are redacted only when their text is classified as sensitive.
7. Merge detected regions with user-supplied manual rectangles.
8. Render pages through PDFium, burn all redaction rectangles into page pixels, rebuild a fresh image-only PDF with ReportLab, and replace source metadata with minimal release metadata.
9. Validate the exported PDF before returning it.

## Frontend Behavior

The macOS app now includes a PDF workspace:

- Drag/drop or choose a PDF.
- The app sends the PDF to the local worker for analysis.
- The worker returns page preview images and detected regions.
- The user can draw manual rectangles on each page preview.
- Export sends the original PDF plus manual rectangles to the worker.
- The worker returns the rebuilt redacted PDF only after validation.
- The app shows the validation result and prevents overwriting the original file path.

## Dependency Setup

PDF support uses the default permissive dependency set:

```bash
cd services/worker
python -m pip install -e ".[dev]"
```

Scanned or mixed image/text PDFs require a local OCR provider:

- Default macOS setup uses the existing Vision OCR bridge when Swift is available.
- Tesseract remains available through the `image-ocr` extra and a local Tesseract binary.
- If OCR is required but unavailable, PDF analysis/export fails closed with an explanation.

## Safety Limitations

- This is not legal-grade redaction.
- OCR can miss visible text, especially low-quality scans, handwriting, unusual fonts, rotated text, or non-default languages.
- Text-coordinate mapping is word based; complex ligatures, unusual encodings, rotated text, or malformed PDFs may over-redact or miss precise boundaries.
- The MVP favors destructive raster output over preserving selectable text. This improves extraction safety but increases file size and removes selectable/searchable non-redacted text.
- Very large PDFs may be slow or memory-heavy because pages are rendered locally.
- Embedded files, JavaScript, forms, and complex annotations are not preserved in the rebuilt output; the output is intended as a flattened sharing copy.

## Reference Projects

- RedactDesk: local Mac PDF redaction, on-device Privacy Filter, and image-rewrite export informed the conservative final-output model.
- doc_redaction: staged document extraction, OCR, review, and export concepts informed the backend module boundary; no code was reused because the project is AGPL-3.0.
- CoverUP: rasterization-based redaction informed the fallback/default export strategy where final PDF pages contain images rather than recoverable source text.
- pypdfium2/PDFium, pypdf, Pillow, and ReportLab: used for local structure inspection, coordinate mapping/rendering, opaque pixel burn-in, image-only rebuild, and validation extraction.
