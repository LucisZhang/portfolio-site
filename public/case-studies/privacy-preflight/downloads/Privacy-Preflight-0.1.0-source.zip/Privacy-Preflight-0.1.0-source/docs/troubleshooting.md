# Troubleshooting

## Worker Shows Stopped Or Needs Attention

Use the worker panel in the app:

1. Click `Check`.
2. Click `Start`.
3. If it still fails, click `Restart`.

Common causes:

- `services/worker/.venv` has not been created.
- Worker dependencies have not been installed.
- Port `8765` is already in use.
- The app was moved away from the repository and no bundled Python environment exists.

Check manually:

```bash
curl http://127.0.0.1:8765/health
```

Run the lifecycle smoke test:

```bash
scripts/smoke_worker_lifecycle.sh
```

## Change Worker Port

```bash
export PRIVACY_PREFLIGHT_WORKER_PORT=8876
cd apps/macos
swift run PrivacyPreflightApp
```

The worker always binds to `127.0.0.1`.

## Worker Logs

Lifecycle events are written to:

```text
~/Library/Application Support/Privacy Preflight/Logs/worker-lifecycle.log
```

The app does not persist worker stdout/stderr by default because traces can accidentally include implementation details. Uvicorn access logs are disabled by the app launch path.

## Export Diagnostics

Use `Privacy` > `Export Diagnostics` in the worker panel.

Diagnostics include:

- app data paths
- profile rule count
- model provider count
- model/gateway privacy flags
- worker data locations

Diagnostics exclude:

- submitted text
- OCR output
- PDF extracted text
- prompts
- profile rule terms
- API keys

## Clear Local Data

Use `Privacy` > `Clear Local Data` in the worker panel.

This clears profile and model provider settings. API keys in Keychain are kept by default so the user can decide whether to remove them separately.

## PDF dependency audit

Before packaging, review `docs/dependency-license-audit.md` and preserve all notices from the exact pypdfium2/PDFium, pypdf, Pillow, and ReportLab versions. The former PDF dependency blocker was replaced for 0.1.0; signing and notarization remain separate release gates.
