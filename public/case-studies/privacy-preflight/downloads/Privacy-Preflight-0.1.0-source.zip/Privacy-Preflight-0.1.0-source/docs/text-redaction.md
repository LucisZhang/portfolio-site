# Text Redaction Backend

Phase 1 implements local deterministic text redaction in the FastAPI worker. Phase 1.5 adds Microsoft Presidio as an optional local detector source. Phase 1.6 adds a local Chinese and mixed-language detector layer. Phase 1.7 adds configurable local dictionaries and Chinese evaluation fixtures. Phase 3 adds local profile rules with `mask`, `ask`, and `allow` actions. Phase 3.5 adds profile sample learning and selected-result quick rule capture. Phase 4 adds an optional, local-first LLM review loop. Phase 4.1 adds an optional OpenAI Privacy Filter detector adapter. Phase 5 adds natural-language revision commands that parse user intent into structured commands before deterministic application. The same text pipeline is reused by image OCR and PDF extraction/OCR flows, but the text endpoint itself still does not implement model comparison, remove/delete text commands, or provider-specific OpenRouter, DashScope, or Gemini clients.

## Endpoint

`POST /redact/text`

Request:

```json
{
  "text": "Email Ada at ada@example.com.",
  "mode": "balanced"
}
```

Response:

```json
{
  "redacted_text": "Email Ada at [EMAIL].",
  "entities": [
    {
      "id": "ent_0001",
      "text": "ada@example.com",
      "type": "EMAIL",
      "start": 13,
      "end": 28,
      "confidence": 0.98,
      "source": "regex:email",
      "action": "replace",
      "replacement": "[EMAIL]",
      "reason": "Matched a standard email address pattern.",
      "profile_rule_id": null
    }
  ],
  "summary": {
    "EMAIL": 1
  }
}
```

Entity offsets are original input offsets. They are Python `str` offsets, which means they count Unicode code points, not UTF-8 bytes, UTF-16 code units, or user-perceived grapheme clusters. Replacement is applied from the end of the text toward the beginning so earlier replacements do not shift later spans.

Frontend clients must convert `start` and `end` as Unicode code point offsets. In Swift, do not use `String.index(_:offsetBy:)` on `Character` positions for these values because composed characters and some emoji can make Swift `Character` counts differ from Python code point counts. Convert through `String.unicodeScalars`, then validate that the extracted substring matches `entity.text` when it is present. If a client cannot map or validate a span safely, it should skip visual highlighting for that entity and show a diagnostic indicator rather than crashing or highlighting the wrong text.

Replacement placeholders use square brackets, for example `[EMAIL]` and `[API_KEY]`. This avoids HTML/XML-like angle bracket tokens in redacted text and keeps placeholders visually distinct from URLs and markup.

`action` is `replace` for built-in detector replacements, `mask` for profile rules that always mask, `ask` for profile rules that should be reviewed, and `allow` only for suppression candidates before entity construction. `ask` rules still use their replacement in `redacted_text` so the default output remains safe; the UI can use the action metadata to ask the user before future workflows forward content.

`profile_rule_id` is present when an entity was created by a profile rule. Built-in regex, Privacy Filter, Presidio, Chinese dictionary, and local dictionary entities leave it null.

## Optional LLM Review Endpoint

`POST /redact/text/review`

Request:

```json
{
  "text": "Client Project Phoenix.",
  "mode": "balanced",
  "provider_id": "model_ollama_1234abcd",
  "enable_llm_review": true,
  "allow_raw_text_for_external_models": false
}
```

If `provider_id`, `enable_llm_review`, or `allow_raw_text_for_external_models` are omitted, the worker uses the stored model review settings.

Response:

```json
{
  "initial_result": {
    "redacted_text": "Client Project Phoenix.",
    "entities": [],
    "summary": {}
  },
  "review_result": {
    "provider_id": "model_ollama_1234abcd",
    "provider_name": "Ollama",
    "provider_is_local": true,
    "raw_text_sent": true,
    "raw_text_blocked": false,
    "warning": null,
    "parsed": true,
    "parse_error": null,
    "suggestion": {
      "pass": false,
      "risk_level": "medium",
      "missed_items": [
        {
          "text": "Project Phoenix",
          "entity_type": "CUSTOM",
          "replacement": "[PROJECT]",
          "reason": "Project name remains visible."
        }
      ],
      "false_positives": [],
      "suggested_policy_updates": []
    },
    "applied_missed_items": [
      {
        "text": "Project Phoenix",
        "entity_type": "CUSTOM",
        "replacement": "[PROJECT]",
        "occurrence_count": 1
      }
    ],
    "invalid_suggestions": []
  },
  "final_result": {
    "redacted_text": "Client [PROJECT].",
    "entities": [
      {
        "id": "ent_0001",
        "text": "Project Phoenix",
        "type": "CUSTOM",
        "start": 7,
        "end": 22,
        "confidence": 0.62,
        "source": "llm_review",
        "action": "replace",
        "replacement": "[PROJECT]",
        "reason": "Model review suggested an exact missed item; the worker applied it by local exact match.",
        "profile_rule_id": null
      }
    ],
    "summary": {
      "CUSTOM": 1
    }
  }
}
```

The review model must return only structured JSON with `pass`, `risk_level`, `missed_items`, `false_positives`, and `suggested_policy_updates`. The worker ignores free-form rewrites and fields outside that schema. Only valid `missed_items` are auto-applied, and only when the suggested text can be found as an exact local match outside existing deterministic entities. The final result is produced by re-running the redaction pipeline with those extra local candidates, preserving existing conflict handling and high-risk API-key protection.

Privacy rules:

- Local providers may receive original text.
- Non-local providers receive redacted-only review input by default.
- Original text to non-local providers requires `allow_raw_text_for_external_models: true`.
- Model review suggestions are returned for review; false positives and policy updates are not persisted or auto-applied.

## Natural-Language Revision Endpoints

`POST /revision/parse`

Request:

```json
{
  "text": "Client Project Phoenix meets on 2026-05-27.",
  "mode": "balanced",
  "instruction": "replace all dates with [DATE]",
  "scope": "current_document",
  "selected_entity_id": null,
  "enable_model_parsing": false
}
```

Response:

```json
{
  "initial_result": {
    "redacted_text": "Client Project Phoenix meets on 2026-05-27.",
    "entities": [],
    "summary": {}
  },
  "parse_result": {
    "parser": "deterministic",
    "provider_id": null,
    "provider_name": null,
    "provider_is_local": true,
    "raw_text_sent": false,
    "raw_text_blocked": false,
    "warning": null,
    "parsed": true,
    "parse_error": null,
    "commands": [
      {
        "intent": "change_replacement",
        "target_text": null,
        "target_entity_id": null,
        "entity_type": "DATE",
        "replacement": "[DATE]",
        "action": null,
        "scope": "current_document",
        "reason": "Deterministic parser matched a replace-all command."
      }
    ],
    "invalid_commands": []
  }
}
```

`POST /redact/text/revise`

The revise endpoint accepts the same request shape, parses commands when `commands` is omitted, applies them, and returns the initial result, parse metadata, final result, command application metadata, and any created or updated profile rules.

Example:

```json
{
  "text": "Ship Project Phoenix notes.",
  "instruction": "add Project Phoenix to profile as PROJECT",
  "scope": "profile"
}
```

This saves a local profile rule for the exact phrase and returns a final result with `Project Phoenix` replaced by `[PROJECT]`.

Revision commands use this validated schema:

```json
{
  "intent": "mask",
  "target_text": "Project Phoenix",
  "target_entity_id": null,
  "entity_type": "PROJECT",
  "replacement": "[PROJECT]",
  "action": "mask",
  "scope": "current_document",
  "reason": "User asked to mask the project name."
}
```

Supported intents are `mask`, `allow`, `ask`, `change_replacement`, and `add_to_profile`. A command must target exact text, a current result entity id, or an entity type. Replacements must be bracket placeholders such as `[DATE]` or `[PROJECT]`; arbitrary code, free-form document rewrites, and remove/delete commands are not accepted.

Deterministic fallback commands are available without a model:

- `mask <text>`
- `mask <text> as <label>`
- `allow <text>`
- `ask <text>`
- `replace <text> with <label>`
- `replace all <entity type> with <label>`
- `add <text> to profile as <label>`

Revision application rules:

- Current-document commands create transient `source = "revision"` candidates and re-run conflict resolution.
- Profile-scope commands create or update local profile rules and then re-run redaction through the profile detector.
- `allow` commands suppress ordinary overlapping detections, but not high-risk regex API-key detections.
- Type-only commands apply to currently detected entities of that type.
- Invalid model JSON produces `parsed = false`; the revise endpoint leaves the initial deterministic result unchanged.

Provider privacy behavior:

- Model parsing is optional and uses the configured review provider settings.
- Local providers may receive the original text and instruction.
- External providers are skipped by default for revision parsing because the instruction can itself contain raw sensitive text. Deterministic fallback is used and `raw_text_blocked` is true.
- Sending original text and the revision instruction to an external provider requires `allow_raw_text_for_external_models: true`, and the parse result includes a warning.

## Supported Entity Types

- `EMAIL`: Standard email address patterns.
- `PHONE`: Phone-number-like patterns with 10 to 15 digits.
- `URL`: `http://`, `https://`, and `www.` URLs.
- `IP_ADDRESS`: Validated IPv4 and IPv6 addresses.
- `LOCAL_PATH`: Common local paths, especially macOS-style paths such as `/Users/name/...`, including Chinese characters and spaces in file paths with extensions, plus selected `/Volumes`, `/private`, `/var`, `/tmp`, `/Applications`, and `~/...` paths.
- `API_KEY`: Common key/token prefixes and credential assignment patterns such as `OPENAI_API_KEY=...`, GitHub tokens, AWS access key IDs, Google API keys, Slack tokens, Stripe keys, and JWT-like values.
- `ID`: Long mixed alphanumeric identifier-like strings.
- `DATE`: Private date-like spans from optional OpenAI Privacy Filter detections.
- OpenAI Privacy Filter types can appear when the detector is enabled. Its labels map as `private_person` to `PERSON`, `private_email` to `EMAIL`, `private_phone` to `PHONE`, `private_url` to `URL`, `private_address` to `ADDRESS`, `private_date` to `DATE`, `account_number` to `ID`, and `secret` to `API_KEY`.
- Presidio-only types such as `PERSON`, `LOCATION`, and other Presidio recognizer labels can appear when Presidio is enabled. For overlapping built-in types, Presidio `EMAIL_ADDRESS` is mapped to `EMAIL` and `PHONE_NUMBER` is mapped to `PHONE`.
- Chinese detector types: `PERSON`, `SCHOOL`, `COMPANY`, `ORGANIZATION`, `LOCATION`, `ADDRESS`, and `CUSTOM`.

## OpenAI Privacy Filter Configuration

OpenAI Privacy Filter is an optional detector-layer integration, not an LLM review provider. It is a token-classification/span model that runs locally and returns detected spans, so the worker maps those spans into ordinary redaction candidates with `source = "privacy_filter"`.

Phase 4.1 does not add the official runtime as a default dependency. To try real local inference, install the official package and download or place the checkpoint locally:

```bash
git clone https://github.com/openai/privacy-filter.git
cd privacy-filter
python -m pip install -e .
```

Then point Privacy Preflight at the local checkpoint:

```bash
export PRIVACY_PREFLIGHT_ENABLE_PRIVACY_FILTER=1
export PRIVACY_PREFLIGHT_PRIVACY_FILTER_RUNTIME=opf
export PRIVACY_PREFLIGHT_PRIVACY_FILTER_DEVICE=cpu
export PRIVACY_PREFLIGHT_PRIVACY_FILTER_MODEL_PATH=/path/to/privacy_filter/checkpoint
```

`PRIVACY_PREFLIGHT_PRIVACY_FILTER_MODEL_ID` is also available for future runtimes that load by model id. The current `opf` runtime is most predictable with `PRIVACY_PREFLIGHT_PRIVACY_FILTER_MODEL_PATH`, because the official package expects a checkpoint directory or its own default checkpoint location.

The official `opf` package may download the default checkpoint if no checkpoint is present at its default location. For Privacy Preflight, prefer an explicit local `PRIVACY_PREFLIGHT_PRIVACY_FILTER_MODEL_PATH` so redaction startup does not unexpectedly fetch model weights.

Known limitations:

- The official runtime is PyTorch-based and can be heavy for the current worker environment.
- CPU inference on macOS/Apple Silicon is feasible but may be slow; the official repo does not advertise native MPS/MLX support.
- Privacy Filter is trained on a static label policy. Domain-specific boundaries require calibration or fine-tuning outside this app.
- The model can miss uncommon names or novel secrets, over-redact ambiguous public text, or produce shifted/fragmented spans.
- The adapter validates returned span text against the original input and skips unsafe offsets rather than redacting the wrong substring.

## Presidio Configuration

Presidio is an optional dependency. Install it only when local Presidio detection is needed:

```bash
cd services/worker
python -m pip install -e ".[dev,presidio]"
```

Presidio Analyzer may require a local NLP model before it can run. Follow the Presidio model setup for the selected language, for example an English spaCy model.

Enable Presidio for the worker:

```bash
export PRIVACY_PREFLIGHT_ENABLE_PRESIDIO=1
export PRIVACY_PREFLIGHT_PRESIDIO_LANGUAGE=en
export PRIVACY_PREFLIGHT_PRESIDIO_SCORE_THRESHOLD=0.35
```

If `PRIVACY_PREFLIGHT_ENABLE_PRESIDIO` is unset or false, the worker still uses deterministic regex detectors and the enabled Chinese detector layer. The integration disables `tldextract` public suffix list fetching and keeps its cache in the local temp directory so Presidio email validation does not make runtime network calls.

## Chinese And Mixed-Language Configuration

The default Chinese provider is `dictionary_only`. It runs locally with no heavy dependency and includes a small public-institution seed dictionary plus a conservative Chinese address marker detector.

```bash
export PRIVACY_PREFLIGHT_ENABLE_CHINESE_NER=1
export PRIVACY_PREFLIGHT_CHINESE_NER_PROVIDER=dictionary_only
```

Supported provider values are `dictionary_only`, `hanlp`, `lac`, and `ltp`. Phase 1.6 implements `dictionary_only` and a HanLP adapter. `lac` and `ltp` are reserved configuration values from the research pass and currently fall back to the dependency-free detectors.

### Local Dictionary File

Users or tests can add local Chinese and mixed-language terms without installing a heavy NER model:

```bash
export PRIVACY_PREFLIGHT_DICTIONARY_PATH=/path/to/privacy-preflight-dictionary.json
```

Dictionary files use JSON:

```json
{
  "version": 1,
  "rules": [
    {
      "id": "rule_school_bit",
      "label": "BIT",
      "entity_type": "SCHOOL",
      "patterns": ["北京理工大学", "Beijing Institute of Technology", "BIT"],
      "replacement": "[SCHOOL]",
      "enabled": true,
      "source": "user_dictionary"
    }
  ]
}
```

Supported dictionary entity types are `PERSON`, `SCHOOL`, `COMPANY`, `ORGANIZATION`, `LOCATION`, `ADDRESS`, and `CUSTOM`. `patterns` contains exact terms and aliases. Latin-script aliases are matched case-insensitively with word boundaries; Chinese terms are matched as exact substrings. Disabled rules are ignored. Phase 1.7 user dictionary rules must use `source: "user_dictionary"` so local rules cannot impersonate internal regex, Presidio, or future allowlist sources.

Loading order is:

1. Built-in public sample dictionary entries.
2. Optional local dictionary file from `PRIVACY_PREFLIGHT_DICTIONARY_PATH`.
3. Future profile allowlist/suppression rules, once profile onboarding exists.

Local dictionary candidates use `source = "user_dictionary"` and can carry their own `replacement`. Validation errors identify the invalid rule and field without echoing pattern values or document text.

Because the local dictionary path is optional, worker startup and redaction fall back to the built-in dictionary if the configured file is missing, unreadable, malformed JSON, or fails validation. Future UI/profile import flows can call the strict validation helper to show the user a clear configuration error before saving a dictionary.

Optional HanLP setup:

```bash
cd services/worker
python -m pip install -e ".[dev,chinese-ner]"
export PRIVACY_PREFLIGHT_ENABLE_CHINESE_NER=1
export PRIVACY_PREFLIGHT_CHINESE_NER_PROVIDER=hanlp
export PRIVACY_PREFLIGHT_CHINESE_NER_MODEL_PATH=/path/to/local/hanlp/model
```

HanLP is never called as a remote service. The adapter requires a local model path; runtime model downloads are intentionally not part of the worker.

## Personal Redaction Profile

Phase 3 adds a human-readable local profile stored under the app data directory. By default on macOS, the path is:

```text
~/Library/Application Support/Privacy Preflight/profile.json
```

For development and tests, the location can be overridden:

```bash
export PRIVACY_PREFLIGHT_APP_DATA_DIR=/path/to/app-data
export PRIVACY_PREFLIGHT_PROFILE_PATH=/path/to/profile.json
```

The profile JSON shape is:

```json
{
  "version": 1,
  "rules": [
    {
      "id": "profile_tsinghua_8ad4e391",
      "label": "Tsinghua",
      "entity_type": "SCHOOL",
      "patterns": ["清华大学"],
      "aliases": ["Tsinghua University"],
      "replacement": "[SCHOOL]",
      "action": "mask",
      "enabled": true,
      "scope": "global",
      "created_at": "2026-05-27T12:00:00Z",
      "updated_at": "2026-05-27T12:00:00Z"
    }
  ]
}
```

Profile rule fields:

- `id`: Stable local rule id generated by the worker.
- `label`: User-visible rule name.
- `entity_type`: Entity type returned in redaction entities, normalized to uppercase identifier style.
- `patterns`: Exact terms to match.
- `aliases`: Additional exact terms to match. Latin-script terms are matched case-insensitively with word boundaries; Chinese and other non-Latin terms are matched as exact substrings.
- `replacement`: Placeholder used in `redacted_text`, such as `[SCHOOL]`.
- `action`: `mask`, `ask`, or `allow`.
- `enabled`: Disabled rules are ignored.
- `scope`: `global` or `text`. Phase 3 applies both to text redaction; the field is present for future content-type separation.
- `created_at` / `updated_at`: UTC timestamps maintained by the worker for rule CRUD operations.

Profile endpoints:

- `GET /profile`: Return the full local profile.
- `PUT /profile`: Replace the full local profile.
- `POST /profile/learn-from-text`: Return suggested profile-rule candidates from sample text without saving them.
- `POST /profile/rules`: Create one rule from a payload without `id`, `created_at`, or `updated_at`.
- `PUT /profile/rules/{id}`: Replace one rule's editable fields while preserving its id and creation time.
- `DELETE /profile/rules/{id}`: Delete one rule.

### Profile Sample Learning

`POST /profile/learn-from-text`

Request:

```json
{
  "text": "Email Ada at ada@example.com. 我的学校是北京理工大学。",
  "mode": "balanced"
}
```

Response:

```json
{
  "candidates": [
    {
      "id": "cand_0001",
      "suggested_entity_type": "EMAIL",
      "pattern": "ada@example.com",
      "aliases": [],
      "replacement": "[EMAIL]",
      "suggested_action": "mask",
      "source_detector": "regex:email",
      "confidence": 0.98,
      "reason": "Matched a standard email address pattern."
    }
  ]
}
```

The learning endpoint runs the existing local detector stack and conflict handling, including deterministic regex detectors, optional local OpenAI Privacy Filter when enabled, optional local Presidio when enabled, Chinese/mixed-language detectors, local dictionary rules, and current profile context. Existing profile mask/ask rules prevent duplicate candidate suggestions for the same span, and profile allow rules suppress ordinary overlapping candidates. Regex API-key detections still keep their high-risk priority.

Learning returns candidate rule payload material only. It does not write the profile file, does not store the submitted sample, does not create redaction history, and does not call external services. The Mac app's `Learn` tab saves only explicitly selected candidates by calling `POST /profile/rules`; those saved rules are reversible through the existing profile delete action.

### Result-Page Quick Rule Capture

The Mac app inspector can create a profile rule from the selected result entity:

- `Always Mask This`: saves an exact-pattern `mask` rule with the entity type and replacement.
- `Ask Me Next Time`: saves an exact-pattern `ask` rule.
- `Always Allow This`: saves an exact-pattern `allow` rule, which suppresses ordinary future matches for that span.
- `Add Pattern`: opens Profile settings with a prefilled editable rule draft.

Highlighted spans remain read-only in Phase 3.5. Selecting entities through the result table continues to drive the inspector and focused highlight state; direct click-to-select on highlighted text is deferred until the preview becomes a richer text review surface.

Profile action semantics:

- `mask`: Create a `source = "profile"` entity and replace the matched span with the rule replacement.
- `ask`: Create a `source = "profile"` entity with `action = "ask"` and replace the matched span with the rule replacement in the default redacted output.
- `allow`: Suppress ordinary overlapping detections, such as a public support email or dictionary-only term. It does not suppress high-risk deterministic API-key detections.

Conflict handling with profile rules:

- Explicit profile allow rules suppress ordinary overlapping matches.
- Profile mask/ask rules override ordinary regex, Chinese dictionary, and local dictionary matches so user rules can customize labels and replacements.
- Regex API-key detections keep priority over overlapping profile rules and allow rules.
- Existing Chinese dictionary and local dictionary behavior remains enabled.

Privacy constraints:

- Profile data is stored only on the local Mac.
- Profile storage does not save submitted documents, sample text, redaction history, or placeholder-to-original mappings.
- Rule patterns and aliases may contain user-entered sensitive terms, so the profile file must not be sent externally.
- The worker does not send profile data to external services.
- Profile learning does not persist raw samples. It returns detected literal candidate patterns to the caller for local review, and only selected candidates become stored profile rules.

## Modes

- `balanced`: Redacts high-confidence deterministic matches and long/contextual ID-like strings.
- `strict`: Includes balanced behavior and redacts shorter long ID-like strings. This mode is more likely to catch sensitive identifiers and more likely to produce false positives.

## Conflict Handling

The pipeline gathers detector candidates, resolves overlapping spans, then applies replacements. If one candidate contains another, the larger span is used. For same-size or partial overlaps, the pipeline prefers higher-confidence candidates, then longer spans, then stable type priority.

Profile allowlist candidates suppress ordinary overlapping redaction candidates before entity construction. Regex API-key detections keep priority over overlapping Privacy Filter, Presidio, Chinese, dictionary, profile, or allow spans so broad detections or user rules do not weaken secret redaction.

This keeps replacements conflict-safe and leaves a single ordered entity list for the UI review layer.

## Limitations

- Regex detectors are intentionally conservative and can miss names, addresses, account numbers, and domain-specific identifiers.
- Phone detection is general and may produce false positives on formatted numeric strings.
- Local path detection now supports common macOS paths with Chinese characters and spaces when the path includes a file extension. Escaped or quoted paths with complex shell syntax still need broader parsing in a later phase.
- `API_KEY` detection covers common shapes but is not a complete secret scanner.
- `ID` detection is heuristic, especially in `strict` mode.
- OpenAI Privacy Filter is disabled by default and requires the optional official `opf` runtime plus local checkpoint setup when enabled.
- Presidio is disabled by default and requires optional local dependencies plus local NLP model setup when enabled.
- Presidio defaults to English. Chinese detection is handled separately and should still be considered partial.
- The built-in Chinese dictionary is intentionally small and does not claim broad school/company/person coverage. Practical coverage should come from an explicit local dictionary file or reviewed profile rules, not hidden production assumptions.
- Chinese address detection is marker-based and conservative. It catches obvious address-like spans but is not a full address parser.
- HanLP support is adapter-level only. Accuracy and licensing depend on the local model a user installs. Phase 1.7 does not integrate real HanLP/LAC/LTP runtime.
- The response includes matched entity text for local user review. The worker must not log or persist raw request bodies or entity text.
- No remove/delete action is implemented. Text actions are replacement-oriented: built-in `replace`, profile `mask`, profile `ask`, and profile `allow`.
- Directly clicking highlighted source spans to select an entity is deferred; row selection remains the accessible selection path.
- No external network calls are made by the redaction pipeline.

## Reference Conclusions

Microsoft Presidio informed the separation between detection results and anonymization/replacement. Phase 1.5 plugs Presidio Analyzer into the detector boundary by mapping `RecognizerResult.entity_type`, `start`, `end`, and `score` to local redaction candidates. Presidio Anonymizer is intentionally not used because replacement remains centralized after conflict resolution across detector sources.

OpenAI Privacy Filter informed Phase 4.1's detector-layer adapter. It is a local token classifier with span output, so it belongs beside regex, Presidio, Chinese dictionary, local dictionary, and Profile detectors rather than in the chat-model review layer.

Phase 1.6 reviewed HanLP, Baidu LAC, HIT LTP/N-LTP, Chinese address parsing projects, CLUENER2020, and awesome-chinese-ner. The chosen default is `dictionary_only` because it is local, deterministic, and dependency-free. HanLP is represented by an optional adapter for future local model use; LAC/LTP/address parsing packages remain future references until dependency, licensing, and span behavior are verified.

Phase 1.7 keeps the same provider choice and adds local JSON dictionaries plus fixture-based Chinese evaluation. No new Chinese NLP runtime is added because configurable deterministic coverage is enough for the UI MVP and avoids model download, license, and startup-cost risk.

LLM Guard informed the scanner-style boundary and the idea that sanitization should happen before any future model review. Phase 1 intentionally does not implement LLM Guard's vault/deanonymization behavior because raw-to-placeholder mapping persistence needs a separate privacy design.

Phase 3 revisited LLM Guard's anonymization/vault documentation and Cherry Studio's PII redaction proposal. Both reinforced typed placeholders, local pre-model sanitization, preview/review affordances, and scoped in-memory mappings for any future reversible flow. Phase 3 intentionally kept the MVP simpler: persistent profile rules only, no per-run vault, no placeholder restoration, no local model provider, no sample learning, and no result-page quick add. Phase 3.5 adds sample learning and result-page quick add while preserving the explicit-save rule and avoiding raw sample persistence.
