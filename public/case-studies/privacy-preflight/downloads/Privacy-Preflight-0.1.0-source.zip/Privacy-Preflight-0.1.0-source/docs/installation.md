# Installation Guide

Privacy Preflight currently supports a development install flow.

## Backend Setup

```bash
cd services/worker
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -e ".[dev]"
```

Optional local OCR:

```bash
python -m pip install -e ".[dev,image-ocr]"
# Install the local Tesseract binary separately if using pytesseract.
```

## Run From Source

```bash
cd apps/macos
swift run PrivacyPreflightApp
```

The app starts the worker automatically when it can find `services/worker` and a usable Python environment. Manual worker startup is still available for debugging:

```bash
scripts/dev_worker.sh
```

## Build A Development App Bundle

```bash
scripts/build_macos_app.sh
```

Output:

```text
apps/macos/build/Privacy Preflight.app
```

Create a development zip:

```bash
scripts/package_macos_zip.sh
```

This app bundle is not notarized and does not bundle a Python runtime or dependency environment. It is suitable for local development and manual install testing only.

## Manual Install Test

1. Run `scripts/build_macos_app.sh`.
2. Open `apps/macos/build/Privacy Preflight.app`.
3. Confirm the worker status panel changes from starting to running.
4. Confirm the endpoint is `http://127.0.0.1:8765`.
5. Redact text, image, and PDF samples.
6. Quit the app and confirm the worker stops unless `PRIVACY_PREFLIGHT_KEEP_WORKER_ALIVE=1` is set.
7. Run `scripts/smoke_worker_lifecycle.sh` to check worker health and loopback binding.

## Uninstall

Remove the app bundle:

```bash
rm -rf "apps/macos/build/Privacy Preflight.app"
```

Remove local app data:

```bash
rm -rf "$HOME/Library/Application Support/Privacy Preflight"
```

Optional: remove model provider API keys from Keychain entries under service `Privacy Preflight Model Providers`.

Do not remove source files or virtual environments unless you no longer need the development checkout.
