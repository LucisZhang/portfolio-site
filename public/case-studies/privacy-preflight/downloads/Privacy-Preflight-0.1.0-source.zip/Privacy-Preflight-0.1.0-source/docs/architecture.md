# Architecture

Privacy Preflight is split into a macOS SwiftUI frontend and a local Python worker. The app is designed so sensitive content remains local unless a future user-controlled setting explicitly permits raw external sharing.

## Components

### macOS frontend

Responsibilities:

- Accept text, image, and PDF inputs.
- Display original and sanitized previews.
- Let users review, accept, reject, or adjust future redaction candidates.
- Start, stop, or connect to the local worker.
- Avoid storing raw content in persistent history by default.

The current frontend is a SwiftUI text and image workspace with local worker health, text input/output, highlighted source review, entity list, entity inspector, natural-language revision commands, PNG/JPEG image preview/export, OCR/redaction box overlays, simple manual image rectangles, profile settings, sample learning, and quick rule capture from selected result entities.

### macOS packaging and worker lifecycle future risk

The current frontend is a Swift Package scaffold, not a full installable `.app` bundle. A later packaging and app lifecycle phase must explicitly design and verify `.app` bundling, `Info.plist`, sandbox and privacy entitlements, app launch behavior, and local worker start/stop management.

This is intentionally not solved in Phase 0 or Phase 1 unless that phase is explicitly expanded. Until packaging is addressed, the SwiftUI frontend should be treated as a development scaffold rather than a distributable macOS app.

### Local worker

Responsibilities:

- Expose local HTTP endpoints on loopback only.
- Run deterministic detection and redaction locally.
- Store local profile rules under the app data directory.
- Return structured redaction candidates and sanitized output.
- Avoid logging raw request bodies.
- Validate model or detector outputs before applying them.

The worker exposes `GET /health`, profile CRUD endpoints, `POST /profile/learn-from-text`, model provider/settings endpoints, `POST /redact/text`, `POST /redact/image`, `POST /redact/text/review`, `POST /revision/parse`, `POST /redact/text/revise`, gateway settings/preview endpoints, and optional OpenAI-compatible `POST /v1/chat/completions` plus `GET /v1/models`. The text endpoint runs deterministic local regex redaction for common sensitive text patterns, local Chinese/mixed-language dictionary and address detection, local profile rules, and can optionally run Microsoft Presidio Analyzer as an additional local detector source. The image endpoint runs local OCR for PNG/JPEG files, maps OCR boxes through safe or precise redaction rules, and burns opaque rectangles into returned image pixels. The review endpoint runs the same redaction pipeline first, then optionally asks a configured model for structured JSON review suggestions. The revision endpoints parse user instructions into validated command objects, then apply those commands through deterministic exact-match candidates and the existing profile rule store. The gateway endpoint redacts supported chat message text locally before forwarding to the configured OpenAI-compatible upstream provider.

## Text redaction pipeline

Current text pipeline stages:

1. Detect obvious sensitive spans with deterministic regex rules.
2. Detect selected Chinese/mixed-language aliases, optional local dictionary terms, and obvious Chinese address spans locally.
3. Detect enabled profile rule matches from the local profile JSON.
4. Optionally detect broader PII spans with OpenAI Privacy Filter when configured and installed locally.
5. Optionally detect broader PII spans with local Presidio Analyzer when configured.
6. Resolve overlapping findings into stable, non-overlapping spans.
7. Apply replacement placeholders from the end of the text toward the beginning.
8. Return redacted text, structured entity metadata, and summary counts.

The Chinese detector layer is dependency-free by default. It loads a small built-in public seed dictionary, then an optional JSON dictionary from `PRIVACY_PREFLIGHT_DICTIONARY_PATH`. If the optional dictionary file is missing or invalid at runtime, the worker falls back to the built-in dictionary rather than failing startup. Local dictionary rules can define aliases, entity types, and replacement placeholders. Their source label is constrained to `user_dictionary` so they cannot impersonate internal regex, Presidio, or profile sources. The optional HanLP adapter boundary remains available for a future local model, but Phase 1.7 intentionally does not add HanLP, LAC, or LTP runtime integration.

The profile layer is a local JSON store at `~/Library/Application Support/Privacy Preflight/profile.json` by default, with `PRIVACY_PREFLIGHT_APP_DATA_DIR` and `PRIVACY_PREFLIGHT_PROFILE_PATH` overrides for development. Profile rules use `mask`, `ask`, and `allow`. Profile mask/ask candidates use `source = "profile"` and include `profile_rule_id` in redaction entities. Allow rules suppress ordinary overlapping detections but do not suppress high-risk deterministic API-key detections. The profile stores only user-managed rules, not submitted documents, sample text, redaction history, or placeholder-to-original mappings.

Profile sample learning is a read-only detector pass over pasted sample text. It returns candidate rule material for local review, but it does not save the profile or retain the sample. The macOS app persists candidates only when the user selects them and saves, using the same profile rule creation endpoint as manual rules and result-page quick actions.

OpenAI Privacy Filter is integrated as an optional detector, not a model review provider. It is a local token-classification/span model, so when enabled it contributes detector candidates with `source = "privacy_filter"`. The official runtime and checkpoint remain optional; normal worker tests and app startup do not require PyTorch or model weights.

The optional LLM review stage:

1. Loads the selected local or OpenAI-compatible review provider.
2. Sends original text only to providers marked local, unless external raw sharing is explicitly enabled.
3. Sends redacted-only content to non-local providers by default.
4. Requires structured JSON suggestions with pass/fail, risk, missed items, false positives, and policy suggestions.
5. Applies only valid exact-match missed-item suggestions as local detector candidates.
6. Re-runs conflict resolution and replacement so deterministic high-risk API-key detections remain protected.

The natural-language revision stage:

1. Accepts instructions such as masking a phrase, allowing a phrase, asking before masking a selected entity, changing a placeholder, or saving a term to the profile.
2. Uses a deterministic fallback parser when no model is configured.
3. Optionally uses the configured local model provider to parse intent into strict `RevisionCommand` JSON.
4. Skips external model parsing by default because the instruction itself can contain raw sensitive text. External parsing requires the same explicit raw-text opt-in used by review.
5. Applies validated commands by creating transient revision candidates for the current document or profile rules for persistent behavior.
6. Re-runs the existing conflict resolver, preserving profile allowlist suppression and high-risk regex API-key priority.

Future text pipeline stages:

1. Add custom local Presidio recognizers for domain-specific PII.
2. Add richer per-span review controls when the preview becomes editable.

Current image pipeline stages:

1. Accept PNG/JPEG bytes through the local worker.
2. Run OCR through a local provider abstraction (`auto`, macOS Vision, pytesseract/Tesseract, or disabled).
3. Return OCR text boxes with pixel-coordinate bounds and confidence metadata.
4. In safe mode, select every OCR text box for masking.
5. In precise mode, run each OCR box text through the existing text redaction pipeline and select only boxes with sensitive detections.
6. Include simple manual rectangles when supplied by the app.
7. Draw opaque black rectangles into image pixel data with Pillow.
8. Create a fresh pixel-only output image and re-encode PNG/JPEG bytes without copying EXIF, XMP, IPTC, GPS, camera, timestamp, software, thumbnail, comment, or other source metadata.

Current PDF pipeline stages:

1. Accept PDF bytes through the local worker.
2. Extract PDF text/structure with pypdf and map rendered character coordinates locally with pypdfium2/PDFium.
3. Detect text, scanned, and mixed PDFs based on text and image content.
4. Render page preview images for UI review.
5. Run the existing text pipeline on extractable PDF text and OCR text boxes.
6. Map detected text back to page rectangles and merge manual page rectangles.
7. Render the original page through PDFium and burn selected rectangles directly into the rendered pixels.
8. Rebuild a fresh image-only PDF with ReportLab.
9. Strip PDF metadata and avoid preserving source annotations, forms, embedded files, or text layers.
10. Verify exported files do not retain extractable redacted strings, a text layer, or unapplied redaction annotations.

Future PDF pipeline improvements:

1. Add richer manual region editing.
2. Improve rotated/complex text coordinate mapping.
3. Add configurable raster quality controls.
4. Add clearer OCR language setup in the UI.

## Model provider layer

The model provider layer is intentionally narrow. It supports:

- Ollama through its local `/api/chat`, `/api/generate`, and `/api/tags` endpoints.
- LM Studio through the OpenAI-compatible `/v1/chat/completions` and `/v1/models` path.
- A generic OpenAI-compatible chat completions provider.

Provider metadata is stored locally under the app data directory as human-readable JSON. API keys are not written to that JSON; on macOS they are stored in Keychain by provider id. The stored provider shape is limited to id, name, provider type, base URL, model, locality, JSON-mode support, timeout, max tokens, and API-key configured state.

The review settings are disabled by default and store the selected review provider plus `allow_raw_text_for_external_models`, which defaults to false. The same provider settings are reused for optional revision-command parsing; local providers may parse raw text and instructions, while external providers are skipped unless raw sharing is explicitly enabled. There is no model comparison workspace, provider expansion surface, routing proxy, or provider-specific OpenRouter, DashScope, or Gemini client.

## Local preflight gateway

The gateway is an optional compatibility surface for advanced users who want existing OpenAI-compatible clients or scripts to call Privacy Preflight first. It is disabled by default and is not a system proxy, browser extension, packet interceptor, or global traffic hook.

Gateway settings are stored locally beside model provider settings:

- `enabled`: defaults to false.
- `bind_host`: defaults to `127.0.0.1`.
- `port`: defaults to the development worker port, `8765`.
- `upstream_provider_id`: references an existing model provider.
- `allow_raw_text_to_upstream`: defaults to false.
- `redact_request_messages`: defaults to true.

Request flow:

1. A compatible client sends a non-streaming `POST /v1/chat/completions` request to the local worker.
2. The worker loads gateway settings and the configured upstream provider.
3. The worker rejects disabled gateway use, missing upstream providers, streaming requests, unsupported message content, or redaction failures before any upstream call.
4. The worker redacts string message content and basic multipart `{"type": "text"}` parts with the normal text pipeline.
5. The worker preserves roles and other supported request fields, replaces the request model with the configured upstream model, and forwards the redacted request through the OpenAI-compatible provider path.
6. The worker returns the upstream response to the client. If `privacy_preflight_debug: true` is present in the local request, the response also includes a local-only redaction summary; this field is removed before forwarding upstream.

`POST /gateway/preview` runs the same request transformation but never forwards upstream. It returns the exact request body that would be forwarded plus redaction metadata that omits raw detected text. This supports local inspection without storing prompts.

Streaming, multimodal passthrough, provider routing, virtual keys, audit ledgers, tokenization services, placeholder restoration, model comparison, and provider-specific gateway clients remain intentionally out of scope.

## PDF safety constraints

PDF redaction must remove recoverable sensitive content. Drawing a black rectangle over text is not sufficient.

Future PDF export must account for:

- Text layers.
- Embedded images.
- Invisible or clipped objects.
- Metadata.
- Annotations and attachments.
- Search, copy/paste, and accessibility extraction.

The current PDF MVP uses a destructive image-only export. It does not claim legal-grade redaction.

## Privacy constraints

- Bind worker services to loopback by default.
- Do not log raw text, images, PDFs, or filenames unless the user explicitly enables diagnostic logging.
- Do not store raw content in history by default.
- Store profile rules locally, but do not store submitted samples, redaction histories, or placeholder-to-original mappings.
- Keep reversible redaction mappings in memory unless a future encrypted vault design is explicitly added.
- Use deterministic detectors for obvious sensitive data before any model review or revision, and validate model suggestions before applying them.
- The gateway must fail closed if redaction fails and must not forward unsupported content unless a future explicit passthrough setting is designed.
