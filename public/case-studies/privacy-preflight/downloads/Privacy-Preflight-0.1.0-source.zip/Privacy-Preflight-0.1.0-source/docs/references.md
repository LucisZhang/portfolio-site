# Reference Findings

This file records reference projects checked before Phase 0 implementation. The project uses these references for architecture and safety patterns only. No large code blocks were copied.

## RedactDesk

- URL: https://github.com/RedactDesk/redactdesk-mac
- License: MIT for code. The RedactDesk name and icon are trademarked separately.
- Relevant findings:
  - macOS-first local redaction app focused on keeping PDFs on-device.
  - Separates model/runtime, PDF pipeline, orchestration, and UI layers.
  - Emphasizes permanent PDF redaction rather than visual overlays.
  - Current scope is text-based PDFs, with OCR planned separately.
- Reused conceptually:
  - Local-only default posture.
  - Clear frontend/orchestration/worker boundaries.
  - Future caution that PDF export must remove underlying content.
- Intentionally not reused:
  - No RedactDesk code, trademark, app naming, PDF pipeline, ONNX model integration, or packaging structure.
  - Phase 0 does not implement PDF redaction.

## Microsoft Presidio

- URL: https://github.com/microsoft/presidio
- Documentation: https://microsoft.github.io/presidio/
- License: MIT.
- Relevant findings:
  - Presidio separates analysis from anonymization.
  - Analyzer design uses recognizers, recognizer results, registries, NLP engines, and context enhancement.
  - Anonymizer design applies configurable operators such as redact, replace, hash, or encrypt to detected spans.
- Reused conceptually:
  - Future backend module boundary between detection and redaction.
  - Structured span-like results instead of ad hoc text replacement.
  - Extensible recognizer pipeline.
- Intentionally not reused:
  - Presidio dependency is not added in Phase 0.
  - No NLP model, recognizer registry, or anonymizer operator implementation is included yet.

## doc_redaction

- URL: https://github.com/seanpedrick-case/doc_redaction
- License: AGPL-3.0-only according to its project metadata.
- Relevant findings:
  - Covers PDF/image documents, Word files, and tabular data.
  - Uses a GUI review flow and produces review artifacts.
  - Supports local OCR/PDF processing paths, with optional external services.
  - Warns that automated redaction can miss personal information and final outputs need human review.
- Reused conceptually:
  - Human review remains a required product workflow.
  - Document processing should be staged so extraction, detection, review, and export are separable.
  - Optional external services must be gated by configuration.
- Intentionally not reused:
  - No code or dependencies are reused because AGPL-3.0-only is a strong license constraint for this project.
  - No Gradio UI, OCR stack, AWS integration, PyMuPDF flow, or document pipeline is added in Phase 0.

## LLM Guard

- URL: https://github.com/protectai/llm-guard
- Documentation: https://protectai.github.io/llm-guard/
- License: MIT.
- Relevant findings:
  - Uses modular input and output scanners around LLM calls.
  - Anonymization can replace sensitive values with placeholders.
  - Deanonymization uses a Vault object to map placeholders back to originals when appropriate.
- Reused conceptually:
  - Future LLM review should operate on sanitized prompts by default.
  - Placeholder mappings should have a scoped vault-like lifecycle.
  - Input and output model checks should be separate stages.
- Intentionally not reused:
  - LLM Guard is not added as a dependency in Phase 0.
  - No model scanning, prompt injection detection, or vault implementation is included yet.

## Phase 0 conclusions

- Keep the repository scaffold small and testable.
- Build the local worker API now, but keep the redaction engine behind future module boundaries.
- Design documentation should explicitly warn that PDF redaction must remove content, not merely hide it.
- Avoid AGPL-licensed code reuse unless the whole project licensing strategy intentionally allows it.

## Phase 1 text redaction reference refresh

Reviewed again before implementing the deterministic text redaction backend MVP.

### Microsoft Presidio

- Documentation checked: https://microsoft.github.io/presidio/analyzer/ and https://microsoft.github.io/presidio/anonymizer/
- Relevant findings:
  - Analyzer design centers on recognizers that return span-based recognizer results with entity type, start, end, and score.
  - Regex recognizers are first-class through `PatternRecognizer`, and custom recognizers can be registered later.
  - Anonymizer design receives analyzer results separately from text and applies configurable operators such as replace, mask, redact, encrypt, or keep.
  - Overlap handling is explicit. Larger containing spans are preferred for contained entities, and higher scores decide full overlaps.
- Reused conceptually:
  - Detector outputs are span-based candidates with type, offsets, confidence, source, and reason.
  - Detection is separate from replacement so Presidio can later be introduced as another detector source.
  - Replacement is represented as an operator-like `action` plus `replacement`.
- Intentionally not reused:
  - No Presidio package, NLP engine, recognizer registry, anonymizer engine, or operator code is added in Phase 1.
  - No Presidio cloud service or Docker service is used.

### LLM Guard

- Documentation checked: https://protectai.github.io/llm-guard/get_started/quickstart/ and https://protectai.github.io/llm-guard/input_scanners/anonymize/
- Relevant findings:
  - Scanners can be composed and run in sequence around prompts and model outputs.
  - The anonymization scanner sanitizes prompts before model calls and can use a scoped `Vault` for reversible placeholder mapping.
  - LLM Guard extends Presidio-style detection with custom patterns for emails, URLs, IPs, UUIDs, and other entity classes.
- Reused conceptually:
  - The worker uses a scanner-like detector boundary and a mode switch for stricter matching.
  - Sanitization remains a local pre-model step, preserving the future rule that external models should receive redacted text by default.
- Intentionally not reused:
  - No LLM Guard dependency, vault, deanonymization scanner, model scanner, or output scanner is added in Phase 1.
  - Reversible placeholder storage is deferred because it needs a separate privacy and retention design.

## Phase 1 conclusions

- Keep deterministic regex detection as the first local stage.
- Preserve original offsets in returned entities so the UI can review spans against the source text.
- Resolve overlaps before replacement and apply replacements from the end of the text.
- Treat `strict` mode as higher recall with more false-positive risk.
- Defer Presidio, LLM review, vault/deanonymization behavior, image support, and PDF support to later phases.

## Phase 1.5 Presidio integration reference refresh

Reviewed before adding Microsoft Presidio as an optional detector source.

### Microsoft Presidio Analyzer and Anonymizer

- Documentation checked:
  - https://microsoft.github.io/presidio/analyzer/
  - https://microsoft.github.io/presidio/analyzer/adding_recognizers/
  - https://microsoft.github.io/presidio/samples/python/presidio_notebook/
  - https://microsoft.github.io/presidio/tutorial/05_languages/
  - https://github.com/microsoft/presidio/blob/main/presidio-analyzer/presidio_analyzer/recognizer_result.py
- License: MIT.
- Relevant findings:
  - Presidio Analyzer runs multiple recognizers through `AnalyzerEngine`.
  - `RecognizerRegistry` owns the configured recognizers. Recognizers can be loaded with `load_predefined_recognizers()` and custom recognizers can be added with `registry.add_recognizer(...)`.
  - `RecognizerResult` contains the fields this project needs for span detection: `entity_type`, `start`, `end`, and `score`, plus optional recognizer metadata.
  - Presidio Anonymizer is a separate step. It receives the original text and analyzer results and applies operators such as replace, redact, mask, hash, and encrypt.
  - Presidio supports multiple languages through configured NLP engines and models, but models must be installed locally and coverage varies by language.
- Reused conceptually:
  - Presidio is integrated only at the detector boundary. The worker maps each `RecognizerResult` into a local `DetectionCandidate`.
  - `RecognizerResult.entity_type` maps to `RedactionEntity.type`, with local aliases for overlapping entity classes: `EMAIL_ADDRESS` to `EMAIL` and `PHONE_NUMBER` to `PHONE`.
  - `RecognizerResult.start` and `RecognizerResult.end` become original-offset `RedactionEntity.start` and `RedactionEntity.end`.
  - `RecognizerResult.score` becomes `RedactionEntity.confidence`.
  - Presidio-derived entities use `source = "presidio"`.
  - Optional recognizer metadata is used only for non-raw explanatory text, such as the recognizer name.
- Custom recognizer path:
  - Later custom recognizers can be registered by creating a Presidio `PatternRecognizer` or local `EntityRecognizer` and passing it into `PresidioDetector(recognizers=[...])`, or by constructing an `AnalyzerEngine` with a prepared registry and injecting that analyzer into `PresidioDetector`.
  - YAML-defined recognizers remain a possible future configuration format, but Phase 1.5 keeps configuration code-based and local.
- Intentionally not reused:
  - Presidio Anonymizer is not used because the existing pipeline already performs deterministic replacement after resolving conflicts across all detector sources.
  - Presidio remote recognizers are not used because they can call external services and would violate the local-first default.
  - Presidio LLM/SLM recognizers are not added in this phase.
  - Presidio does not replace the existing regex detectors; it is one source among several.
- Chinese and mixed Chinese/English limitations:
  - The initial integration defaults to English (`PRIVACY_PREFLIGHT_PRESIDIO_LANGUAGE=en`) and does not install or configure Chinese NLP models.
  - Built-in English recognizers may still catch Latin-script emails, phone numbers, URLs, and some English names in mixed text, but Chinese names, schools, addresses, or organizations should not be assumed to be covered.
  - Future Chinese support needs explicit local model selection, evaluation data, and likely custom recognizers for Chinese-specific personal, school, address, and ID patterns.

## Phase 1.5 conclusions

- Keep regex detectors enabled by default and load Presidio only when configured.
- Preserve the existing local replacement pipeline instead of delegating anonymization to Presidio.
- Protect regex API-key detections from being replaced by broader Presidio spans.
- Disable `tldextract` public suffix list fetching in the Presidio path so email validation uses its bundled snapshot instead of making runtime network calls.
- Keep Presidio optional because it adds model/package requirements and language-specific setup.

## Phase 1.6 Chinese NER and mixed-language detector research

Reviewed before adding Chinese and mixed-language detector adapters.

### HanLP

- Project URL: https://github.com/hankcs/HanLP
- License:
  - Code: Apache License 2.0.
  - Models: generally CC BY-NC-SA 4.0 unless otherwise specified by a model.
- Install complexity on macOS:
  - `pip install hanlp` is simple at the command level, but runtime dependencies are heavy because HanLP is built around PyTorch/TensorFlow-era NLP models.
  - Apple Silicon and newer Python versions may need dependency pinning.
- Model download requirements:
  - Native local inference needs a model downloaded ahead of runtime.
  - HanLP also offers REST APIs, but those are not acceptable for this local-first pipeline.
- Local inference:
  - Supported through native Python APIs when a local model path is available.
- Span output:
  - HanLP NER outputs structured NER items. Exact offset conventions vary by model/task output, so the adapter validates char offsets and falls back to locating the emitted entity string in the input.
- Entity types:
  - Depends on selected model and corpus. Common outputs include person, organization, location, and corpus-specific labels.
- Dependency/runtime cost:
  - High. Useful for a future optional advanced mode, not a default MVP dependency.
- MVP suitability:
  - Suitable as an optional adapter behind a local model path.
  - Not suitable as the default because model licenses are often non-commercial and model downloads are large.

### Baidu LAC

- Project URL: https://github.com/baidu/lac
- License: Apache License 2.0.
- Install complexity on macOS:
  - Advertises `pip install lac`, but the project is older and Paddle/native binary compatibility needs verification on current macOS/Python versions.
- Model download requirements:
  - Package includes/uses local lexical analysis models; no external API is required after install.
- Local inference:
  - Supported through Python, Java, C++, and Android interfaces.
- Span output:
  - Returns token lists and tags rather than direct character spans. A Privacy Preflight adapter would need to reconstruct offsets by scanning token text back into the original string.
- Entity types:
  - The README lists `PER`, `LOC`, `ORG`, and `TIME` as common named-entity tags.
- Dependency/runtime cost:
  - Medium, but with aging dependency risk.
- MVP suitability:
  - Future fallback candidate if HanLP model licensing or size blocks users.
  - Not integrated in Phase 1.6 because dictionary/address coverage gives deterministic value without a Paddle dependency.

### HIT LTP / N-LTP

- Project URL: https://github.com/HIT-SCIR/ltp
- License:
  - The README states free source use for universities/research institutes/personal researchers and paid use for commercial enterprise contexts.
  - This is not a standard permissive OSS license for a commercial Mac app default.
- Install complexity on macOS:
  - Requires `torch`, `transformers`, `ltp`, `ltp-core`, and `ltp-extension`; Rust/native extension compatibility must be verified per Python/macOS version.
- Model download requirements:
  - Defaults to downloading models from Hugging Face. Local paths are supported if models are downloaded ahead of runtime.
- Local inference:
  - Supported when using local model folders.
- Span output:
  - Pipeline returns Chinese word segmentation, POS, and NER structures; offsets require reconstruction from segmented tokens.
- Entity types:
  - Chinese lexical analysis NER, with common person/location/organization-style labels depending on model.
- Dependency/runtime cost:
  - High for deep learning models; legacy mode is faster but still model/package heavy.
- MVP suitability:
  - Future reference only for this product unless licensing is clarified.

### Chinese address parsing projects

- Project URLs:
  - Neural Chinese Address Parsing: https://github.com/leodotnet/neural-chinese-address-parsing and paper https://aclanthology.org/N19-1346/
  - addressparser: https://github.com/shibing624/addressparser
- License:
  - Neural Chinese Address Parsing: no explicit GitHub license was visible during review, so code reuse is not appropriate.
  - addressparser: GitHub shows MIT license. Some package mirrors contain conflicting metadata, so this should be rechecked before dependency adoption.
- Install complexity on macOS:
  - Neural Chinese Address Parsing requires older Dynet-era setup and is research-code oriented.
  - addressparser is a small Python package but returns structured region parsing rather than general text NER.
- Model download requirements:
  - Neural Chinese Address Parsing includes data/research artifacts but is not packaged as a simple local inference library.
  - addressparser is dictionary/data based and does not need model downloads.
- Local inference:
  - Both are local in principle.
- Span output:
  - Neural Chinese Address Parsing models semantic address chunks.
  - addressparser outputs province/city/district/address components and positions for some modes, but it is not a direct arbitrary-text span detector.
- Entity types:
  - Address-specific labels such as province, city, district, road, road number, house number, POI, room number.
- Dependency/runtime cost:
  - Neural parser: high and research-oriented.
  - addressparser: low-to-medium, with pandas/data dependency implications.
- MVP suitability:
  - Phase 1.6 uses a conservative address marker detector instead of adding a dependency.
  - addressparser is worth revisiting for structured address normalization after the UI review layer exists.

### CLUENER2020 and awesome-chinese-ner references

- Project URLs:
  - CLUENER2020: https://github.com/CLUEbenchmark/CLUENER2020
  - awesome-chinese-ner: https://github.com/taishan1994/awesome-chinese-ner
- License:
  - CLUENER2020: no explicit GitHub license was visible during review; treat as dataset/model reference, not copied code.
  - awesome-chinese-ner: no explicit GitHub license was visible during review; treat as curated reference only.
- Install complexity on macOS:
  - CLUENER includes baseline model code, not a production package.
  - awesome-chinese-ner is a link collection.
- Model download requirements:
  - CLUENER baselines require model setup/training or pretrained checkpoints.
  - awesome-chinese-ner points to many external models; each must be evaluated separately.
- Local inference:
  - Possible for models trained on CLUENER-style labels, but no runtime package is provided by the dataset itself.
- Span output:
  - CLUENER labels include explicit start/end indices in its JSON format.
- Entity types:
  - CLUENER labels include address, book, company, game, government, movie, name, organization, position, and scene.
- Dependency/runtime cost:
  - Depends on selected baseline/model; usually BERT-class and heavy.
- MVP suitability:
  - Dataset/model reference only in Phase 1.6.
  - Useful for future evaluation because its labels map well to Privacy Preflight types such as `PERSON`, `COMPANY`, `ORGANIZATION`, `ADDRESS`, and `LOCATION`.

## Phase 1.6 conclusions

- Use `dictionary_only` as the production default because it is deterministic, local, fast, dependency-free, and enough to cover known bilingual school aliases without training.
- Add a HanLP adapter boundary for future optional local model use, but require a local model path and keep the dependency optional because HanLP model downloads are large and many models are non-commercial.
- Do not integrate LAC or LTP yet. LAC is plausible but aging; LTP has commercial-use constraints and heavier dependencies.
- Do not integrate addressparser yet. The immediate need is redaction span detection; structured address normalization belongs in a later review/export phase.
- Keep Chinese address matching conservative to reduce false positives until the UI can review and correct entity decisions.

## Phase 1.7 configurable dictionary reference refresh

Reviewed before adding configurable local dictionaries and Chinese evaluation fixtures.

### References reused from Phase 1.6

- HanLP, Baidu LAC, HIT LTP/N-LTP, Chinese address parsing projects, CLUENER2020, and awesome-chinese-ner remain the relevant Chinese NER references.
- No new NLP runtime reference was adopted in Phase 1.7 because the user explicitly requested no real HanLP/LAC/LTP integration in this phase.

### Relevant findings

- The Phase 1.6 research still supports a dependency-free `dictionary_only` default for MVP work: it is local, deterministic, testable, and avoids model license/download/runtime risk.
- CLUENER2020's explicit span labels remain useful conceptually for evaluation fixtures, but Phase 1.7 uses small hand-authored fixtures instead of importing any dataset or trained model.
- Presidio's separation between detector results and replacement remains useful for local dictionary rules: dictionary matches are detector candidates with type, source, confidence, and optional replacement metadata.

### Reused conceptually

- Span-based detector outputs with stable entity types.
- Fixture-style evaluation that checks expected entity types and redacted output without training or calling external services.
- Explicit source labels so UI review can distinguish regex, built-in Chinese dictionary, user dictionary, Presidio, and future providers.

### Intentionally not reused

- No HanLP, LAC, LTP, addressparser, CLUENER model, or awesome-chinese-ner model code is added.
- No model downloads are required at runtime.
- No profile-learning or UI-backed dictionary editor is added in Phase 1.7.
- No broad default production dictionary of personal, company, or school assumptions is added beyond the small public seed terms already documented in Phase 1.6.

## Phase 1.7 conclusions

- Add a local JSON dictionary format with rule ids, entity types, exact patterns/aliases, replacements, enable flags, and a constrained `user_dictionary` source label.
- Load built-in public entries first, then an optional local dictionary file from `PRIVACY_PREFLIGHT_DICTIONARY_PATH`.
- Keep future allowlist/profile suppression compatible with the existing conflict-resolution stage.
- Validate dictionary shape with safe error messages that identify the invalid rule and field without echoing pattern values or document text.
- Keep heavy Chinese NER providers optional and deferred until after the UI can review and correct detections.

## Phase 2 SwiftUI text workspace reference refresh

Reviewed before connecting the macOS SwiftUI app to the local worker.

### RedactDesk

- URL: https://github.com/RedactDesk/redactdesk-mac
- Files inspected:
  - `README.md`
  - `PII Redactor/RootView.swift`
  - `PII Redactor/DocumentView.swift`
  - `PII Redactor/EntitySidebar.swift`
- License: MIT for code. The RedactDesk name and icon are trademarked separately.
- Relevant findings:
  - The product keeps the main workspace direct: a primary document/review area, visible local processing status, and a separate detection review surface.
  - The README emphasizes on-device processing, no telemetry, and durable redaction rather than visual-only masking.
  - The app is organized by clear UI, orchestration, model runtime, and document pipeline layers.
  - The entity review area groups detections and shows counts, letting users inspect what was found without hiding operational state.
- Reused conceptually:
  - Keep worker readiness visible in the primary toolbar area.
  - Use a focused workspace instead of a marketing-style landing screen.
  - Show detection counts and a reviewable entity list separately from the redacted output.
  - Keep the UI honest about failure states instead of appearing idle when local processing is unavailable.
- Intentionally not reused:
  - No RedactDesk UI code, design system, branding, trademarked assets, PDF canvas, PDF redaction pipeline, model download flow, ONNX runtime, onboarding sheet, category toggle behavior, or export workflow is reused.
  - Phase 2 remains text-only and manually connects to the existing FastAPI worker. It does not implement PDF support, app packaging, worker lifecycle management, model providers, image/PDF redaction, or highlight rendering.

## Phase 2 conclusions

- The SwiftUI app should call the existing `/redact/text` schema directly rather than creating a frontend-only schema.
- The first usable macOS workspace should prioritize paste, redact, review, and copy.
- Worker startup stays manual in this phase, so the app needs an understandable offline state and retryable health check.
- Entity review should include the detected local span, type, source, replacement, confidence, and counts by type, while advanced highlight rendering remains deferred.

## Phase 2.5 highlight preview and entity inspector reference refresh

Reviewed before adding text span highlighting and selection-driven entity inspection.

### RedactDesk

- URL: https://github.com/RedactDesk/redactdesk-mac
- Files inspected:
  - `PII Redactor/PDFCanvasView.swift`
  - `PII Redactor/EntitySidebar.swift`
- License: MIT for code. The RedactDesk name and icon are trademarked separately.
- Relevant findings:
  - RedactDesk keeps detections reviewable through a sidebar list and a focused visual preview.
  - Clicking a detection focuses the preview on the corresponding span.
  - Preview markings are rebuilt from structured span metadata rather than inferred from rendered text.
  - Detection rows carry enough context to support later review actions without mixing those actions into the first-pass scan.
- Reused conceptually:
  - Selection state links the entity list to the preview.
  - Preview rendering is derived from backend span offsets and entity metadata.
  - Detection details stay in a separate inspector so the source/output editors remain simple.
- Intentionally not reused:
  - No RedactDesk code, PDFKit annotation layer, PDF canvas, category toggle system, export workflow, design system, or branding is reused.
  - Phase 2.5 uses a SwiftUI read-only attributed text preview instead of editable rich text or PDF annotations.
  - No profile rule capture, allowlist/mask actions, sample learning, or onboarding flow is added.

## Phase 2.5 conclusions

- Keep highlight preview read-only and derived from the original source snapshot used for the latest redaction run.
- Preserve backend offsets as the source of truth for highlighted spans.
- Selectable entity rows should drive both the highlighted span focus and the inspector details.
- Reserve the inspector surface for future per-entity rule actions, but do not expose those actions before the profile design exists.
- Treat backend offsets as Python Unicode code point offsets. Swift clients should map them through `String.unicodeScalars`, validate the mapped substring against `entity.text`, and skip unsafe highlights with a visible diagnostic.

## Phase 3 profile rule reference refresh

Reviewed before adding local profile rule management.

### LLM Guard anonymization and vault flow

- Documentation checked:
  - https://protectai.github.io/llm-guard/input_scanners/anonymize/
  - https://protectai.github.io/llm-guard/output_scanners/deanonymize/
- License: MIT for LLM Guard.
- Relevant findings:
  - Anonymization is modeled as an input scanner that detects PII before the model call and replaces it with typed placeholders.
  - It can use Presidio, extra patterns, custom regex groups, configured entity types, thresholds, and model recognizers.
  - Deanonymization uses the same Vault object to map placeholders back to original values after a model response.
  - The vault concept is scoped to the model interaction and should not become a casual persistent store of raw sensitive values.
- Reused conceptually:
  - Profile rules use explicit typed replacement labels such as `[SCHOOL]`, `[CLIENT]`, or `[PROJECT]`.
  - The worker keeps detector output and replacement application centralized rather than embedding redaction inside each detector.
  - Future model review should use a scoped in-memory mapping if reversible placeholder restoration is ever added.
- Intentionally not reused:
  - No LLM Guard dependency, scanner runtime, model recognizer, reversible vault, or deanonymization flow is added in Phase 3.
  - Profile storage does not persist original document/sample text or per-redaction placeholder mappings.

### Cherry Studio PII redaction proposal

- URL: https://github.com/CherryHQ/cherry-studio/issues/14910
- License context: Cherry Studio Community Edition is AGPL-3.0; the issue was used only as a product/reference concept.
- Relevant findings:
  - The proposal redacts outgoing messages before cloud LLM transmission using local PII detection.
  - It uses typed, numbered placeholders such as `[NAME_1]`, `[ID_NUMBER_1]`, `[PHONE_1]`, and `[ADDRESS_1]`.
  - It proposes previewing detected entities before sending and letting users override specific detections.
  - It keeps placeholder-to-original mappings local, in memory, and scoped to a conversation.
  - It explicitly excludes direct image/PDF attachment redaction from that text-only capability.
- Reused conceptually:
  - Phase 3 keeps a settings-managed profile with explicit mask, ask, and allow actions.
  - The entity inspector now exposes profile source and rule id when available so user-defined detections are explainable.
  - The `ask` action returns a reviewable entity while still producing a safe placeholder in `redacted_text`.
- Intentionally not reused:
  - No AGPL code, local model tier, conversation vault, placeholder restoration, input-bar shield flow, attachment redaction, or result-page quick-add UI is reused.
  - Numbered per-message placeholders are deferred because this phase stores reusable rules, not per-run reversible mappings.

## Phase 3 conclusions

- Keep profile storage simple, local, and human-readable under the app data directory.
- Reuse the existing dictionary-like JSON structure where possible: `id`, `label`, `entity_type`, `patterns`, `aliases`, `replacement`, `enabled`, and source-style attribution.
- Use profile actions `mask`, `ask`, and `allow`; continue to avoid remove/delete as a primary text action.
- Do not persist sample text, redaction histories, or placeholder-to-original mappings.
- Let explicit allow rules suppress ordinary overlapping detections, but keep high-risk deterministic secret/API-key detections protected.

## Phase 3.5 profile learning and quick capture reference refresh

Reviewed before adding sample-driven profile learning and result-page quick rule capture. No new dependencies or source-code reuse were added.

### References reused from Phase 2.5 and Phase 3

- RedactDesk remains the relevant macOS review reference for keeping detections selectable in a result list with an adjacent inspector. Phase 3.5 keeps row selection as the primary reviewed-entity action path and does not reuse RedactDesk PDF annotation or canvas code.
- Microsoft Presidio remains the detector-boundary reference. Phase 3.5 maps existing local detector candidates into profile-rule suggestions rather than adding Presidio Anonymizer or recognizer registry changes.
- LLM Guard's anonymization/vault flow continues to inform the privacy boundary: typed placeholders are useful, but raw sample text and reversible mappings should not become persistent state.
- Cherry Studio's PII redaction proposal remains a product concept reference for preview-before-send behavior and explicit user overrides. No AGPL code or provider integration is reused.

### Reused conceptually

- Learning runs the same detector stack used by redaction so suggestions stay explainable through source, confidence, and reason fields.
- Profile context participates in learning so existing mask/ask rules do not create duplicate suggestions and allow rules suppress ordinary candidates.
- Candidate saving is explicit and uses the existing profile-rule create path; no learned rule is auto-saved.
- Result-page quick actions live in the inspector, where the selected entity already has type, source, replacement, confidence, span, and reason context.

### Intentionally not reused or added

- No LLM, model comparison, cloud provider, prompt review loop, or external enrichment is added.
- No raw sample text persistence, redaction history, or placeholder-to-original vault is added.
- No rich text editor or direct click-to-select highlighted spans is added; row selection remains the reliable accessible path for Phase 3.5.
- No large reference code blocks are copied.

## Phase 3.5 conclusions

- Add `POST /profile/learn-from-text` as a read-only local detector pass that returns candidate rule fields only.
- Keep candidate persistence behind explicit user action through `POST /profile/rules`.
- Add a Profile settings `Learn` tab for sample text, candidate selection, and selected-candidate saves.
- Add inspector quick actions for mask, ask, allow, and editable pattern capture from the selected result entity.
- Preserve offset-safe highlight behavior and document direct highlighted-span selection as deferred.

## Phase 4 narrow model provider and LLM review reference refresh

Reviewed before adding the intentionally narrow provider layer and optional redaction review loop.

### LLM Guard anonymization, deanonymization, and scanner boundary

- Documentation checked:
  - https://protectai.github.io/llm-guard/input_scanners/anonymize/
  - https://protectai.github.io/llm-guard/output_scanners/deanonymize/
- License: MIT.
- Relevant findings:
  - LLM Guard treats anonymization as a scanner that sanitizes prompts before model calls.
  - It combines Presidio-style entity recognition, custom regex patterns, thresholds, configured entity types, and typed placeholders.
  - Deanonymization is a distinct output scanner using a scoped Vault for placeholder restoration.
  - The Vault pattern is useful, but it is also sensitive state and should not casually become durable app storage.
- Reused conceptually:
  - Privacy Preflight keeps deterministic local redaction before model review.
  - The review prompt receives redacted text by default for non-local providers.
  - Model output is treated as a scanner-style suggestion layer, not as authoritative redaction output.
- Intentionally not reused:
  - No LLM Guard dependency, model recognizer, deanonymization scanner, prompt-injection scanner, or reversible Vault is added.
  - Phase 4 does not restore placeholders into model responses because the product is reviewing redaction results, not proxying user conversations.

### Local LLM proxy and anonymization projects

- References checked:
  - Philterd / Philter AI Proxy: https://philterd.ai/
  - llm-sentinel: https://github.com/raaihank/llm-sentinel
  - Anonamoose: https://docs.anonamoose.net/
  - Additional market scan items included Grepture, OpenGuard, and related OpenAI-compatible proxy/gateway patterns.
- License and dependency notes:
  - Philterd projects are described as Apache-licensed in their public docs, but no code is reused.
  - llm-sentinel and Anonamoose were used only as architecture references; no dependency or code integration was added.
- Relevant findings:
  - Proxy projects commonly sit in front of OpenAI-compatible APIs, redact or mask before egress, and optionally restore placeholders later.
  - Useful guardrails include redacted-by-default cloud forwarding, provider reachability tests, no raw content logging, API-key isolation, and treating policy decisions as explicit configuration.
  - Some proxies add routing, audit logs, replay, comparison, or provider marketplaces. Those are broader than this phase and increase privacy and product surface area.
- Reused conceptually:
  - Provider configuration uses a small OpenAI-compatible shape: base URL, model, timeout, max tokens, JSON-mode support, and locality.
  - External/generic providers are considered non-local unless explicitly marked otherwise.
  - Provider errors returned to the UI avoid upstream response bodies and secrets.
- Intentionally not reused:
  - No proxy server, conversation forwarding gateway, audit ledger, tokenization service, replay log, routing layer, semantic router, or provider marketplace is added.
  - No raw prompt/response recording is added.

### Cherry Studio PII redaction proposal

- URL: https://github.com/CherryHQ/cherry-studio/issues/14910
- License context: Cherry Studio Community Edition is AGPL-3.0; the issue was used only as a product/reference concept.
- Relevant findings:
  - The proposal centers local detection before cloud transmission.
  - It uses typed placeholders, pre-send preview, user overrides, and an in-memory placeholder mapping scoped to a conversation.
  - It explicitly separates text redaction from direct multimodal attachment redaction.
- Reused conceptually:
  - The macOS app exposes model settings separately from the redaction workspace and warns when review uses an external provider.
  - The review path keeps original text local by default for non-local providers and only sends original text externally with explicit opt-in.
  - The review output is visible as review metadata rather than silently rewriting the user text.
- Intentionally not reused:
  - No AGPL code, Cherry Studio UI code, conversation plugin flow, numbered per-message placeholder mapping, placeholder restoration, or attachment redaction is reused.

### Ollama and LM Studio provider API references

- Ollama documentation checked:
  - https://docs.ollama.com/api/introduction
  - https://docs.ollama.com/api/chat
  - https://docs.ollama.com/api/generate
- LM Studio documentation checked:
  - https://lmstudio.ai/docs/developer/openai-compat/chat-completions
- Relevant findings:
  - Ollama's local API defaults to `http://localhost:11434/api`, with `/api/chat`, `/api/generate`, and `/api/tags`.
  - Ollama supports non-streaming calls and JSON/JSON-schema response formats through its `format` option.
  - LM Studio exposes OpenAI-compatible chat completions at `http://localhost:1234/v1`, including `messages`, `temperature`, `max_tokens`, and `stream`.
- Reused conceptually:
  - Ollama uses `/api/chat` with `/api/generate` fallback and `/api/tags` for provider testing.
  - LM Studio uses the generic OpenAI-compatible chat-completions path and model list test path.
- Intentionally not reused:
  - No provider SDKs are added. The worker uses minimal HTTP calls through `httpx`.

## Phase 4 conclusions

- Keep provider support intentionally narrow: Ollama, LM Studio through the OpenAI-compatible path, and one generic OpenAI-compatible provider type.
- Store provider metadata locally in JSON, but keep API keys out of that JSON and use macOS Keychain for secrets.
- Keep model review optional and disabled by default.
- Local providers may receive original text. Non-local providers receive redacted-only review input by default.
- External raw-text review requires the explicit `allow_raw_text_for_external_models` setting and emits a warning in the review result/UI.
- The LLM response must be structured JSON. The worker validates it, ignores free-form rewrites, applies only exact-match missed-item suggestions, and re-runs the deterministic conflict resolver so high-risk regex API-key detections are not weakened.
- Do not add model comparison, provider marketplace, routing/proxy behavior, OpenRouter-specific support, DashScope-specific support, Gemini-specific support, raw prompt logging, or placeholder restoration.

## Phase 4.1 OpenAI Privacy Filter detector reference refresh

Reviewed before adding the optional OpenAI Privacy Filter detector adapter.

### OpenAI Privacy Filter

- Repository: https://github.com/openai/privacy-filter
- Model weights: https://huggingface.co/openai/privacy-filter
- Transformers documentation: https://huggingface.co/docs/transformers/model_doc/openai_privacy_filter
- Model card PDF: https://cdn.openai.com/pdf/c66281ed-b638-456a-8ce1-97e9f5264a90/OpenAI-Privacy-Filter-Model-Card.pdf
- OpenAI launch post: https://openai.com/index/introducing-openai-privacy-filter/
- License: Apache-2.0.
- Model size and runtime:
  - The model card and repository describe a 1.5B-parameter model with about 50M active parameters.
  - The Hugging Face model page lists about 1B parameters and F32/BF16 safetensors.
  - The official local package is PyTorch-based and depends on `huggingface_hub`, `numpy`, `packaging`, `torch`, `safetensors`, and `tiktoken`.
  - Official usage installs the package from the repository with `pip install -e .` and exposes an `opf` CLI plus Python API.
- macOS / Apple Silicon feasibility:
  - Official code supports CPU and CUDA device options. CPU should run on Apple Silicon but may be slow for interactive redaction.
  - The official runtime does not advertise a native MPS/MLX backend in the core repository.
  - Community MLX/quantized variants exist, but Phase 4.1 does not depend on or trust those variants by default.
- Local inference:
  - The official design is fully local after the checkpoint is available.
  - By default the official `opf` package looks for `OPF_CHECKPOINT` or `~/.opf/privacy_filter` and may download the default checkpoint if it is missing.
  - Privacy Preflight should prefer an explicit local checkpoint path to avoid surprise network activity.
- Output format and offsets:
  - The official JSON output includes `schema_version`, `summary`, original/decoded `text`, `detected_spans`, and `redacted_text`.
  - Each detected span includes `label`, `start`, `end`, `text`, and `placeholder`.
  - Prediction export can also produce JSONL with predicted spans keyed by label/text.
  - The model is a BIOES token classifier over eight span categories: `account_number`, `private_address`, `private_email`, `private_person`, `private_phone`, `private_url`, `private_date`, and `secret`.
  - The repository notes an optional warning when tokenizer decoding does not exactly round-trip the input; Privacy Preflight validates span text against the original input before accepting offsets.
- Known limitations:
  - It is a privacy redaction aid, not an anonymization or compliance guarantee.
  - The trained label policy is static and cannot be changed dynamically without fine-tuning.
  - Performance may drop on non-English text, non-Latin scripts, protected-group naming patterns, or out-of-distribution domains.
  - Failure modes include missed unusual names/identifiers, over-redaction of public or ambiguous text, fragmented or shifted boundaries, missed novel secrets, and over-redaction of benign high-entropy strings.

### Phase 4.1 implementation decision

- Real runtime integration is partially feasible but heavy for this phase.
- Added a first-class optional `PrivacyFilterDetector` adapter behind the existing detector interface.
- The adapter dynamically imports the official `opf` package only when enabled, so normal app startup and tests do not require PyTorch or a downloaded checkpoint.
- The adapter maps official labels to local entity types:
  - `private_person` -> `PERSON`
  - `private_email` -> `EMAIL`
  - `private_phone` -> `PHONE`
  - `private_url` -> `URL`
  - `private_address` -> `ADDRESS`
  - `private_date` -> `DATE`
  - `account_number` -> `ID`
  - `secret` -> `API_KEY`
- Intentionally deferred:
  - Installing the official `opf` package as a default dependency.
  - Downloading model weights automatically from the worker.
  - MLX, ONNX, WebGPU, Transformers, or community quantized runtimes.
  - UI controls for Privacy Filter.
  - Replacing regex, Presidio, Chinese dictionary, local dictionary, or Profile detectors.

## Phase 5 natural-language revision reference refresh

Reviewed before adding natural-language revision commands. No new dependencies, source code, provider integrations, or external model-specific phases were added.

### LLM Guard scanner boundary

- Existing reference: https://protectai.github.io/llm-guard/input_scanners/anonymize/
- License: MIT.
- Relevant findings:
  - LLM Guard's scanner pattern keeps model-adjacent logic as structured input/output checks rather than letting a model directly mutate protected text.
  - Its anonymization flow reinforces the idea that redaction commands should be typed, validated, and applied by local deterministic code.
- Reused conceptually:
  - Revision parsing returns strict command JSON only.
  - The worker validates command shape, exact targets, placeholders, and scopes before applying anything.
  - Final text changes still go through the local redaction pipeline and conflict resolver.
- Intentionally not reused:
  - No LLM Guard dependency, vault, deanonymization, prompt-injection scanner, or model scanner is added.

### Cherry Studio PII redaction proposal

- Existing reference: https://github.com/CherryHQ/cherry-studio/issues/14910
- License context: Cherry Studio Community Edition is AGPL-3.0; the issue is used only as a product concept reference.
- Relevant findings:
  - The proposal emphasizes user overrides, typed placeholders, and local preview before content leaves the device.
  - It treats privacy policy changes as explicit user actions rather than hidden model rewrites.
- Reused conceptually:
  - The macOS app exposes a reviewable revision box and shows parsed commands after applying them.
  - Users can choose current-document revisions or persistent profile updates.
  - Profile saves remain explicit and local.
- Intentionally not reused:
  - No AGPL code, UI code, conversation plugin architecture, placeholder restoration, or cloud routing behavior is reused.

### Phase 5 conclusions

- Keep the LLM role limited to intent parsing into `RevisionCommand` objects.
- Keep deterministic fallback commands available when no model is configured.
- Treat external revision parsing more conservatively than review: because the instruction can itself contain raw target text, non-local providers are skipped by default unless raw sharing is explicitly enabled.
- Apply revision commands as transient local candidates or profile rules, then re-run existing conflict resolution so profile allow rules and high-risk regex API-key detections keep their established priority.
- Do not add remove/delete commands, free-form rewrites, provider marketplaces, model comparison, image/PDF behavior, or new model-provider families in Phase 5.

## Phase 5.5 local OpenAI-compatible preflight gateway reference refresh

Reviewed before adding the optional local OpenAI-compatible gateway.

### LLM Guard scanner and vault boundary

- Documentation checked:
  - https://protectai.github.io/llm-guard/input_scanners/anonymize/
  - https://protectai.github.io/llm-guard/output_scanners/deanonymize/
- License: MIT.
- Relevant findings:
  - LLM Guard's `Anonymize` input scanner sanitizes a prompt before the model call and returns sanitized text plus validity/risk metadata.
  - Its `Deanonymize` output scanner is deliberately separate and uses a `Vault` that remembers the original placeholder mappings.
  - The scanner split is a useful safety pattern for a preflight gateway: request transformation should happen before upstream forwarding, and any local diagnostics should remain out of the upstream prompt.
- Reused conceptually:
  - Gateway request messages are transformed locally before forwarding.
  - Preview returns the transformed request and redaction metadata without making an upstream call.
  - Local debug summaries are added only to the local response when explicitly requested, never to the upstream prompt.
- Intentionally not reused:
  - No LLM Guard dependency, model scanner, prompt-injection scanner, deanonymization scanner, or Vault is added.
  - No placeholder restoration is added because this phase is a privacy preflight gateway, not a reversible anonymization proxy.

### OpenAI-compatible proxy and local server patterns

- References checked:
  - OpenAI Chat Completions API reference: https://platform.openai.com/docs/api-reference/chat/create
  - LM Studio OpenAI compatibility docs: https://lmstudio.ai/docs/developer/openai-compat
  - LiteLLM getting-started and proxy docs: https://docs.litellm.ai/
- License and dependency notes:
  - OpenAI and LM Studio docs were used for API-shape compatibility only.
  - LiteLLM was used as a proxy/gateway architecture reference only. No dependency or code was reused.
- Relevant findings:
  - OpenAI-compatible clients generally switch providers by changing the base URL while keeping `/v1/chat/completions`, `/v1/models`, `model`, and `messages`.
  - LM Studio demonstrates the local-server pattern where existing OpenAI clients point to a loopback `/v1` URL.
  - LiteLLM's proxy pattern forwards OpenAI-shaped requests and responses while normalizing provider behavior; it also supports streaming, routing, monitoring, and spend controls that are broader than this phase.
- Reused conceptually:
  - Privacy Preflight exposes `POST /v1/chat/completions` and `GET /v1/models` on the local worker.
  - The gateway preserves the OpenAI-shaped request body as much as possible while replacing configured model and message content with local redacted content before forwarding.
  - The gateway defaults to loopback, disabled state, redacted request messages, and no raw upstream sharing.
- Intentionally not reused:
  - No provider marketplace, routing layer, spend tracking, audit log, virtual keys, streaming bridge, global system proxy, browser extension, or OS traffic interception is added.
  - No provider-specific gateway client is added beyond the existing OpenAI-compatible provider path.

## Phase 5.5 conclusions

- Keep the gateway optional and disabled by default.
- Store gateway settings locally beside model provider settings with `bind_host = 127.0.0.1`, `redact_request_messages = true`, and `allow_raw_text_to_upstream = false` by default.
- Support non-streaming OpenAI-compatible chat completions first; reject streaming safely for now.
- Redact string message content and basic `{"type": "text"}` multipart content locally; reject unsupported multipart content rather than forwarding unredacted data.
- Preview should never forward upstream and should avoid echoing raw sensitive spans in the preview metadata.
- Do not store prompts, log raw request bodies, or include upstream error bodies/API keys in client-visible errors.

## Phase 6 image redaction MVP reference refresh

Reviewed before adding PNG/JPEG OCR-region image redaction. No PDF support, external OCR, cloud vision API, or large reference code reuse was added.

### RedactDesk and doc_redaction

- Existing references:
  - RedactDesk: https://github.com/RedactDesk/redactdesk-mac
  - doc_redaction: https://github.com/seanpedrick-case/doc_redaction
- Relevant findings:
  - Redaction export must change the underlying document/image content, not just add visual review overlays.
  - Human review remains important because automated OCR and entity detection can miss content or over-redact.
  - doc_redaction remains AGPL-3.0-only, so it is still used only as a conceptual workflow reference.
- Reused conceptually:
  - Separate extraction/OCR metadata from the export step.
  - Keep preview overlays reviewable, but burn final redactions into output pixels.
- Intentionally not reused:
  - No PDF pipeline, GUI code, review artifact format, AWS/cloud flow, AGPL code, or project structure was copied.

### Apple Vision OCR bridge

- Reference: Apple Vision framework text-recognition APIs (`VNRecognizeTextRequest`).
- License/dependency context:
  - Vision is an Apple platform framework available locally on macOS; it is not a third-party runtime dependency and does not send image data externally.
- Relevant findings:
  - Vision returns recognized text observations with normalized bounding boxes and confidence scores.
  - The normalized coordinate space must be converted back to image pixel coordinates before drawing redaction rectangles.
- Reused conceptually:
  - The worker uses a small local Swift bridge script behind an OCR provider abstraction when `PRIVACY_PREFLIGHT_IMAGE_OCR_PROVIDER=vision` or the default `auto` provider chooses Vision on macOS.
- Intentionally not reused:
  - No VisionKit UI, document camera workflow, cloud OCR, or persistent OCR cache was added.

### Tesseract / pytesseract

- References:
  - Tesseract OCR: https://github.com/tesseract-ocr/tesseract
  - pytesseract: https://github.com/madmaze/pytesseract
- License:
  - Tesseract is Apache-2.0.
  - pytesseract is Apache-2.0.
- Relevant findings:
  - Tesseract is a local OCR engine and pytesseract exposes word-level text, bounding boxes, and confidence data.
  - Tesseract language packs and the system binary are separate setup concerns; missing OCR should be reported clearly instead of failing app startup.
- Reused conceptually:
  - A `pytesseract` provider is available behind the same OCR abstraction for non-Vision setups.
- Intentionally not reused:
  - pytesseract is optional (`image-ocr` extra) and is not required for normal worker tests because macOS Vision is the default local path on macOS.
  - No automatic Tesseract binary or language-data download is performed.

### Pillow

- Reference: https://github.com/python-pillow/Pillow
- License: HPND-style permissive Pillow license.
- Relevant findings:
  - Pillow can decode PNG/JPEG files and draw opaque rectangles directly into pixel data.
  - Re-encoding the modified image is a simple way to ensure exported image pixels contain the redaction, rather than a reversible overlay layer.
- Reused conceptually:
  - The worker uses Pillow to decode supported image formats, draw opaque black rectangles, create a fresh pixel-only output image, and encode returned PNG/JPEG bytes without source metadata.
- Intentionally not reused:
  - No advanced image metadata rewrite policy, OCR preprocessing pipeline, or PDF/image hybrid processing was added.

## Phase 6 conclusions

- Add a backend image redaction service with an OCR provider abstraction and local-only providers (`vision`, `pytesseract`, `auto`, or disabled).
- Support PNG and JPEG only.
- Safe mode burns rectangles over every OCR text box.
- Precise mode runs each OCR text box through the existing text redaction pipeline and burns only boxes with detected sensitive text.
- Manual rectangles are supported by the backend and a simple drag rectangle UI; all manual rectangles are burned into output pixels.
- Return OCR boxes, redacted boxes, source/reason metadata, summary counts, and base64-encoded redacted image bytes.
- Re-encode redacted PNG/JPEG outputs from pixel data without preserving original EXIF, XMP, IPTC, GPS, device, timestamp, camera, software, thumbnail, or comment metadata.
- Keep original image files untouched by default and avoid storing originals or OCR text on disk. The Vision bridge uses a temporary local file and deletes it after OCR.
- Do not implement PDF support, full-image panic mode, external OCR services, image history storage, or advanced metadata rewrite controls in this phase.

## Phase 7 PDF redaction MVP reference refresh

Reviewed before adding destructive PDF redaction export. No large code blocks were copied.

### RedactDesk

- URL: https://github.com/RedactDesk/redactdesk-mac
- Product site: https://redactdesk.app/
- License: MIT for code. The RedactDesk name and icon are trademarked separately.
- Files inspected:
  - `README.md`
  - `PII Redactor/PDFExtractor.swift`
  - `PII Redactor/PDFRedactor.swift`
- Relevant findings:
  - RedactDesk is a macOS-first, local PDF redaction app using OpenAI Privacy Filter on-device.
  - Its public README states exported PDFs use image-rewrite redaction so content is physically removed rather than hidden behind visual overlays.
  - The PDF extractor separates page text extraction from redaction/export.
  - The PDF redactor renders pages to bitmaps, paints redaction rectangles, and writes a fresh PDF with no selectable text layer.
- Reused conceptually:
  - Keep PDF processing local to the Mac/worker.
  - Keep extraction, detection, review metadata, and export as separate steps.
  - Use image-rewrite/rasterized output as a conservative safety boundary.
  - Validate export by checking text extraction rather than trusting preview appearance.
- Intentionally not reused:
  - No RedactDesk code, PDFKit pipeline, ONNX runtime, model download flow, UI, design system, branding, app packaging, Sparkle update flow, watermarking, or trademarked assets were reused.
  - Privacy Preflight keeps its existing Python worker and SwiftUI app boundary instead of adopting RedactDesk's all-Swift PDF pipeline.

### doc_redaction

- URL: https://github.com/seanpedrick-case/doc_redaction
- Documentation site: https://seanpedrick-case.github.io/doc_redaction/
- License: AGPL-3.0 according to project metadata.
- Relevant findings:
  - The project handles PDF/image documents, Word files, and tabular files through a review-oriented document redaction workflow.
  - It supports local PDF text extraction, OCR with Tesseract/Poppler setup, and optional cloud services.
  - Its settings explicitly distinguish local OCR options from optional AWS Textract/Comprehend behavior.
  - The project warns users that automated redaction should be reviewed.
- Reused conceptually:
  - Stage PDF processing as extraction/OCR, detection, review, and export.
  - Treat OCR availability as a clear setup concern.
  - Keep human review visible because automated detection can miss content.
- Intentionally not reused:
  - No AGPL code, Gradio UI, review artifact format, AWS integration, Poppler dependency, Tesseract setup scripts, or project structure was reused.
  - Privacy Preflight does not add cloud OCR or cloud PII detection for PDF processing.

### CoverUP

- URL: https://github.com/digidigital/CoverUP
- License: GPL-3.0 according to repository license metadata.
- Relevant findings:
  - CoverUP lets users draw redaction bars and exports PDFs after converting content to images.
  - The README states the image conversion prevents normal text copying/indexing without OCR.
  - It offers high-quality and compressed export modes because image-based PDFs can become large.
- Reused conceptually:
  - Manual redaction rectangles can be safe when they are burned into rasterized output rather than left as removable overlays.
  - Rasterization is a practical fallback/default when preserving the original PDF structure is riskier than flattening.
- Intentionally not reused:
  - No GPL code, GUI code, package structure, session persistence, white-bar option, compressed export UI, translation assets, or installer flow was reused.

### Former PDF-engine investigation (superseded for 0.1.0)

- Documentation: https://pymupdf.readthedocs.io/en/latest/page.html
- License context: this evaluated engine has AGPL/commercial terms and is not installed or bundled in the 0.1.0 release.
- Relevant findings:
  - `Page.add_redact_annot()` marks regions and `Page.apply_redactions()` applies and deletes redaction annotations.
  - Redaction options can remove text and blank image pixels in overlapping regions.
  - `Page.get_text("words")` provides word-level coordinates, and `Page.get_pixmap()` renders pages for raster workflows.
  - New PDFs can be built by inserting rendered page images into fresh pages.
- Historical implementation only:
  - An earlier private-development implementation used this engine. The distributed source and runtime replace it with pypdfium2/PDFium, pypdf, Pillow, and ReportLab.
- Intentionally not reused:
  - Native redaction alone is not trusted as the final safety boundary in this MVP. Output is rebuilt as image-only pages after burn-in and then validated.

## Phase 7 conclusions

- Add `POST /redact/pdf/analyze` and `POST /redact/pdf/export`.
- Use the existing local text redaction pipeline for extracted PDF text and OCR text boxes.
- Classify PDFs as text, scanned, or mixed based on text and image content.
- Use local OCR for scanned or image-containing pages; fail closed if OCR is required but unavailable.
- Merge detected regions with manual page rectangles.
- Attempt true PDF redaction first, then always rebuild the final exported PDF as rasterized image-only pages with redaction rectangles burned into pixels.
- Strip metadata on the rebuilt PDF and do not preserve annotations, forms, embedded files, or source text layers.
- Validate output by extracting text from the exported PDF, checking known redacted strings, checking that no text layer remains, and checking that no redaction annotations were left unapplied.
- Add a SwiftUI PDF workspace with drag/drop, page preview, detected/manual region overlays, manual rectangle selection, export, and validation display.
- Do not claim legal-grade redaction, preserve selectable text, add cloud OCR, add PDF history storage, overwrite originals, or implement advanced region editing in this phase.

## Phase 8 packaging, lifecycle, and release-readiness reference refresh

Reviewed before adding development app-bundle packaging and worker lifecycle management. No referenced project code was copied.

### Apple macOS bundle and sandbox documentation

- Bundle content placement: https://developer.apple.com/documentation/bundleresources/placing-content-in-a-bundle
- Bundle structure guide: https://developer.apple.com/library/archive/documentation/CoreFoundation/Conceptual/CFBundles/BundleTypes/BundleTypes.html
- App Sandbox documentation: https://developer.apple.com/documentation/security/app_sandbox
- Notarization documentation: https://developer.apple.com/documentation/security/notarizing_macos_software_before_distribution
- Relevant findings:
  - macOS app bundles use `Contents/Info.plist`, `Contents/MacOS/`, and `Contents/Resources/`.
  - Apple distinguishes executable code from script/resources for bundle placement and notarization risk.
  - Sandboxed file access should be driven by user-selected read/write permissions.
  - Developer ID distribution requires signing, hardened runtime, and notarization before release claims.
- Reused conceptually:
  - Add a real `.app` wrapper layout around the current SwiftPM executable.
  - Put worker source under `Contents/Resources/worker` for the dev bundle rather than pretending scripts are signed helper code.
  - Add an entitlements template for intended sandbox shape.
- Intentionally not reused:
  - No Xcode project, launch daemon, privileged helper, service management helper, notarization flow, or App Store sandbox claim is added in this phase.

### Uvicorn local binding

- Settings reference: https://www.uvicorn.org/settings/
- Relevant findings:
  - Uvicorn's host setting controls the bind address, and `127.0.0.1` is the safe loopback-only default.
- Reused conceptually:
  - The app lifecycle manager launches the worker with `--host 127.0.0.1`.
  - The worker lifecycle smoke test checks that the listener is not bound to wildcard interfaces.
- Intentionally not reused:
  - No network exposure, reverse proxy, launch daemon, or remote worker mode was added.

### Dependency license references

- Former PDF-engine licensing references are retained above as historical provenance only.
- Pillow: https://github.com/python-pillow/Pillow/blob/main/LICENSE
- FastAPI: https://github.com/fastapi/fastapi
- Uvicorn: https://github.com/Kludex/uvicorn
- Pydantic: https://github.com/pydantic/pydantic/blob/main/LICENSE
- Microsoft Presidio: https://github.com/microsoft/presidio
- pytesseract: https://github.com/madmaze/pytesseract
- Tesseract: https://github.com/tesseract-ocr/tesseract
- OpenAI Privacy Filter: https://github.com/openai/privacy-filter and https://openai.com/index/introducing-openai-privacy-filter/
- Relevant findings:
  - The former engine was an AGPL/commercial release blocker and was replaced before the 0.1.0 preview.
  - Pillow, FastAPI, Uvicorn, Pydantic, Presidio, pytesseract, Tesseract, and official OpenAI Privacy Filter are permissive-license dependencies, subject to notice and transitive dependency review.
  - Optional model and OCR assets need separate review before bundling.
- Reused conceptually:
  - Document release blockers before packaging claims.
  - Keep optional detector/OCR dependencies optional and local.
- Intentionally not reused:
  - No dependency was vendored or bundled as a complete runtime in that historical phase.

## Phase 8 conclusions

- Choose SwiftPM plus an app-wrapper script as the near-term packaging path.
- Produce a development `.app` bundle with `Info.plist`, resources, icon generation, and bundled worker source.
- The historical phase did not claim notarization, sandbox verification, or self-contained Python bundling; 0.1.0 later added a standalone runtime but remains unnotarized.
- Add app-driven worker start, stop, restart, health check, sanitized latest error, loopback endpoint display, and limited crash restart.
- Launch the worker with `127.0.0.1` binding and access logs disabled.
- Add privacy diagnostics and local-data clear endpoints that avoid raw content and keep Keychain API keys unless explicitly cleared.
- Document app data paths, localhost behavior, temp-file behavior, signing/notarization checklist, install flow, uninstall flow, and dependency-distribution risk.
