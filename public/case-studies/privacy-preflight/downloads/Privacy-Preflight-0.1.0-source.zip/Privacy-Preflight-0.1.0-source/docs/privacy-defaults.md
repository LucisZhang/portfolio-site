# Privacy Defaults

Privacy Preflight is local-first by default.

## Defaults

- Worker endpoint: `http://127.0.0.1:8765`
- Worker bind host: `127.0.0.1`
- History: off
- External model raw-text sharing: off
- Gateway: off
- Gateway request redaction: on
- Gateway raw upstream forwarding: off
- Image export: pixel-modified and metadata-stripped
- PDF export: rasterized image-only output with burned-in redactions
- API keys: stored in macOS Keychain when possible

## Not Stored By Default

- raw text submissions
- raw images
- raw PDFs
- raw OCR output
- raw PDF text
- raw model prompts
- raw gateway prompts
- redaction history

## Stored Locally

- profile rules: `~/Library/Application Support/Privacy Preflight/profile.json`
- model provider metadata: `~/Library/Application Support/Privacy Preflight/model_providers.json`
- API keys: macOS Keychain service `Privacy Preflight Model Providers`
- worker lifecycle log: `~/Library/Application Support/Privacy Preflight/Logs/worker-lifecycle.log`

Profile rules can contain user-entered sensitive terms. They stay local and are not sent externally by the worker.

## External Providers

External/generic OpenAI-compatible providers receive redacted-only content by default. Sending raw text to a non-local provider requires explicit opt-in and produces a warning in model review or revision results.

## Diagnostics

Diagnostics are designed for support without raw content. They include counts, paths, and privacy flags only.

## Clear Local Data

The app exposes a Clear Local Data action. It removes local profile and model provider settings. Keychain API keys are kept by default; users can remove them separately or future UI can expose a separate destructive key-clearing option.
