import Combine
import Foundation

struct WorkerEndpoint: Equatable {
    static let loopbackHost = "127.0.0.1"
    static let defaultPort = 8765

    let port: Int

    static func fromEnvironment(_ environment: [String: String] = ProcessInfo.processInfo.environment) -> WorkerEndpoint {
        let configuredPort = Int(environment["PRIVACY_PREFLIGHT_WORKER_PORT"] ?? "") ?? defaultPort
        return WorkerEndpoint(port: configuredPort)
    }

    var baseURL: URL {
        URL(string: "http://\(Self.loopbackHost):\(port)")!
    }

    var displayString: String {
        baseURL.absoluteString.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
    }
}

@MainActor
final class WorkerLifecycleManager: ObservableObject {
    static let shared = WorkerLifecycleManager()

    nonisolated static var configuredEndpoint: WorkerEndpoint {
        WorkerEndpoint.fromEnvironment()
    }

    nonisolated static var configuredEndpointURL: URL {
        configuredEndpoint.baseURL
    }

    enum Status: Equatable {
        case stopped
        case starting
        case running
        case stopping
        case unavailable
    }

    @Published private(set) var status: Status = .stopped
    @Published private(set) var endpointURL: URL
    @Published private(set) var lastHealthCheck: Date?
    @Published private(set) var latestError: String?
    @Published private(set) var launchModeDescription = "Worker launch path has not been resolved yet."

    private let endpoint: WorkerEndpoint
    private let port: Int
    private let session: URLSession
    private var process: Process?
    private var intentionalStop = false
    private var restartAttempts = 0
    private let maximumRestartAttempts = 2

    var endpointDisplay: String {
        endpoint.displayString
    }

    var statusTitle: String {
        switch status {
        case .stopped:
            return "Stopped"
        case .starting:
            return "Starting"
        case .running:
            return "Running"
        case .stopping:
            return "Stopping"
        case .unavailable:
            return "Needs attention"
        }
    }

    var canStart: Bool {
        status == .stopped || status == .unavailable
    }

    var canStop: Bool {
        process?.isRunning == true && (status == .running || status == .starting || status == .unavailable)
    }

    var canRestart: Bool {
        if status == .running {
            return process?.isRunning == true
        }
        return status == .stopped || status == .unavailable
    }

    private init() {
        let configuredEndpoint = Self.configuredEndpoint
        endpoint = configuredEndpoint
        port = configuredEndpoint.port
        endpointURL = configuredEndpoint.baseURL

        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 2
        configuration.timeoutIntervalForResource = 2
        session = URLSession(configuration: configuration)
    }

    func startIfNeeded() async {
        if await checkHealth() {
            return
        }
        await start()
    }

    func start() async {
        restartAttempts = 0
        await launchWorker()
    }

    func stop() async {
        intentionalStop = true
        status = .stopping
        appendLifecycleLog("Stopping worker.")

        guard let process else {
            status = .stopped
            latestError = nil
            return
        }

        if process.isRunning {
            process.terminate()
            for _ in 0..<20 where process.isRunning {
                try? await Task.sleep(nanoseconds: 100_000_000)
            }
        }

        self.process = nil
        status = .stopped
        latestError = nil
    }

    func restart() async {
        await stop()
        intentionalStop = false
        await start()
    }

    func checkHealth() async -> Bool {
        var request = URLRequest(url: endpointURL.appendingPathComponent("health"))
        request.httpMethod = "GET"
        request.timeoutInterval = 2

        do {
            let (_, response) = try await session.data(for: request)
            guard let httpResponse = response as? HTTPURLResponse,
                  (200..<300).contains(httpResponse.statusCode)
            else {
                recordHealthCheck(success: false, message: "Worker health check returned a non-OK response.")
                return false
            }
            recordHealthCheck(success: true, message: nil)
            return true
        } catch {
            recordHealthCheck(success: false, message: "Worker did not answer the local health check.")
            return false
        }
    }

    func recordHealthCheck(success: Bool, message: String?) {
        lastHealthCheck = Date()
        if success {
            status = .running
            if process == nil {
                launchModeDescription = "Using an already running local worker. The app can health-check it but did not launch it."
            }
            latestError = nil
        } else {
            latestError = sanitize(message ?? "Worker health check failed.")
            if process?.isRunning == true {
                status = .unavailable
            } else if status != .starting && status != .stopping {
                status = .stopped
            }
        }
    }

    func stopSynchronouslyOnAppExit() {
        if ProcessInfo.processInfo.environment["PRIVACY_PREFLIGHT_KEEP_WORKER_ALIVE"] == "1" {
            appendLifecycleLog("Leaving worker running because PRIVACY_PREFLIGHT_KEEP_WORKER_ALIVE=1.")
            return
        }
        intentionalStop = true
        guard let process else { return }
        if process.isRunning {
            process.terminate()
            process.waitUntilExit()
        }
        self.process = nil
        status = .stopped
    }

    private func launchWorker() async {
        if process?.isRunning == true {
            status = .running
            latestError = nil
            return
        }

        guard let plan = resolveLaunchPlan() else {
            status = .unavailable
            latestError = "Could not find the local worker. Run from the repository or use the documented dev app bundle layout."
            appendLifecycleLog("Worker launch failed: worker directory could not be resolved.")
            return
        }

        intentionalStop = false
        status = .starting
        latestError = nil
        launchModeDescription = plan.description
        appendLifecycleLog("Starting worker on 127.0.0.1:\(port) using \(plan.pythonDisplayName).")

        let newProcess = Process()
        newProcess.executableURL = plan.executableURL
        newProcess.arguments = plan.arguments
        newProcess.currentDirectoryURL = plan.workerDirectory
        newProcess.environment = workerEnvironment(workerDirectory: plan.workerDirectory)
        newProcess.standardOutput = FileHandle.nullDevice
        newProcess.standardError = FileHandle.nullDevice
        newProcess.terminationHandler = { [weak self] terminatedProcess in
            Task { @MainActor in
                self?.handleWorkerTermination(terminatedProcess)
            }
        }

        do {
            try newProcess.run()
            process = newProcess
        } catch {
            process = nil
            status = .unavailable
            latestError = "Worker process could not be launched. Check Python setup and worker dependencies."
            appendLifecycleLog("Worker launch failed before process start.")
            return
        }

        for _ in 0..<28 {
            if await checkHealth() {
                appendLifecycleLog("Worker health check passed.")
                restartAttempts = 0
                return
            }
            if newProcess.isRunning == false {
                break
            }
            try? await Task.sleep(nanoseconds: 250_000_000)
        }

        if newProcess.isRunning {
            status = .unavailable
            latestError = "Worker started but did not answer health checks on \(endpointDisplay)."
            appendLifecycleLog("Worker launch timed out before health check passed.")
        }
    }

    private func handleWorkerTermination(_ terminatedProcess: Process) {
        guard process === terminatedProcess else { return }
        process = nil

        if intentionalStop {
            status = .stopped
            latestError = nil
            appendLifecycleLog("Worker stopped.")
            return
        }

        let exitCode = terminatedProcess.terminationStatus
        latestError = "Worker exited unexpectedly with code \(exitCode)."
        appendLifecycleLog("Worker exited unexpectedly with code \(exitCode).")

        guard restartAttempts < maximumRestartAttempts else {
            status = .unavailable
            return
        }

        restartAttempts += 1
        status = .starting
        appendLifecycleLog("Restarting worker after unexpected exit. Attempt \(restartAttempts).")
        Task {
            try? await Task.sleep(nanoseconds: 800_000_000)
            await launchWorker()
        }
    }

    private func resolveLaunchPlan() -> WorkerLaunchPlan? {
        let environment = ProcessInfo.processInfo.environment
        if let configuredWorkerDir = environment["PRIVACY_PREFLIGHT_WORKER_DIR"],
           let configuredPython = environment["PRIVACY_PREFLIGHT_WORKER_PYTHON"] {
            let workerDirectory = URL(fileURLWithPath: configuredWorkerDir, isDirectory: true)
            let pythonURL = URL(fileURLWithPath: configuredPython)
            return WorkerLaunchPlan(
                workerDirectory: workerDirectory,
                executableURL: pythonURL,
                arguments: uvicornArguments(forPythonExecutable: pythonURL),
                description: "Development worker using explicit environment paths.",
                pythonDisplayName: pythonURL.path
            )
        }

        if let repositoryWorkerDirectory = findRepositoryWorkerDirectory(),
           let plan = plan(for: repositoryWorkerDirectory, description: "Development worker from the repository checkout.") {
            return plan
        }

        if let resourceURL = Bundle.main.resourceURL {
            let bundledWorkerDirectory = resourceURL.appendingPathComponent("worker", isDirectory: true)
            let bundledPython = resourceURL
                .appendingPathComponent("python", isDirectory: true)
                .appendingPathComponent("bin", isDirectory: true)
                .appendingPathComponent("python3")
            if FileManager.default.fileExists(atPath: bundledWorkerDirectory.appendingPathComponent("pyproject.toml").path),
               FileManager.default.isExecutableFile(atPath: bundledPython.path) {
                return WorkerLaunchPlan(
                    workerDirectory: bundledWorkerDirectory,
                    executableURL: bundledPython,
                    arguments: uvicornArguments(forPythonExecutable: bundledPython),
                    description: "Standalone bundled worker runtime.",
                    pythonDisplayName: "Bundled Python 3.12"
                )
            }

            if FileManager.default.fileExists(atPath: bundledWorkerDirectory.appendingPathComponent("pyproject.toml").path),
               let plan = plan(for: bundledWorkerDirectory, description: "Dev app bundle worker source. Python dependencies are still external.") {
                return plan
            }
        }

        return nil
    }

    private func plan(for workerDirectory: URL, description: String) -> WorkerLaunchPlan? {
        let venvPython = workerDirectory
            .appendingPathComponent(".venv", isDirectory: true)
            .appendingPathComponent("bin", isDirectory: true)
            .appendingPathComponent("python")
        if FileManager.default.isExecutableFile(atPath: venvPython.path) {
            return WorkerLaunchPlan(
                workerDirectory: workerDirectory,
                executableURL: venvPython,
                arguments: uvicornArguments(forPythonExecutable: venvPython),
                description: "\(description) Using the worker virtual environment.",
                pythonDisplayName: venvPython.path
            )
        }

        let envURL = URL(fileURLWithPath: "/usr/bin/env")
        return WorkerLaunchPlan(
            workerDirectory: workerDirectory,
            executableURL: envURL,
            arguments: ["python3"] + uvicornArguments(forPythonExecutable: envURL),
            description: "\(description) Python runtime/dependencies are not bundled.",
            pythonDisplayName: "python3"
        )
    }

    private func uvicornArguments(forPythonExecutable executableURL: URL) -> [String] {
        let baseArguments = [
            "-m",
            "uvicorn",
            "app.main:app",
            "--host",
            "127.0.0.1",
            "--port",
            String(port),
            "--log-level",
            "warning",
            "--no-access-log",
        ]
        return executableURL.path == "/usr/bin/env" ? baseArguments : baseArguments
    }

    private func workerEnvironment(workerDirectory: URL) -> [String: String] {
        var environment = ProcessInfo.processInfo.environment
        environment["PYTHONUNBUFFERED"] = "1"
        environment["PRIVACY_PREFLIGHT_WORKER_PORT"] = String(port)
        environment["PRIVACY_PREFLIGHT_WORKER_DIR"] = workerDirectory.path
        environment["PRIVACY_PREFLIGHT_WORKER_BIND_HOST"] = "127.0.0.1"
        let bundledVisionHelper = Bundle.main.bundleURL
            .appendingPathComponent("Contents", isDirectory: true)
            .appendingPathComponent("MacOS", isDirectory: true)
            .appendingPathComponent("image_ocr_vision")
        if FileManager.default.isExecutableFile(atPath: bundledVisionHelper.path) {
            environment["PRIVACY_PREFLIGHT_VISION_OCR_EXECUTABLE"] = bundledVisionHelper.path
        }
        return environment
    }

    private func findRepositoryWorkerDirectory() -> URL? {
        let fileManager = FileManager.default
        let seeds = [
            URL(fileURLWithPath: fileManager.currentDirectoryPath, isDirectory: true),
            Bundle.main.bundleURL,
            Bundle.main.executableURL?.deletingLastPathComponent(),
        ].compactMap { $0 }

        for seed in seeds {
            for ancestor in ancestors(of: seed) {
                let workerDirectory = ancestor
                    .appendingPathComponent("services", isDirectory: true)
                    .appendingPathComponent("worker", isDirectory: true)
                let marker = workerDirectory.appendingPathComponent("pyproject.toml")
                if fileManager.fileExists(atPath: marker.path) {
                    return workerDirectory
                }
            }
        }

        return nil
    }

    private func ancestors(of url: URL) -> [URL] {
        var result: [URL] = []
        var current = url.standardizedFileURL
        for _ in 0..<12 {
            result.append(current)
            let parent = current.deletingLastPathComponent()
            if parent.path == current.path {
                break
            }
            current = parent
        }
        return result
    }

    private func appendLifecycleLog(_ message: String) {
        let logDirectory = appDataDirectory().appendingPathComponent("Logs", isDirectory: true)
        let logURL = logDirectory.appendingPathComponent("worker-lifecycle.log")
        let timestamp = ISO8601DateFormatter().string(from: Date())
        let line = "\(timestamp) \(sanitize(message))\n"

        do {
            try FileManager.default.createDirectory(
                at: logDirectory,
                withIntermediateDirectories: true
            )
            if FileManager.default.fileExists(atPath: logURL.path),
               let handle = try? FileHandle(forWritingTo: logURL) {
                try handle.seekToEnd()
                try handle.write(contentsOf: Data(line.utf8))
                try handle.close()
            } else {
                try Data(line.utf8).write(to: logURL, options: .atomic)
            }
        } catch {
            // Lifecycle logging must never interrupt local redaction.
        }
    }

    private func appDataDirectory() -> URL {
        if let configured = ProcessInfo.processInfo.environment["PRIVACY_PREFLIGHT_APP_DATA_DIR"],
           !configured.isEmpty {
            return URL(fileURLWithPath: configured, isDirectory: true)
        }
        return FileManager.default
            .homeDirectoryForCurrentUser
            .appendingPathComponent("Library", isDirectory: true)
            .appendingPathComponent("Application Support", isDirectory: true)
            .appendingPathComponent("Privacy Preflight", isDirectory: true)
    }

    private func sanitize(_ message: String) -> String {
        var sanitized = message.replacingOccurrences(of: "\n", with: " ")
        sanitized = sanitized.replacingOccurrences(of: "\r", with: " ")
        if sanitized.count > 240 {
            sanitized = String(sanitized.prefix(240)) + "..."
        }
        return sanitized
    }
}

private struct WorkerLaunchPlan {
    let workerDirectory: URL
    let executableURL: URL
    let arguments: [String]
    let description: String
    let pythonDisplayName: String
}
