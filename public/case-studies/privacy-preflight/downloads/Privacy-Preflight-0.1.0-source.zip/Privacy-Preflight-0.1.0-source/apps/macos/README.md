# Privacy Preflight macOS

This is the SwiftUI text, image, and PDF workspace for the Privacy Preflight Mac app.

It includes:

- A text input editor.
- A redacted output editor.
- A Balanced/Strict mode selector.
- Worker health status for the local FastAPI worker.
- Redact and Copy buttons.
- A natural-language revision box with This Document and Save to Profile scopes.
- A read-only highlighted source preview.
- Entity summary counts and a review list with detected span, type, source, replacement, and confidence.
- A selection-driven entity inspector with original text, replacement, action, profile rule id when available, offsets, reason, and quick profile actions.
- A Profile settings sheet for listing, adding, editing, deleting, enabling, disabling, and learning local profile rules.
- A Model settings sheet for local-first review and revision parsing providers.
- An Image workspace for PNG/JPEG OCR-region redaction and burned-in export.
- A PDF workspace for local page preview, detected region review, manual rectangles, destructive PDF export, and validation display.
- A worker status panel with local endpoint, last health check, start/stop/restart/check controls, sanitized latest error, and privacy maintenance actions.

The app attempts to start the local worker automatically when it can find the repository worker and a usable Python environment. Manual worker startup remains available for debugging:

```bash
scripts/dev_worker.sh
```

Open this folder in Xcode as a Swift package, or build the development app bundle from the repository root:

```bash
scripts/build_macos_app.sh
```

The bundle is created at:

```text
apps/macos/build/Privacy Preflight.app
```

This is a development bundle. It is not notarized, not sandbox-verified, and does not bundle a Python runtime/dependency environment.

You can also run from Terminal:

```bash
swift build
swift run PrivacyPreflightApp
```

Manual test input:

```text
我的学校是北京理工大学，邮箱 ada@example.com，地址：北京市海淀区中关村南大街5号
```

Unicode offset test inputs:

```text
😀 我的邮箱 ada@example.com
我在北京理工大学，邮箱 ada@example.com
café email ada@example.com
🇨🇳 地址：北京市海淀区中关村南大街5号
```

Manual verification:

1. Run the app from `apps/macos` with `swift run PrivacyPreflightApp`, or open the development app bundle.
2. Confirm the worker status panel shows `Running` and endpoint `http://127.0.0.1:8765`.
3. Paste the mixed-language test input.
4. Click `Redact`.
5. Confirm the redacted output contains `[SCHOOL]`, `[EMAIL]`, and `[ADDRESS]`.
6. Confirm `Highlighted Source` marks the original school, email, and address spans.
7. Select each entity row and confirm the inspector updates original text, replacement, type, source, confidence, span, and reason.
8. Open `Profile`, add a rule such as `label: Tsinghua`, `entity_type: SCHOOL`, `patterns: 清华大学`, `aliases: Tsinghua University`, `replacement: [SCHOOL]`, `action: Always Mask`, then save it.
9. Redact text containing the profile term and confirm the inspector shows `Source` as `profile` and includes the profile rule id.
10. In the inspector, choose `Always Allow This` for a selected ordinary email, redact again, and confirm that email is no longer returned as an entity.
11. Open `Profile`, switch to `Learn`, paste the mixed-language sample, find candidates, save selected candidates, and confirm saved rules appear in `Rules`.
12. Type `mask Project Phoenix` into the revision box for text containing `Project Phoenix`, apply it, and confirm the parsed command appears and the output uses `[CUSTOM]`.
13. Change the revision scope to `Save to Profile`, type `add Project Phoenix to profile as PROJECT`, apply it, and confirm the saved rule appears in `Profile`.
14. Use `Privacy` > `Export Diagnostics` and confirm the file contains counts and paths, not raw text.
15. Use the worker panel `Stop`, `Start`, and `Restart` controls and confirm the UI recovers.
16. Click `Copy` and paste elsewhere to confirm the copied text is the redacted output.
17. Stop the worker, click `Redact`, and confirm the offline error is understandable.
18. Repeat with the Unicode offset test inputs and confirm highlighting still maps to the detected entity text, especially after emoji, flag emoji, and accented text.

PDF manual verification:

1. Run the app and confirm the worker is running.
2. Switch to `PDF`.
3. Drop or choose a PDF containing `ada@example.com`.
4. Confirm page previews and detected regions appear.
5. Draw a manual rectangle on the page preview.
6. Click `Export PDF`.
7. Confirm the validation result is shown and save to a new `-redacted.pdf` file.
8. Confirm the app refuses to save over the original PDF path.

This phase intentionally does not include direct click-to-select highlighted spans, clipboard shortcuts, global hotkeys, notarization, sandbox verification, or legal-grade redaction guarantees. The 0.1.0 release script does embed an arm64 Python runtime and the audited replacement PDF stack; the resulting preview is ad-hoc signed and unnotarized.
