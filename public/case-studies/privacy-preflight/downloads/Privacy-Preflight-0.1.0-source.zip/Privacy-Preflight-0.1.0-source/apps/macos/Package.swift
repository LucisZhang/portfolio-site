// swift-tools-version: 5.9

import PackageDescription

let package = Package(
    name: "PrivacyPreflightMac",
    platforms: [
        .macOS(.v14)
    ],
    products: [
        .executable(
            name: "PrivacyPreflightApp",
            targets: ["PrivacyPreflightApp"]
        )
    ],
    targets: [
        .executableTarget(
            name: "PrivacyPreflightApp",
            path: "Sources/PrivacyPreflightApp"
        )
    ]
)
