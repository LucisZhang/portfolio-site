import AppKit
import SwiftUI
import UniformTypeIdentifiers

private enum WorkspaceKind: String, CaseIterable, Identifiable {
    case text
    case image
    case pdf

    var id: String { rawValue }

    var title: String {
        switch self {
        case .text:
            return "Text"
        case .image:
            return "Image"
        case .pdf:
            return "PDF"
        }
    }

    var subtitle: String {
        switch self {
        case .text:
            return "Local text redaction"
        case .image:
            return "Local image redaction"
        case .pdf:
            return "Local PDF redaction"
        }
    }
}

struct ContentView: View {
    private static let apiClient = PrivacyPreflightAPIClient(
        baseURL: WorkerLifecycleManager.configuredEndpointURL
    )

    @ObservedObject var workerManager: WorkerLifecycleManager
    @State private var workspace: WorkspaceKind = .text
    @State private var inputText = ""
    @State private var outputText = ""
    @State private var mode: TextRedactionMode = .balanced
    @State private var healthState: WorkerHealthState = .checking
    @State private var entities: [RedactionEntity] = []
    @State private var summary: [String: Int] = [:]
    @State private var previewSourceText = ""
    @State private var selectedEntityID: RedactionEntity.ID?
    @State private var highlightedEntityID: RedactionEntity.ID?
    @State private var errorMessage: String?
    @State private var errorSource: ContentErrorSource?
    @State private var copyConfirmation: String?
    @State private var isRedacting = false
    @State private var isShowingProfileSettings = false
    @State private var isShowingModelSettings = false
    @State private var isShowingGatewaySettings = false
    @State private var profileSettingsSeed: ProfileRuleSeed?
    @State private var quickRuleStatus: String?
    @State private var isSavingQuickRule = false
    @State private var revisionInstruction = ""
    @State private var revisionScope: RevisionScope = .currentDocument
    @State private var latestRevisionParseResult: RevisionParseResult?
    @State private var latestAppliedRevisionCommands: [AppliedRevisionCommand] = []
    @State private var isApplyingRevision = false
    @State private var modelProviders: [ModelProvider] = []
    @State private var modelSettings = ModelReviewSettings(
        enableLLMReview: false,
        selectedReviewProviderID: nil,
        allowRawTextForExternalModels: false
    )
    @State private var latestReviewResult: ModelReviewResult?

    private var selectedEntity: RedactionEntity? {
        guard let selectedEntityID else { return nil }
        return entities.first { $0.id == selectedEntityID }
    }

    var body: some View {
        VStack(spacing: 0) {
            toolbar
            WorkerStatusPanel(
                workerManager: workerManager,
                onStart: { await startWorker() },
                onStop: { await stopWorker() },
                onRestart: { await restartWorker() },
                onCheck: { await refreshHealth() },
                onExportDiagnostics: { await exportDiagnostics() },
                onClearLocalData: { await clearLocalData() }
            )

            if let message = errorMessage {
                StatusBanner(message: message, style: .error)
            } else if case .unavailable(let message) = healthState {
                StatusBanner(message: message, style: .warning)
            }

            if workspace == .text, let latestReviewResult {
                ModelReviewBanner(result: latestReviewResult)
            }

            if workspace == .text {
                textWorkspace
            } else if workspace == .image {
                ImageWorkspaceView(
                    apiClient: Self.apiClient,
                    healthState: $healthState,
                    errorMessage: $errorMessage,
                    errorSource: $errorSource
                )
            } else {
                PDFWorkspaceView(
                    apiClient: Self.apiClient,
                    healthState: $healthState,
                    errorMessage: $errorMessage,
                    errorSource: $errorSource
                )
            }
        }
        .frame(minWidth: 1120, minHeight: 760)
        .sheet(isPresented: $isShowingProfileSettings, onDismiss: {
            profileSettingsSeed = nil
        }) {
            ProfileSettingsView(
                apiClient: Self.apiClient,
                initialRuleSeed: profileSettingsSeed
            )
                .frame(minWidth: 760, minHeight: 560)
        }
        .sheet(isPresented: $isShowingModelSettings, onDismiss: {
            Task { await refreshModelConfig() }
        }) {
            ModelSettingsView(apiClient: Self.apiClient)
                .frame(minWidth: 860, minHeight: 620)
        }
        .sheet(isPresented: $isShowingGatewaySettings) {
            GatewaySettingsView(apiClient: Self.apiClient)
                .frame(minWidth: 860, minHeight: 620)
        }
        .task {
            await workerManager.startIfNeeded()
            await refreshHealth()
            await refreshModelConfig()
        }
    }

    private var textWorkspace: some View {
        HSplitView {
            editor(
                title: "Input",
                text: $inputText,
                prompt: "Paste text to redact"
            )
            .frame(minWidth: 360, idealWidth: 480)

            VStack(spacing: 0) {
                editor(
                    title: "Redacted Output",
                    text: Binding.constant(outputText),
                    prompt: "Redacted text will appear here"
                )
                .frame(minHeight: 150)

                Divider()

                revisionPanel
                    .frame(minHeight: 132, idealHeight: 154, maxHeight: 190)

                Divider()

                highlightPreview
                    .frame(minHeight: 150, idealHeight: 170, maxHeight: 220)

                Divider()

                entityReview
                    .frame(minHeight: 250, idealHeight: 290, maxHeight: 360)
            }
            .frame(minWidth: 640)
        }
    }

    private var toolbar: some View {
        HStack(spacing: 14) {
            VStack(alignment: .leading, spacing: 2) {
                Text("Privacy Preflight")
                    .font(.title2)
                    .fontWeight(.semibold)
                Text(workspace.subtitle)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }

            Picker("Workspace", selection: $workspace) {
                ForEach(WorkspaceKind.allCases) { workspace in
                    Text(workspace.title).tag(workspace)
                }
            }
            .pickerStyle(.segmented)
            .frame(width: 210)

            Spacer()

            Button {
                profileSettingsSeed = nil
                isShowingProfileSettings = true
            } label: {
                Label("Profile", systemImage: "person.text.rectangle")
            }
            .buttonStyle(.bordered)

            Button {
                isShowingModelSettings = true
            } label: {
                Label("Models", systemImage: "cpu")
            }
            .buttonStyle(.bordered)

            Button {
                isShowingGatewaySettings = true
            } label: {
                Label("Gateway", systemImage: "point.3.connected.trianglepath.dotted")
            }
            .buttonStyle(.bordered)

            if workspace == .text, modelSettings.enableLLMReview {
                Label(modelReviewToolbarTitle, systemImage: "sparkle.magnifyingglass")
                    .font(.caption)
                    .foregroundStyle(modelReviewToolbarColor)
                    .help(modelReviewToolbarHelp)
            }

            healthIndicator

            Button {
                Task { await refreshHealth() }
            } label: {
                Label("Check worker", systemImage: "arrow.clockwise")
            }
            .labelStyle(.iconOnly)
            .buttonStyle(.borderless)
            .help("Check worker")
            .disabled(healthState == .checking)

            if workspace == .text {
                Picker("Mode", selection: $mode) {
                    ForEach(TextRedactionMode.allCases) { mode in
                        Text(mode.title).tag(mode)
                    }
                }
                .pickerStyle(.segmented)
                .frame(width: 190)
                .disabled(isRedacting)

                Button {
                    Task { await redact() }
                } label: {
                    if isRedacting {
                        ProgressView()
                            .controlSize(.small)
                            .frame(width: 18, height: 18)
                    } else {
                        Label("Redact", systemImage: "wand.and.stars")
                    }
                }
                .buttonStyle(.borderedProminent)
                .frame(width: 96)
                .disabled(inputText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || isRedacting || isApplyingRevision)

                Button {
                    copyRedactedText()
                } label: {
                    Label(copyConfirmation ?? "Copy", systemImage: "doc.on.doc")
                }
                .buttonStyle(.bordered)
                .frame(width: 96)
                .disabled(outputText.isEmpty)
            }
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 14)
        .background(Color(nsColor: .windowBackgroundColor))
        .overlay(Divider(), alignment: .bottom)
    }

    private var healthIndicator: some View {
        HStack(spacing: 6) {
            Circle()
                .fill(healthState.color)
                .frame(width: 8, height: 8)

            Text(healthState.title)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .help(healthState.helpText)
    }

    private var selectedReviewProvider: ModelProvider? {
        guard let providerID = modelSettings.selectedReviewProviderID else { return nil }
        return modelProviders.first { $0.id == providerID }
    }

    private var modelReviewToolbarTitle: String {
        guard let provider = selectedReviewProvider else {
            return "Review not configured"
        }
        return provider.isLocal ? "Local review" : "External review"
    }

    private var modelReviewToolbarColor: Color {
        guard let provider = selectedReviewProvider else {
            return .orange
        }
        return provider.isLocal ? .secondary : .orange
    }

    private var modelReviewToolbarHelp: String {
        guard let provider = selectedReviewProvider else {
            return "Choose a review provider in Model settings."
        }
        if provider.isLocal {
            return "LLM review uses \(provider.name) locally."
        }
        if modelSettings.allowRawTextForExternalModels {
            return "External LLM review may receive original text because raw sharing is enabled."
        }
        return "External LLM review receives redacted-only input by default."
    }

    private var highlightPreview: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .firstTextBaseline) {
                Text("Highlighted Source")
                    .font(.headline)

                if let entity = selectedEntity {
                    Text(entity.type)
                        .font(.caption)
                        .fontWeight(.medium)
                        .foregroundStyle(.secondary)
                }

                Spacer()

                if invalidHighlightCount > 0 {
                    Label("\(invalidHighlightCount) skipped", systemImage: "exclamationmark.triangle.fill")
                        .font(.caption)
                        .foregroundStyle(.orange)
                        .help("Some backend offsets could not be mapped safely to the current source text.")
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)

            Divider()

            if previewSourceText.isEmpty {
                VStack(spacing: 8) {
                    Image(systemName: "highlighter")
                        .font(.system(size: 22, weight: .regular))
                        .foregroundStyle(.secondary)
                    Text("No highlighted preview yet")
                        .font(.callout)
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                ScrollView {
                    Text(highlightedSourceText)
                        .font(.body.monospaced())
                        .lineSpacing(4)
                        .textSelection(.enabled)
                        .frame(maxWidth: .infinity, alignment: .topLeading)
                        .padding(12)
                }
                .background(Color(nsColor: .textBackgroundColor))
            }
        }
        .background(Color(nsColor: .textBackgroundColor).opacity(0.55))
    }

    private var revisionPanel: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .center, spacing: 10) {
                Text("Revision")
                    .font(.headline)

                Picker("Revision Scope", selection: $revisionScope) {
                    ForEach(RevisionScope.allCases) { scope in
                        Text(scope.title).tag(scope)
                    }
                }
                .labelsHidden()
                .pickerStyle(.segmented)
                .frame(width: 230)
                .disabled(isApplyingRevision)

                Spacer()

                Button {
                    Task { await applyRevision() }
                } label: {
                    if isApplyingRevision {
                        ProgressView()
                            .controlSize(.small)
                            .frame(width: 18, height: 18)
                    } else {
                        Label("Apply Revision", systemImage: "checkmark.circle")
                    }
                }
                .buttonStyle(.borderedProminent)
                .disabled(!canApplyRevision)
            }

            HStack(alignment: .top, spacing: 10) {
                ZStack(alignment: .topLeading) {
                    TextEditor(text: $revisionInstruction)
                        .font(.body)
                        .scrollContentBackground(.hidden)
                        .background(Color(nsColor: .textBackgroundColor))
                        .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 8, style: .continuous)
                                .stroke(Color(nsColor: .separatorColor))
                        )

                    if revisionInstruction.isEmpty {
                        Text("mask Project Phoenix")
                            .foregroundStyle(.tertiary)
                            .padding(.top, 8)
                            .padding(.leading, 5)
                            .allowsHitTesting(false)
                    }
                }
                .frame(minHeight: 72)

                RevisionParseSummary(
                    result: latestRevisionParseResult,
                    appliedCommands: latestAppliedRevisionCommands
                )
                .frame(width: 300)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(Color(nsColor: .textBackgroundColor).opacity(0.55))
    }

    private var highlightedSourceText: AttributedString {
        var attributed = AttributedString(previewSourceText)

        for entity in entities {
            guard let range = rangeMapping(for: entity, in: previewSourceText).range,
                  let attributedRange = Range(range, in: attributed)
            else { continue }

            let isFocused = entity.id == selectedEntityID || entity.id == highlightedEntityID
            attributed[attributedRange].backgroundColor = highlightColor(for: entity, isFocused: isFocused)
            attributed[attributedRange].foregroundColor = .primary
        }

        return attributed
    }

    private var invalidHighlightCount: Int {
        entities.filter { rangeMapping(for: $0, in: previewSourceText).diagnostic != nil }.count
    }

    private var entityReview: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .firstTextBaseline) {
                Text("Detected Entities")
                    .font(.headline)

                Text("\(entities.count)")
                    .font(.caption)
                    .foregroundStyle(.secondary)

                Spacer()

                if !summary.isEmpty {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 6) {
                            ForEach(summary.sorted(by: { $0.key < $1.key }), id: \.key) { item in
                                SummaryChip(type: item.key, count: item.value)
                            }
                        }
                    }
                    .frame(maxWidth: 360)
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)

            Divider()

            if entities.isEmpty {
                VStack(spacing: 8) {
                    Image(systemName: outputText.isEmpty ? "list.bullet.rectangle" : "checkmark.seal")
                        .font(.system(size: 24, weight: .regular))
                        .foregroundStyle(.secondary)
                    Text(outputText.isEmpty ? "No redaction run yet" : "No entities detected")
                        .font(.callout)
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                HStack(spacing: 0) {
                    entityList
                        .frame(minWidth: 360)

                    Divider()

                    EntityInspector(
                        entity: selectedEntity,
                        highlightDiagnostic: selectedEntity.flatMap {
                            rangeMapping(for: $0, in: previewSourceText).diagnostic
                        },
                        isSavingProfileRule: isSavingQuickRule,
                        profileRuleStatus: quickRuleStatus
                    ) { intent in
                        Task { await handleProfileRuleAction(intent) }
                    }
                        .frame(width: 280)
                }
            }
        }
        .background(Color(nsColor: .textBackgroundColor).opacity(0.55))
    }

    private var entityList: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 0) {
                EntityHeaderRow()
                ForEach(entities) { entity in
                    Divider()
                    EntityRow(
                        entity: entity,
                        isSelected: entity.id == selectedEntityID,
                        isHighlighted: entity.id == highlightedEntityID,
                        highlightDiagnostic: rangeMapping(for: entity, in: previewSourceText).diagnostic
                    ) {
                        selectedEntityID = entity.id
                        highlightedEntityID = entity.id
                    } onHover: { isHovering in
                        highlightedEntityID = isHovering ? entity.id : selectedEntityID
                    }
                }
            }
        }
    }

    private func editor(title: String, text: Binding<String>, prompt: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.headline)

            TextEditor(text: text)
                .font(.body.monospaced())
                .scrollContentBackground(.hidden)
                .background(Color(nsColor: .textBackgroundColor))
                .overlay {
                    if text.wrappedValue.isEmpty {
                        Text(prompt)
                            .foregroundStyle(.tertiary)
                            .padding(.top, 8)
                            .padding(.leading, 5)
                            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                            .allowsHitTesting(false)
                    }
                }
                .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 8, style: .continuous)
                        .stroke(Color(nsColor: .separatorColor))
                )
        }
        .padding(16)
    }

    private var canApplyRevision: Bool {
        !inputText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            && !revisionInstruction.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            && !isRedacting
            && !isApplyingRevision
    }

    @MainActor
    private func refreshHealth() async {
        healthState = .checking
        do {
            let response = try await Self.apiClient.checkHealth()
            if response.status.lowercased() == "ok" {
                healthState = .available
                workerManager.recordHealthCheck(success: true, message: nil)
                clearWorkerAvailabilityError()
            } else {
                let message = "The worker returned status \"\(response.status)\"."
                healthState = .unavailable(message)
                workerManager.recordHealthCheck(success: false, message: message)
            }
        } catch {
            healthState = .unavailable(error.localizedDescription)
            workerManager.recordHealthCheck(success: false, message: error.localizedDescription)
        }
    }

    @MainActor
    private func startWorker() async {
        await workerManager.start()
        await refreshHealth()
        await refreshModelConfig()
    }

    @MainActor
    private func stopWorker() async {
        await workerManager.stop()
        healthState = .unavailable("The local worker is stopped.")
    }

    @MainActor
    private func restartWorker() async {
        await workerManager.restart()
        await refreshHealth()
        await refreshModelConfig()
    }

    @MainActor
    private func exportDiagnostics() async {
        clearError()
        do {
            let data = try await Self.apiClient.fetchPrivacyDiagnosticsData()
            let panel = NSSavePanel()
            panel.allowedContentTypes = [.json]
            panel.nameFieldStringValue = "privacy-preflight-diagnostics.json"
            if panel.runModal() == .OK, let url = panel.url {
                try data.write(to: url, options: .atomic)
            }
            workerManager.recordHealthCheck(success: true, message: nil)
        } catch {
            setError(error.localizedDescription, source: contentErrorSource(for: error, fallback: .requestFailed))
            workerManager.recordHealthCheck(success: false, message: error.localizedDescription)
        }
    }

    @MainActor
    private func clearLocalData() async {
        let alert = NSAlert()
        alert.messageText = "Clear local Privacy Preflight data?"
        alert.informativeText = "This removes local profile rules and model provider settings. API keys in Keychain are kept unless you clear them separately from macOS Keychain."
        alert.alertStyle = .warning
        alert.addButton(withTitle: "Clear Data")
        alert.addButton(withTitle: "Cancel")
        guard alert.runModal() == .alertFirstButtonReturn else { return }

        clearError()
        do {
            let response = try await Self.apiClient.clearLocalData(clearKeychainAPIKeys: false)
            copyConfirmation = response.message
            await refreshModelConfig()
            workerManager.recordHealthCheck(success: true, message: nil)
        } catch {
            setError(error.localizedDescription, source: contentErrorSource(for: error, fallback: .requestFailed))
            workerManager.recordHealthCheck(success: false, message: error.localizedDescription)
        }
    }

    @MainActor
    private func refreshModelConfig() async {
        do {
            async let providers = Self.apiClient.fetchModelProviders()
            async let settings = Self.apiClient.fetchModelSettings()
            modelProviders = try await providers
            modelSettings = try await settings
        } catch {
            // Keep text redaction usable if model settings are unavailable.
            modelProviders = []
            modelSettings = ModelReviewSettings(
                enableLLMReview: false,
                selectedReviewProviderID: nil,
                allowRawTextForExternalModels: false
            )
        }
    }

    @MainActor
    private func redact(preserveQuickRuleStatus: Bool = false) async {
        clearError()
        copyConfirmation = nil
        if !preserveQuickRuleStatus {
            quickRuleStatus = nil
        }
        latestReviewResult = nil
        latestRevisionParseResult = nil
        latestAppliedRevisionCommands = []
        isRedacting = true

        defer { isRedacting = false }

        do {
            let response: TextRedactionResponse
            if modelSettings.enableLLMReview,
               modelSettings.selectedReviewProviderID != nil {
                let reviewResponse = try await Self.apiClient.redactTextWithReview(
                    inputText,
                    mode: mode,
                    settings: modelSettings
                )
                latestReviewResult = reviewResponse.reviewResult
                response = reviewResponse.finalResult
            } else {
                response = try await Self.apiClient.redactText(inputText, mode: mode)
            }
            outputText = response.redactedText
            entities = response.entities
            summary = response.summary
            previewSourceText = inputText
            selectedEntityID = response.entities.first?.id
            highlightedEntityID = response.entities.first?.id
            healthState = .available
        } catch {
            outputText = ""
            entities = []
            summary = [:]
            previewSourceText = ""
            selectedEntityID = nil
            highlightedEntityID = nil
            latestReviewResult = nil
            setError(error.localizedDescription, source: contentErrorSource(for: error, fallback: .redaction))
            healthState = .unavailable(error.localizedDescription)
        }
    }

    @MainActor
    private func applyRevision() async {
        guard canApplyRevision else { return }

        clearError()
        copyConfirmation = nil
        quickRuleStatus = nil
        latestReviewResult = nil
        isApplyingRevision = true

        defer { isApplyingRevision = false }

        do {
            let response = try await Self.apiClient.reviseText(
                inputText,
                mode: mode,
                instruction: revisionInstruction,
                scope: revisionScope,
                selectedEntityID: selectedEntityID,
                settings: modelSettings
            )
            latestRevisionParseResult = response.parseResult
            latestAppliedRevisionCommands = response.appliedCommands
            outputText = response.finalResult.redactedText
            entities = response.finalResult.entities
            summary = response.finalResult.summary
            previewSourceText = inputText
            selectedEntityID = response.finalResult.entities.first?.id
            highlightedEntityID = response.finalResult.entities.first?.id
            healthState = .available
        } catch {
            latestRevisionParseResult = nil
            latestAppliedRevisionCommands = []
            setError(error.localizedDescription, source: contentErrorSource(for: error, fallback: .redaction))
            healthState = .unavailable(error.localizedDescription)
        }
    }

    @MainActor
    private func handleProfileRuleAction(_ intent: ProfileQuickRuleIntent) async {
        guard let entity = selectedEntity,
              let pattern = entity.text?.trimmingCharacters(in: .whitespacesAndNewlines),
              !pattern.isEmpty
        else {
            quickRuleStatus = "Select an entity with text first."
            return
        }

        if intent == .pattern {
            profileSettingsSeed = ProfileRuleSeed(
                label: quickRuleLabel(for: entity, intent: intent),
                entityType: entity.type,
                pattern: pattern,
                replacement: entity.replacement,
                action: .mask
            )
            isShowingProfileSettings = true
            return
        }

        guard let action = intent.profileAction else { return }
        isSavingQuickRule = true
        quickRuleStatus = nil
        clearError()
        defer { isSavingQuickRule = false }

        do {
            _ = try await Self.apiClient.createProfileRule(
                ProfileRuleInput(
                    label: quickRuleLabel(for: entity, intent: intent),
                    entityType: entity.type,
                    patterns: [pattern],
                    aliases: [],
                    replacement: action == .allow ? nil : entity.replacement,
                    action: action,
                    enabled: true,
                    scope: .global
                )
            )
            await redact(preserveQuickRuleStatus: true)
            quickRuleStatus = "\(intent.doneTitle) profile rule saved."
            healthState = .available
        } catch {
            quickRuleStatus = error.localizedDescription
            healthState = .unavailable(error.localizedDescription)
        }
    }

    private func setError(_ message: String, source: ContentErrorSource) {
        errorMessage = message
        errorSource = source
    }

    private func clearError() {
        errorMessage = nil
        errorSource = nil
    }

    private func clearWorkerAvailabilityError() {
        if errorSource == .workerAvailability {
            clearError()
        }
    }

    private func copyRedactedText() {
        guard !outputText.isEmpty else { return }

        let pasteboard = NSPasteboard.general
        pasteboard.clearContents()
        pasteboard.setString(outputText, forType: .string)
        copyConfirmation = "Copied"
    }

    private func rangeMapping(for entity: RedactionEntity, in text: String) -> EntityRangeMapping {
        // Backend offsets come from Python string indices: Unicode code point counts.
        // Swift Character offsets are grapheme-cluster based, so map through unicodeScalars.
        guard let start = entity.start,
              let end = entity.end,
              start >= 0,
              end > start
        else {
            return EntityRangeMapping(
                diagnostic: "Highlight skipped: missing or invalid backend offsets."
            )
        }

        let scalarCount = text.unicodeScalars.count
        guard end <= scalarCount else {
            return EntityRangeMapping(
                diagnostic: "Highlight skipped: backend offsets are outside the source text."
            )
        }

        let scalarStart = text.unicodeScalars.index(text.unicodeScalars.startIndex, offsetBy: start)
        let scalarEnd = text.unicodeScalars.index(text.unicodeScalars.startIndex, offsetBy: end)
        guard let lowerBound = scalarStart.samePosition(in: text),
              let upperBound = scalarEnd.samePosition(in: text)
        else {
            return EntityRangeMapping(
                diagnostic: "Highlight skipped: backend offsets fall inside a composed character."
            )
        }

        let range = lowerBound..<upperBound
        if let expectedText = entity.text,
           !expectedText.isEmpty,
           String(text[range]) != expectedText {
            return EntityRangeMapping(
                diagnostic: "Highlight skipped: mapped text does not match the detected entity text."
            )
        }

        return EntityRangeMapping(range: range)
    }

    private func highlightColor(for entity: RedactionEntity, isFocused: Bool) -> Color {
        if isFocused {
            return Color.accentColor.opacity(0.36)
        }

        switch entity.type {
        case "EMAIL":
            return Color.blue.opacity(0.20)
        case "ADDRESS", "LOCAL_PATH", "URL":
            return Color.orange.opacity(0.24)
        case "SCHOOL", "COMPANY", "ORGANIZATION":
            return Color.green.opacity(0.22)
        case "API_KEY", "ID":
            return Color.red.opacity(0.20)
        default:
            return Color.purple.opacity(0.18)
        }
    }

    private func quickRuleLabel(
        for entity: RedactionEntity,
        intent: ProfileQuickRuleIntent
    ) -> String {
        "Quick \(entity.type) \(intent.labelSuffix)"
    }
}

private struct EntityRangeMapping {
    var range: Range<String.Index>?
    var diagnostic: String?
}

private enum ProfileQuickRuleIntent: Equatable {
    case mask
    case ask
    case allow
    case pattern

    var profileAction: ProfileRuleAction? {
        switch self {
        case .mask:
            return .mask
        case .ask:
            return .ask
        case .allow:
            return .allow
        case .pattern:
            return nil
        }
    }

    var labelSuffix: String {
        switch self {
        case .mask:
            return "mask"
        case .ask:
            return "review"
        case .allow:
            return "allow"
        case .pattern:
            return "pattern"
        }
    }

    var doneTitle: String {
        switch self {
        case .mask:
            return "Mask"
        case .ask:
            return "Review"
        case .allow:
            return "Allow"
        case .pattern:
            return "Pattern"
        }
    }
}

private struct ProfileRuleSeed: Equatable, Identifiable {
    let id = UUID()
    var label: String
    var entityType: String
    var pattern: String
    var replacement: String
    var action: ProfileRuleAction
}

private enum ContentErrorSource: Equatable {
    case workerAvailability
    case requestFailed
    case validation
    case redaction
}

private func contentErrorSource(for error: Error, fallback: ContentErrorSource) -> ContentErrorSource {
    if let apiError = error as? PrivacyPreflightAPIError,
       apiError.isWorkerAvailabilityError {
        return .workerAvailability
    }
    return fallback
}

private struct ImageWorkspaceView: View {
    let apiClient: PrivacyPreflightAPIClient
    @Binding var healthState: WorkerHealthState
    @Binding var errorMessage: String?
    @Binding var errorSource: ContentErrorSource?

    @State private var selectedImageURL: URL?
    @State private var originalImage: NSImage?
    @State private var redactedImage: NSImage?
    @State private var response: ImageRedactionResponse?
    @State private var imageMode: ImageRedactionMode = .safeText
    @State private var manualRectangles: [ImageManualRectangle] = []
    @State private var draftRectangle: ImageManualRectangle?
    @State private var isRedactingImage = false
    @State private var isDropTargeted = false
    @State private var statusMessage: String?

    private var displayedImage: NSImage? {
        redactedImage ?? originalImage
    }

    private var pixelSize: CGSize {
        if let response {
            return CGSize(width: response.imageWidth, height: response.imageHeight)
        }
        return originalImage?.pixelSize ?? .zero
    }

    private var canRedact: Bool {
        selectedImageURL != nil && !isRedactingImage
    }

    private var canExport: Bool {
        response != nil && !isRedactingImage
    }

    var body: some View {
        VStack(spacing: 0) {
            imageToolbar

            Divider()

            HSplitView {
                ImagePreviewCanvas(
                    image: displayedImage,
                    pixelSize: pixelSize,
                    ocrBoxes: response?.ocrBoxes ?? [],
                    redactedBoxes: response?.redactedBoxes ?? [],
                    manualRectangles: manualRectangles,
                    draftRectangle: $draftRectangle,
                    onManualRectangleAdded: addManualRectangle
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 0)
                        .stroke(isDropTargeted ? Color.accentColor : Color.clear, lineWidth: 3)
                )
                .onDrop(of: [UTType.fileURL.identifier], isTargeted: $isDropTargeted) { providers in
                    handleDrop(providers)
                }
                .frame(minWidth: 680, minHeight: 520)

                imageSidebar
                    .frame(minWidth: 320, idealWidth: 360, maxWidth: 420)
            }
        }
        .onChange(of: manualRectangles) { _, _ in
            if response != nil {
                response = nil
                redactedImage = nil
                statusMessage = "Manual rectangles changed."
            }
        }
        .onChange(of: imageMode) { _, _ in
            if response != nil {
                response = nil
                redactedImage = nil
                statusMessage = "Mode changed."
            }
        }
    }

    private var imageToolbar: some View {
        HStack(spacing: 12) {
            Button {
                openImage()
            } label: {
                Label("Choose Image", systemImage: "photo")
            }
            .buttonStyle(.bordered)

            if let selectedImageURL {
                Text(selectedImageURL.lastPathComponent)
                    .font(.callout)
                    .lineLimit(1)
                    .truncationMode(.middle)
                    .foregroundStyle(.secondary)
            } else {
                Text("Drop PNG or JPG")
                    .font(.callout)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Picker("Image Mode", selection: $imageMode) {
                ForEach(ImageRedactionMode.allCases) { mode in
                    Text(mode.title).tag(mode)
                }
            }
            .labelsHidden()
            .pickerStyle(.segmented)
            .frame(width: 160)
            .disabled(isRedactingImage)

            Button {
                Task { await runImageRedaction() }
            } label: {
                if isRedactingImage {
                    ProgressView()
                        .controlSize(.small)
                        .frame(width: 18, height: 18)
                } else {
                    Label("Redact Image", systemImage: "rectangle.fill.on.rectangle.fill")
                }
            }
            .buttonStyle(.borderedProminent)
            .disabled(!canRedact)

            Button {
                exportRedactedImage()
            } label: {
                Label("Export", systemImage: "square.and.arrow.down")
            }
            .buttonStyle(.bordered)
            .disabled(!canExport)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 12)
        .background(Color(nsColor: .windowBackgroundColor))
    }

    private var imageSidebar: some View {
        VStack(alignment: .leading, spacing: 0) {
            VStack(alignment: .leading, spacing: 10) {
                Text("Image Review")
                    .font(.headline)

                if let response {
                    HStack(spacing: 8) {
                        SummaryChip(type: "OCR", count: response.ocrBoxes.count)
                        SummaryChip(type: "Redacted", count: response.redactedBoxes.count)
                    }

                    DetailRow(label: "OCR", value: response.ocrProvider)
                    DetailRow(label: "Format", value: response.outputFormat)
                    DetailRow(label: "Pixels", value: "\(response.imageWidth)x\(response.imageHeight)")
                } else if let statusMessage {
                    Text(statusMessage)
                        .font(.callout)
                        .foregroundStyle(.secondary)
                } else {
                    Text("No image result yet")
                        .font(.callout)
                        .foregroundStyle(.secondary)
                }
            }
            .padding(16)

            Divider()

            manualRectangleSection

            Divider()

            redactedBoxSection
        }
        .background(Color(nsColor: .textBackgroundColor).opacity(0.5))
    }

    private var manualRectangleSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Manual Rectangles")
                    .font(.headline)
                Spacer()
                if !manualRectangles.isEmpty {
                    Button {
                        manualRectangles.removeAll()
                    } label: {
                        Label("Clear", systemImage: "trash")
                    }
                    .labelStyle(.iconOnly)
                    .buttonStyle(.borderless)
                    .help("Clear")
                }
            }

            if manualRectangles.isEmpty {
                Text("None")
                    .font(.callout)
                    .foregroundStyle(.secondary)
            } else {
                ForEach(manualRectangles) { rectangle in
                    HStack(spacing: 8) {
                        Image(systemName: "rectangle.dashed")
                            .foregroundStyle(.orange)
                        Text("\(Int(rectangle.width))x\(Int(rectangle.height)) at \(Int(rectangle.x)), \(Int(rectangle.y))")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                        Spacer()
                        Button {
                            manualRectangles.removeAll { $0.id == rectangle.id }
                        } label: {
                            Label("Remove", systemImage: "xmark.circle")
                        }
                        .labelStyle(.iconOnly)
                        .buttonStyle(.borderless)
                        .help("Remove")
                    }
                }
            }
        }
        .padding(16)
    }

    private var redactedBoxSection: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("Redacted Regions")
                .font(.headline)
                .padding(.horizontal, 16)
                .padding(.top, 16)
                .padding(.bottom, 10)

            if let response, !response.redactedBoxes.isEmpty {
                List(response.redactedBoxes) { box in
                    VStack(alignment: .leading, spacing: 4) {
                        HStack {
                            Text(box.source == "text_pipeline" ? "Precise" : box.source.capitalized)
                                .font(.caption)
                                .fontWeight(.medium)
                            Spacer()
                            Text("\(Int(box.width))x\(Int(box.height))")
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }

                        Text(box.entityTypes.isEmpty ? box.reason : box.entityTypes.joined(separator: ", "))
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(2)
                    }
                    .padding(.vertical, 4)
                }
                .listStyle(.inset)
            } else {
                VStack(spacing: 8) {
                    Image(systemName: "rectangle.slash")
                        .font(.system(size: 22))
                        .foregroundStyle(.secondary)
                    Text("No redacted regions")
                        .font(.callout)
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
    }

    @MainActor
    private func openImage() {
        let panel = NSOpenPanel()
        panel.allowsMultipleSelection = false
        panel.canChooseDirectories = false
        panel.allowedContentTypes = [.png, .jpeg]
        if panel.runModal() == .OK, let url = panel.url {
            loadImage(url)
        }
    }

    @MainActor
    private func loadImage(_ url: URL) {
        guard ["png", "jpg", "jpeg"].contains(url.pathExtension.lowercased()) else {
            setError("Choose a PNG or JPG image.", source: .validation)
            return
        }
        guard let image = NSImage(contentsOf: url) else {
            setError("The image could not be opened.", source: .validation)
            return
        }

        selectedImageURL = url
        originalImage = image
        redactedImage = nil
        response = nil
        manualRectangles = []
        draftRectangle = nil
        statusMessage = nil
        clearError()
    }

    private func handleDrop(_ providers: [NSItemProvider]) -> Bool {
        guard let provider = providers.first(where: { $0.hasItemConformingToTypeIdentifier(UTType.fileURL.identifier) }) else {
            return false
        }

        provider.loadItem(forTypeIdentifier: UTType.fileURL.identifier, options: nil) { item, _ in
            let url: URL?
            if let data = item as? Data {
                url = URL(dataRepresentation: data, relativeTo: nil)
            } else {
                url = item as? URL
            }

            if let url {
                Task { @MainActor in
                    loadImage(url)
                }
            }
        }
        return true
    }

    @MainActor
    private func runImageRedaction() async {
        guard let selectedImageURL else { return }

        isRedactingImage = true
        clearError()
        statusMessage = nil
        defer { isRedactingImage = false }

        do {
            let result = try await apiClient.redactImage(
                fileURL: selectedImageURL,
                mode: imageMode,
                manualRectangles: manualRectangles
            )
            guard let imageData = Data(base64Encoded: result.redactedImageBase64),
                  let image = NSImage(data: imageData)
            else {
                throw PrivacyPreflightAPIError.invalidResponse
            }
            response = result
            redactedImage = image
            statusMessage = "Redacted \(result.redactedBoxes.count) region\(result.redactedBoxes.count == 1 ? "" : "s")."
            healthState = .available
        } catch {
            response = nil
            redactedImage = nil
            setError(error.localizedDescription, source: contentErrorSource(for: error, fallback: .redaction))
            healthState = .unavailable(error.localizedDescription)
        }
    }

    @MainActor
    private func exportRedactedImage() {
        guard let response,
              let data = Data(base64Encoded: response.redactedImageBase64)
        else {
            return
        }

        let panel = NSSavePanel()
        panel.allowedContentTypes = response.mediaType == "image/jpeg" ? [.jpeg] : [.png]
        panel.nameFieldStringValue = defaultExportFilename(for: response)

        if panel.runModal() == .OK, let url = panel.url {
            do {
                try data.write(to: url, options: .atomic)
                statusMessage = "Exported \(url.lastPathComponent)."
            } catch {
                setError(error.localizedDescription, source: .requestFailed)
            }
        }
    }

    private func setError(_ message: String, source: ContentErrorSource) {
        errorMessage = message
        errorSource = source
    }

    private func clearError() {
        errorMessage = nil
        errorSource = nil
    }

    private func defaultExportFilename(for response: ImageRedactionResponse) -> String {
        let baseName = selectedImageURL?.deletingPathExtension().lastPathComponent ?? "image"
        let extensionName = response.mediaType == "image/jpeg" ? "jpg" : "png"
        return "\(baseName)-redacted.\(extensionName)"
    }

    private func addManualRectangle(_ rectangle: ImageManualRectangle) {
        manualRectangles.append(rectangle)
    }
}

private struct ImagePreviewCanvas: View {
    let image: NSImage?
    let pixelSize: CGSize
    let ocrBoxes: [ImageOCRBox]
    let redactedBoxes: [ImageRedactedBox]
    let manualRectangles: [ImageManualRectangle]
    @Binding var draftRectangle: ImageManualRectangle?
    let onManualRectangleAdded: (ImageManualRectangle) -> Void

    var body: some View {
        GeometryReader { proxy in
            let frame = fittedImageFrame(in: proxy.size)

            ZStack {
                Color(nsColor: .textBackgroundColor)

                if let image, pixelSize.width > 0, pixelSize.height > 0 {
                    Image(nsImage: image)
                        .resizable()
                        .interpolation(.high)
                        .aspectRatio(contentMode: .fit)
                        .frame(width: frame.width, height: frame.height)
                        .position(x: frame.midX, y: frame.midY)

                    ForEach(ocrBoxes) { box in
                        rectangleOverlay(
                            x: box.x,
                            y: box.y,
                            width: box.width,
                            height: box.height,
                            color: .blue,
                            fillOpacity: 0.04,
                            in: frame
                        )
                    }

                    ForEach(redactedBoxes) { box in
                        rectangleOverlay(
                            x: box.x,
                            y: box.y,
                            width: box.width,
                            height: box.height,
                            color: box.source == "manual" ? .orange : .red,
                            fillOpacity: 0.12,
                            in: frame
                        )
                    }

                    ForEach(manualRectangles) { rectangle in
                        rectangleOverlay(
                            x: rectangle.x,
                            y: rectangle.y,
                            width: rectangle.width,
                            height: rectangle.height,
                            color: .orange,
                            fillOpacity: 0.10,
                            in: frame
                        )
                    }

                    if let draftRectangle {
                        rectangleOverlay(
                            x: draftRectangle.x,
                            y: draftRectangle.y,
                            width: draftRectangle.width,
                            height: draftRectangle.height,
                            color: .orange,
                            fillOpacity: 0.16,
                            in: frame
                        )
                    }
                } else {
                    VStack(spacing: 10) {
                        Image(systemName: "photo.badge.plus")
                            .font(.system(size: 38, weight: .regular))
                            .foregroundStyle(.secondary)
                        Text("Drop PNG or JPG")
                            .font(.title3)
                            .foregroundStyle(.secondary)
                    }
                }
            }
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 4)
                    .onChanged { value in
                        guard image != nil,
                              frame.contains(value.startLocation),
                              let start = imagePoint(for: value.startLocation, in: frame),
                              let end = imagePoint(for: value.location, in: frame)
                        else {
                            return
                        }
                        draftRectangle = rectangle(from: start, to: end)
                    }
                    .onEnded { _ in
                        if let draftRectangle,
                           draftRectangle.width >= 4,
                           draftRectangle.height >= 4 {
                            onManualRectangleAdded(draftRectangle)
                        }
                        draftRectangle = nil
                    }
            )
        }
    }

    private func rectangleOverlay(
        x: Double,
        y: Double,
        width: Double,
        height: Double,
        color: Color,
        fillOpacity: Double,
        in frame: CGRect
    ) -> some View {
        let display = displayRect(
            x: x,
            y: y,
            width: width,
            height: height,
            in: frame
        )
        return Rectangle()
            .fill(color.opacity(fillOpacity))
            .overlay(Rectangle().stroke(color, lineWidth: 2))
            .frame(width: display.width, height: display.height)
            .position(x: display.midX, y: display.midY)
    }

    private func fittedImageFrame(in size: CGSize) -> CGRect {
        guard pixelSize.width > 0, pixelSize.height > 0 else {
            return .zero
        }
        let scale = min(size.width / pixelSize.width, size.height / pixelSize.height)
        let width = pixelSize.width * scale
        let height = pixelSize.height * scale
        return CGRect(
            x: (size.width - width) / 2,
            y: (size.height - height) / 2,
            width: width,
            height: height
        )
    }

    private func displayRect(
        x: Double,
        y: Double,
        width: Double,
        height: Double,
        in frame: CGRect
    ) -> CGRect {
        guard pixelSize.width > 0, pixelSize.height > 0 else {
            return .zero
        }
        let scaleX = frame.width / pixelSize.width
        let scaleY = frame.height / pixelSize.height
        return CGRect(
            x: frame.minX + x * scaleX,
            y: frame.minY + y * scaleY,
            width: width * scaleX,
            height: height * scaleY
        )
    }

    private func imagePoint(for location: CGPoint, in frame: CGRect) -> CGPoint? {
        guard frame.width > 0, frame.height > 0 else {
            return nil
        }
        let clampedX = min(max(location.x, frame.minX), frame.maxX)
        let clampedY = min(max(location.y, frame.minY), frame.maxY)
        let scaleX = pixelSize.width / frame.width
        let scaleY = pixelSize.height / frame.height
        return CGPoint(
            x: (clampedX - frame.minX) * scaleX,
            y: (clampedY - frame.minY) * scaleY
        )
    }

    private func rectangle(from start: CGPoint, to end: CGPoint) -> ImageManualRectangle {
        ImageManualRectangle(
            x: min(start.x, end.x),
            y: min(start.y, end.y),
            width: abs(end.x - start.x),
            height: abs(end.y - start.y)
        )
    }
}

private struct PDFWorkspaceView: View {
    let apiClient: PrivacyPreflightAPIClient
    @Binding var healthState: WorkerHealthState
    @Binding var errorMessage: String?
    @Binding var errorSource: ContentErrorSource?

    @State private var selectedPDFURL: URL?
    @State private var analysis: PDFRedactionAnalysisResponse?
    @State private var exportResponse: PDFRedactionExportResponse?
    @State private var pageImages: [Int: NSImage] = [:]
    @State private var currentPageIndex = 0
    @State private var pdfMode: TextRedactionMode = .balanced
    @State private var manualRectangles: [PDFManualRectangle] = []
    @State private var draftRectangle: PDFManualRectangle?
    @State private var isAnalyzingPDF = false
    @State private var isExportingPDF = false
    @State private var isDropTargeted = false
    @State private var statusMessage: String?

    private var latestPageCount: Int {
        exportResponse?.pageCount ?? analysis?.pageCount ?? 0
    }

    private var latestRegions: [PDFRedactionRegion] {
        exportResponse?.redactionRegions ?? analysis?.redactionRegions ?? []
    }

    private var latestSummary: [String: Int] {
        exportResponse?.summary ?? analysis?.summary ?? [:]
    }

    private var latestDocumentType: String? {
        exportResponse?.documentType ?? analysis?.documentType
    }

    private var currentPage: PDFPagePreview? {
        let pages = exportResponse?.pages ?? analysis?.pages ?? []
        return pages.first { $0.pageIndex == currentPageIndex } ?? pages.first
    }

    private var currentPageSize: CGSize {
        guard let currentPage else { return .zero }
        return CGSize(width: currentPage.width, height: currentPage.height)
    }

    private var currentPageImage: NSImage? {
        pageImages[currentPage?.pageIndex ?? currentPageIndex]
    }

    private var currentRegions: [PDFRedactionRegion] {
        latestRegions.filter { $0.pageIndex == currentPageIndex }
    }

    private var currentManualRectangles: [PDFManualRectangle] {
        manualRectangles.filter { $0.pageIndex == currentPageIndex }
    }

    private var canAnalyze: Bool {
        selectedPDFURL != nil && !isAnalyzingPDF && !isExportingPDF
    }

    private var canExport: Bool {
        selectedPDFURL != nil && analysis != nil && !isAnalyzingPDF && !isExportingPDF
    }

    var body: some View {
        VStack(spacing: 0) {
            pdfToolbar

            Divider()

            HSplitView {
                PDFPreviewCanvas(
                    image: currentPageImage,
                    pageIndex: currentPageIndex,
                    pageSize: currentPageSize,
                    regions: currentRegions,
                    manualRectangles: currentManualRectangles,
                    draftRectangle: $draftRectangle,
                    onManualRectangleAdded: addManualRectangle
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 0)
                        .stroke(isDropTargeted ? Color.accentColor : Color.clear, lineWidth: 3)
                )
                .onDrop(of: [UTType.fileURL.identifier], isTargeted: $isDropTargeted) { providers in
                    handleDrop(providers)
                }
                .frame(minWidth: 680, minHeight: 520)

                pdfSidebar
                    .frame(minWidth: 340, idealWidth: 380, maxWidth: 440)
            }
        }
        .onChange(of: manualRectangles) { _, _ in
            if exportResponse != nil {
                exportResponse = nil
                statusMessage = "Manual rectangles changed."
            }
        }
        .onChange(of: pdfMode) { _, _ in
            if analysis != nil || exportResponse != nil {
                analysis = nil
                exportResponse = nil
                pageImages = [:]
                manualRectangles = []
                draftRectangle = nil
                statusMessage = "Mode changed."
            }
        }
        .onChange(of: currentPageIndex) { _, _ in
            draftRectangle = nil
        }
    }

    private var pdfToolbar: some View {
        HStack(spacing: 12) {
            Button {
                openPDF()
            } label: {
                Label("Choose PDF", systemImage: "doc.richtext")
            }
            .buttonStyle(.bordered)

            if let selectedPDFURL {
                Text(selectedPDFURL.lastPathComponent)
                    .font(.callout)
                    .lineLimit(1)
                    .truncationMode(.middle)
                    .foregroundStyle(.secondary)
            } else {
                Text("Drop PDF")
                    .font(.callout)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            if let analysis {
                Picker("Page", selection: $currentPageIndex) {
                    ForEach(analysis.pages) { page in
                        Text("\(page.pageIndex + 1)").tag(page.pageIndex)
                    }
                }
                .labelsHidden()
                .frame(width: 90)
                .disabled(isAnalyzingPDF || isExportingPDF)
            }

            Picker("PDF Mode", selection: $pdfMode) {
                ForEach(TextRedactionMode.allCases) { mode in
                    Text(mode.title).tag(mode)
                }
            }
            .labelsHidden()
            .pickerStyle(.segmented)
            .frame(width: 190)
            .disabled(isAnalyzingPDF || isExportingPDF)

            Button {
                Task { await analyzePDF() }
            } label: {
                if isAnalyzingPDF {
                    ProgressView()
                        .controlSize(.small)
                        .frame(width: 18, height: 18)
                } else {
                    Label("Detect", systemImage: "magnifyingglass")
                }
            }
            .buttonStyle(.bordered)
            .disabled(!canAnalyze)

            Button {
                Task { await exportPDF() }
            } label: {
                if isExportingPDF {
                    ProgressView()
                        .controlSize(.small)
                        .frame(width: 18, height: 18)
                } else {
                    Label("Export PDF", systemImage: "square.and.arrow.down")
                }
            }
            .buttonStyle(.borderedProminent)
            .disabled(!canExport)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 12)
        .background(Color(nsColor: .windowBackgroundColor))
    }

    private var pdfSidebar: some View {
        VStack(alignment: .leading, spacing: 0) {
            VStack(alignment: .leading, spacing: 10) {
                Text("PDF Review")
                    .font(.headline)

                if analysis != nil || exportResponse != nil {
                    HStack(spacing: 8) {
                        SummaryChip(type: "Pages", count: latestPageCount)
                        SummaryChip(type: "Regions", count: latestRegions.count)
                    }

                    if let latestDocumentType {
                        DetailRow(label: "Document", value: latestDocumentType.capitalized)
                    }

                    if !latestSummary.isEmpty {
                        DetailRow(
                            label: "Sources",
                            value: latestSummary
                                .sorted(by: { $0.key < $1.key })
                                .map { "\($0.key): \($0.value)" }
                                .joined(separator: ", ")
                        )
                    }

                    if let validation = exportResponse?.validation {
                        validationSummary(validation)
                    }
                } else if let statusMessage {
                    Text(statusMessage)
                        .font(.callout)
                        .foregroundStyle(.secondary)
                } else {
                    Text("No PDF result yet")
                        .font(.callout)
                        .foregroundStyle(.secondary)
                }
            }
            .padding(16)

            Divider()

            pdfManualRectangleSection

            Divider()

            pdfRegionSection
        }
        .background(Color(nsColor: .textBackgroundColor).opacity(0.5))
    }

    private func validationSummary(_ validation: PDFValidationResult) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 6) {
                Image(systemName: validationIcon(validation))
                    .foregroundStyle(validationColor(validation))
                Text(validation.status.capitalized)
                    .font(.caption)
                    .fontWeight(.semibold)
                Spacer(minLength: 0)
            }

            Text(validation.message)
                .font(.caption)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)

            DetailRow(label: "Checked Terms", value: "\(validation.checkedTermsCount)")
        }
    }

    private var pdfManualRectangleSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Manual Rectangles")
                    .font(.headline)
                Spacer()
                if !manualRectangles.isEmpty {
                    Button {
                        manualRectangles.removeAll()
                    } label: {
                        Label("Clear", systemImage: "trash")
                    }
                    .labelStyle(.iconOnly)
                    .buttonStyle(.borderless)
                    .help("Clear")
                }
            }

            if manualRectangles.isEmpty {
                Text("None")
                    .font(.callout)
                    .foregroundStyle(.secondary)
            } else {
                ForEach(manualRectangles) { rectangle in
                    HStack(spacing: 8) {
                        Image(systemName: "rectangle.dashed")
                            .foregroundStyle(.orange)
                        Text("p\(rectangle.pageIndex + 1) · \(Int(rectangle.width))x\(Int(rectangle.height)) at \(Int(rectangle.x)), \(Int(rectangle.y))")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                        Spacer()
                        Button {
                            manualRectangles.removeAll { $0.id == rectangle.id }
                        } label: {
                            Label("Remove", systemImage: "xmark.circle")
                        }
                        .labelStyle(.iconOnly)
                        .buttonStyle(.borderless)
                        .help("Remove")
                    }
                }
            }
        }
        .padding(16)
    }

    private var pdfRegionSection: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("Redacted Regions")
                .font(.headline)
                .padding(.horizontal, 16)
                .padding(.top, 16)
                .padding(.bottom, 10)

            if !latestRegions.isEmpty {
                List(latestRegions) { region in
                    VStack(alignment: .leading, spacing: 4) {
                        HStack {
                            Text(regionTitle(region))
                                .font(.caption)
                                .fontWeight(.medium)
                            Spacer()
                            Text("p\(region.pageIndex + 1)")
                                .font(.caption2.monospacedDigit())
                                .foregroundStyle(.secondary)
                        }

                        if let text = region.text, !text.isEmpty {
                            Text(text)
                                .font(.caption.monospaced())
                                .lineLimit(1)
                                .truncationMode(.middle)
                                .textSelection(.enabled)
                        }

                        Text(region.entityTypes.isEmpty ? region.reason : region.entityTypes.joined(separator: ", "))
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(2)
                    }
                    .padding(.vertical, 4)
                }
                .listStyle(.inset)
            } else {
                VStack(spacing: 8) {
                    Image(systemName: "rectangle.slash")
                        .font(.system(size: 22))
                        .foregroundStyle(.secondary)
                    Text("No redacted regions")
                        .font(.callout)
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
    }

    @MainActor
    private func openPDF() {
        let panel = NSOpenPanel()
        panel.allowsMultipleSelection = false
        panel.canChooseDirectories = false
        panel.allowedContentTypes = [.pdf]
        if panel.runModal() == .OK, let url = panel.url {
            loadPDF(url, analyzeAfterLoad: true)
        }
    }

    @MainActor
    private func loadPDF(_ url: URL, analyzeAfterLoad: Bool) {
        guard url.pathExtension.lowercased() == "pdf" else {
            setError("Choose a PDF file.", source: .validation)
            return
        }

        selectedPDFURL = url
        analysis = nil
        exportResponse = nil
        pageImages = [:]
        currentPageIndex = 0
        manualRectangles = []
        draftRectangle = nil
        statusMessage = nil
        clearError()

        if analyzeAfterLoad {
            Task { await analyzePDF() }
        }
    }

    private func handleDrop(_ providers: [NSItemProvider]) -> Bool {
        guard let provider = providers.first(where: { $0.hasItemConformingToTypeIdentifier(UTType.fileURL.identifier) }) else {
            return false
        }

        provider.loadItem(forTypeIdentifier: UTType.fileURL.identifier, options: nil) { item, _ in
            let url: URL?
            if let data = item as? Data {
                url = URL(dataRepresentation: data, relativeTo: nil)
            } else {
                url = item as? URL
            }

            if let url {
                Task { @MainActor in
                    loadPDF(url, analyzeAfterLoad: true)
                }
            }
        }
        return true
    }

    @MainActor
    private func analyzePDF() async {
        guard let selectedPDFURL else { return }

        isAnalyzingPDF = true
        clearError()
        statusMessage = nil
        exportResponse = nil
        defer { isAnalyzingPDF = false }

        do {
            let result = try await apiClient.analyzePDF(
                fileURL: selectedPDFURL,
                mode: pdfMode
            )
            analysis = result
            pageImages = decodePageImages(result.pages)
            currentPageIndex = result.pages.first?.pageIndex ?? 0
            statusMessage = "Detected \(result.redactionRegions.count) region\(result.redactionRegions.count == 1 ? "" : "s")."
            healthState = .available
        } catch {
            analysis = nil
            exportResponse = nil
            pageImages = [:]
            setError(error.localizedDescription, source: contentErrorSource(for: error, fallback: .redaction))
            healthState = .unavailable(error.localizedDescription)
        }
    }

    @MainActor
    private func exportPDF() async {
        guard let selectedPDFURL else { return }

        isExportingPDF = true
        clearError()
        statusMessage = nil
        defer { isExportingPDF = false }

        do {
            let result = try await apiClient.exportRedactedPDF(
                fileURL: selectedPDFURL,
                mode: pdfMode,
                manualRectangles: manualRectangles
            )
            exportResponse = result
            pageImages = decodePageImages(result.pages)
            statusMessage = "Validation \(result.validation.status)."
            healthState = .available
            if result.validation.safe {
                saveRedactedPDF(result)
            }
        } catch {
            exportResponse = nil
            setError(error.localizedDescription, source: contentErrorSource(for: error, fallback: .redaction))
            healthState = .unavailable(error.localizedDescription)
        }
    }

    @MainActor
    private func saveRedactedPDF(_ result: PDFRedactionExportResponse) {
        guard let data = Data(base64Encoded: result.redactedPDFBase64) else {
            setError("The worker returned an unreadable PDF.", source: .redaction)
            return
        }

        let panel = NSSavePanel()
        panel.allowedContentTypes = [.pdf]
        panel.nameFieldStringValue = defaultExportFilename()

        if panel.runModal() == .OK, let url = panel.url {
            if let selectedPDFURL,
               selectedPDFURL.standardizedFileURL == url.standardizedFileURL {
                setError("Choose a new file name so the original PDF is not overwritten.", source: .validation)
                return
            }

            do {
                try data.write(to: url, options: .atomic)
                statusMessage = "Exported \(url.lastPathComponent)."
            } catch {
                setError(error.localizedDescription, source: .requestFailed)
            }
        }
    }

    private func setError(_ message: String, source: ContentErrorSource) {
        errorMessage = message
        errorSource = source
    }

    private func clearError() {
        errorMessage = nil
        errorSource = nil
    }

    private func defaultExportFilename() -> String {
        let baseName = selectedPDFURL?.deletingPathExtension().lastPathComponent ?? "document"
        return "\(baseName)-redacted.pdf"
    }

    private func addManualRectangle(_ rectangle: PDFManualRectangle) {
        manualRectangles.append(rectangle)
    }

    private func decodePageImages(_ pages: [PDFPagePreview]) -> [Int: NSImage] {
        Dictionary(
            uniqueKeysWithValues: pages.compactMap { page in
                guard let data = Data(base64Encoded: page.previewImageBase64),
                      let image = NSImage(data: data)
                else {
                    return nil
                }
                return (page.pageIndex, image)
            }
        )
    }

    private func regionTitle(_ region: PDFRedactionRegion) -> String {
        switch region.source {
        case "text_pdf":
            return "PDF Text"
        case "ocr":
            return "OCR"
        case "manual":
            return "Manual"
        default:
            return region.source.capitalized
        }
    }

    private func validationIcon(_ validation: PDFValidationResult) -> String {
        if !validation.safe || validation.status == "failed" {
            return "exclamationmark.triangle.fill"
        }
        return validation.status == "warning" ? "exclamationmark.triangle.fill" : "checkmark.seal"
    }

    private func validationColor(_ validation: PDFValidationResult) -> Color {
        if !validation.safe || validation.status == "failed" {
            return .red
        }
        return validation.status == "warning" ? .orange : .green
    }
}

private struct PDFPreviewCanvas: View {
    let image: NSImage?
    let pageIndex: Int
    let pageSize: CGSize
    let regions: [PDFRedactionRegion]
    let manualRectangles: [PDFManualRectangle]
    @Binding var draftRectangle: PDFManualRectangle?
    let onManualRectangleAdded: (PDFManualRectangle) -> Void

    var body: some View {
        GeometryReader { proxy in
            let frame = fittedPageFrame(in: proxy.size)

            ZStack {
                Color(nsColor: .textBackgroundColor)

                if let image, pageSize.width > 0, pageSize.height > 0 {
                    Image(nsImage: image)
                        .resizable()
                        .interpolation(.high)
                        .aspectRatio(contentMode: .fit)
                        .frame(width: frame.width, height: frame.height)
                        .position(x: frame.midX, y: frame.midY)

                    ForEach(regions) { region in
                        rectangleOverlay(
                            x: region.x,
                            y: region.y,
                            width: region.width,
                            height: region.height,
                            color: region.source == "manual" ? .orange : .red,
                            fillOpacity: 0.12,
                            in: frame
                        )
                    }

                    ForEach(manualRectangles) { rectangle in
                        rectangleOverlay(
                            x: rectangle.x,
                            y: rectangle.y,
                            width: rectangle.width,
                            height: rectangle.height,
                            color: .orange,
                            fillOpacity: 0.10,
                            in: frame
                        )
                    }

                    if let draftRectangle {
                        rectangleOverlay(
                            x: draftRectangle.x,
                            y: draftRectangle.y,
                            width: draftRectangle.width,
                            height: draftRectangle.height,
                            color: .orange,
                            fillOpacity: 0.16,
                            in: frame
                        )
                    }
                } else {
                    VStack(spacing: 10) {
                        Image(systemName: "doc.badge.plus")
                            .font(.system(size: 38, weight: .regular))
                            .foregroundStyle(.secondary)
                        Text("Drop PDF")
                            .font(.title3)
                            .foregroundStyle(.secondary)
                    }
                }
            }
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 4)
                    .onChanged { value in
                        guard image != nil,
                              frame.contains(value.startLocation),
                              let start = pagePoint(for: value.startLocation, in: frame),
                              let end = pagePoint(for: value.location, in: frame)
                        else {
                            return
                        }
                        draftRectangle = rectangle(from: start, to: end)
                    }
                    .onEnded { _ in
                        if let draftRectangle,
                           draftRectangle.width >= 4,
                           draftRectangle.height >= 4 {
                            onManualRectangleAdded(draftRectangle)
                        }
                        draftRectangle = nil
                    }
            )
        }
    }

    private func rectangleOverlay(
        x: Double,
        y: Double,
        width: Double,
        height: Double,
        color: Color,
        fillOpacity: Double,
        in frame: CGRect
    ) -> some View {
        let display = displayRect(
            x: x,
            y: y,
            width: width,
            height: height,
            in: frame
        )
        return Rectangle()
            .fill(color.opacity(fillOpacity))
            .overlay(Rectangle().stroke(color, lineWidth: 2))
            .frame(width: display.width, height: display.height)
            .position(x: display.midX, y: display.midY)
    }

    private func fittedPageFrame(in size: CGSize) -> CGRect {
        guard pageSize.width > 0, pageSize.height > 0 else {
            return .zero
        }
        let scale = min(size.width / pageSize.width, size.height / pageSize.height)
        let width = pageSize.width * scale
        let height = pageSize.height * scale
        return CGRect(
            x: (size.width - width) / 2,
            y: (size.height - height) / 2,
            width: width,
            height: height
        )
    }

    private func displayRect(
        x: Double,
        y: Double,
        width: Double,
        height: Double,
        in frame: CGRect
    ) -> CGRect {
        guard pageSize.width > 0, pageSize.height > 0 else {
            return .zero
        }
        let scaleX = frame.width / pageSize.width
        let scaleY = frame.height / pageSize.height
        return CGRect(
            x: frame.minX + x * scaleX,
            y: frame.minY + y * scaleY,
            width: width * scaleX,
            height: height * scaleY
        )
    }

    private func pagePoint(for location: CGPoint, in frame: CGRect) -> CGPoint? {
        guard frame.width > 0, frame.height > 0 else {
            return nil
        }
        let clampedX = min(max(location.x, frame.minX), frame.maxX)
        let clampedY = min(max(location.y, frame.minY), frame.maxY)
        let scaleX = pageSize.width / frame.width
        let scaleY = pageSize.height / frame.height
        return CGPoint(
            x: (clampedX - frame.minX) * scaleX,
            y: (clampedY - frame.minY) * scaleY
        )
    }

    private func rectangle(from start: CGPoint, to end: CGPoint) -> PDFManualRectangle {
        PDFManualRectangle(
            pageIndex: pageIndex,
            x: min(start.x, end.x),
            y: min(start.y, end.y),
            width: abs(end.x - start.x),
            height: abs(end.y - start.y)
        )
    }
}

private extension NSImage {
    var pixelSize: CGSize {
        if let representation = representations.first {
            return CGSize(
                width: representation.pixelsWide,
                height: representation.pixelsHigh
            )
        }
        return size
    }
}

private enum WorkerHealthState: Equatable {
    case checking
    case available
    case unavailable(String)

    var title: String {
        switch self {
        case .checking:
            return "Checking worker"
        case .available:
            return "Worker ready"
        case .unavailable:
            return "Worker offline"
        }
    }

    var helpText: String {
        switch self {
        case .checking:
            return "Checking the local worker"
        case .available:
            return "The local worker is ready"
        case .unavailable(let message):
            return message
        }
    }

    var color: Color {
        switch self {
        case .checking:
            return .orange
        case .available:
            return .green
        case .unavailable:
            return .red
        }
    }
}

private struct WorkerStatusPanel: View {
    @ObservedObject var workerManager: WorkerLifecycleManager
    let onStart: () async -> Void
    let onStop: () async -> Void
    let onRestart: () async -> Void
    let onCheck: () async -> Void
    let onExportDiagnostics: () async -> Void
    let onClearLocalData: () async -> Void

    @State private var isWorking = false
    @State private var isExportingDiagnostics = false
    @State private var isClearingData = false

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .center, spacing: 12) {
                Label(workerManager.statusTitle, systemImage: statusSymbol)
                    .font(.callout)
                    .foregroundStyle(statusColor)
                    .frame(width: 140, alignment: .leading)

                VStack(alignment: .leading, spacing: 2) {
                    Text(workerManager.endpointDisplay)
                        .font(.caption.monospaced())
                        .textSelection(.enabled)
                    Text(workerManager.launchModeDescription)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                        .truncationMode(.middle)
                }

                Spacer()

                Text(lastHealthCheckText)
                    .font(.caption)
                    .foregroundStyle(.secondary)

                Button {
                    runWorkerAction(onStart)
                } label: {
                    Label("Start", systemImage: "play.fill")
                }
                .buttonStyle(.bordered)
                .disabled(isWorking || !workerManager.canStart)

                Button {
                    runWorkerAction(onStop)
                } label: {
                    Label("Stop", systemImage: "stop.fill")
                }
                .buttonStyle(.bordered)
                .disabled(isWorking || !workerManager.canStop)

                Button {
                    runWorkerAction(onRestart)
                } label: {
                    Label("Restart", systemImage: "arrow.clockwise")
                }
                .buttonStyle(.bordered)
                .disabled(isWorking || !workerManager.canRestart)

                Button {
                    runWorkerAction(onCheck)
                } label: {
                    Label("Check", systemImage: "heart.text.square")
                }
                .buttonStyle(.bordered)
                .disabled(isWorking)

                Menu {
                    Button {
                        Task { await exportDiagnostics() }
                    } label: {
                        Label("Export Diagnostics", systemImage: "square.and.arrow.down")
                    }
                    .disabled(isExportingDiagnostics)

                    Button(role: .destructive) {
                        Task { await clearLocalData() }
                    } label: {
                        Label("Clear Local Data", systemImage: "trash")
                    }
                    .disabled(isClearingData)
                } label: {
                    Label("Privacy", systemImage: "lock.shield")
                }
            }

            if let latestError = workerManager.latestError, !latestError.isEmpty {
                Label(latestError, systemImage: "exclamationmark.triangle.fill")
                    .font(.caption)
                    .foregroundStyle(.orange)
                    .lineLimit(2)
                    .textSelection(.enabled)
            }
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 10)
        .background(Color(nsColor: .textBackgroundColor).opacity(0.55))
        .overlay(Divider(), alignment: .bottom)
    }

    private var statusSymbol: String {
        switch workerManager.status {
        case .running:
            return "checkmark.circle.fill"
        case .starting:
            return "clock.arrow.circlepath"
        case .stopping, .stopped:
            return "pause.circle"
        case .unavailable:
            return "exclamationmark.triangle.fill"
        }
    }

    private var statusColor: Color {
        switch workerManager.status {
        case .running:
            return .green
        case .starting, .stopping:
            return .orange
        case .stopped:
            return .secondary
        case .unavailable:
            return .red
        }
    }

    private var lastHealthCheckText: String {
        guard let lastHealthCheck = workerManager.lastHealthCheck else {
            return "No health check yet"
        }
        return "Checked \(lastHealthCheck.formatted(date: .omitted, time: .shortened))"
    }

    private func runWorkerAction(_ action: @escaping () async -> Void) {
        Task {
            isWorking = true
            await action()
            isWorking = false
        }
    }

    private func exportDiagnostics() async {
        isExportingDiagnostics = true
        await onExportDiagnostics()
        isExportingDiagnostics = false
    }

    private func clearLocalData() async {
        isClearingData = true
        await onClearLocalData()
        isClearingData = false
    }
}

private struct SummaryChip: View {
    let type: String
    let count: Int

    var body: some View {
        HStack(spacing: 5) {
            Text(type)
                .font(.caption)
                .fontWeight(.medium)
            Text("\(count)")
                .font(.caption.monospacedDigit())
                .foregroundStyle(.secondary)
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .background(Color.accentColor.opacity(0.12))
        .clipShape(Capsule())
    }
}

private struct ModelReviewBanner: View {
    let result: ModelReviewResult

    var body: some View {
        HStack(alignment: .top, spacing: 8) {
            Image(systemName: iconName)
                .foregroundStyle(color)
                .padding(.top, 1)

            VStack(alignment: .leading, spacing: 3) {
                Text(title)
                    .font(.callout)
                    .fontWeight(.medium)

                if let detail {
                    Text(detail)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }

            Spacer(minLength: 0)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 9)
        .background(color.opacity(0.1))
        .overlay(Divider(), alignment: .bottom)
    }

    private var title: String {
        if !result.parsed {
            return "LLM review response was not usable"
        }

        let risk = result.suggestion?.riskLevel.capitalized ?? "Unknown"
        let appliedCount = result.appliedMissedItems.reduce(0) { $0 + $1.occurrenceCount }
        if appliedCount > 0 {
            return "LLM review applied \(appliedCount) exact-match suggestion\(appliedCount == 1 ? "" : "s")"
        }
        return "LLM review completed · \(risk) risk"
    }

    private var detail: String? {
        if let parseError = result.parseError {
            return parseError
        }
        if let warning = result.warning {
            return warning
        }
        if !result.invalidSuggestions.isEmpty {
            return result.invalidSuggestions.joined(separator: " ")
        }
        if let providerName = result.providerName {
            return result.providerIsLocal
                ? "\(providerName) reviewed the original text locally."
                : "\(providerName) reviewed redacted-only content."
        }
        return nil
    }

    private var iconName: String {
        if !result.parsed {
            return "exclamationmark.triangle.fill"
        }
        return result.appliedMissedItems.isEmpty ? "checkmark.seal" : "sparkles"
    }

    private var color: Color {
        if !result.parsed || result.rawTextBlocked || !(result.invalidSuggestions.isEmpty) {
            return .orange
        }
        return .green
    }
}

private struct RevisionParseSummary: View {
    let result: RevisionParseResult?
    let appliedCommands: [AppliedRevisionCommand]

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 6) {
                Image(systemName: iconName)
                    .foregroundStyle(color)
                Text(title)
                    .font(.caption)
                    .fontWeight(.semibold)
                    .lineLimit(1)
                Spacer(minLength: 0)
            }

            if let detail {
                Text(detail)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)
            }

            if let result, !result.commands.isEmpty {
                ScrollView {
                    VStack(alignment: .leading, spacing: 4) {
                        ForEach(Array(result.commands.enumerated()), id: \.offset) { index, command in
                            RevisionCommandRow(
                                command: command,
                                applied: appliedCommands[safe: index]
                            )
                        }
                    }
                }
                .frame(maxHeight: 84)
            } else if let result, !result.invalidCommands.isEmpty {
                Text(result.invalidCommands.joined(separator: " "))
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .lineLimit(3)
                    .fixedSize(horizontal: false, vertical: true)
            } else {
                Spacer(minLength: 0)
            }
        }
        .padding(10)
        .background(Color(nsColor: .windowBackgroundColor).opacity(0.65))
        .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 8, style: .continuous)
                .stroke(Color(nsColor: .separatorColor))
        )
    }

    private var title: String {
        guard let result else { return "No revision applied" }
        if !result.parsed { return "Revision parse failed" }
        if result.commands.isEmpty { return "No commands parsed" }
        let count = result.commands.count
        return "\(count) command\(count == 1 ? "" : "s") parsed"
    }

    private var detail: String? {
        guard let result else { return nil }
        if let parseError = result.parseError { return parseError }
        if let warning = result.warning { return warning }
        if !result.invalidCommands.isEmpty {
            return result.invalidCommands.joined(separator: " ")
        }
        if result.rawTextSent, let providerName = result.providerName {
            return result.providerIsLocal
                ? "\(providerName) parsed locally."
                : "\(providerName) parsed with raw sharing enabled."
        }
        return result.parser == "deterministic" ? "Deterministic parser" : nil
    }

    private var iconName: String {
        guard let result else { return "text.badge.plus" }
        if !result.parsed || result.rawTextBlocked || !result.invalidCommands.isEmpty {
            return "exclamationmark.triangle.fill"
        }
        return result.commands.isEmpty ? "questionmark.circle" : "checkmark.seal"
    }

    private var color: Color {
        guard let result else { return .secondary }
        if !result.parsed || result.rawTextBlocked || !result.invalidCommands.isEmpty {
            return .orange
        }
        return result.commands.isEmpty ? .secondary : .green
    }
}

private struct RevisionCommandRow: View {
    let command: RevisionCommand
    let applied: AppliedRevisionCommand?

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            HStack(spacing: 6) {
                Text(command.intent.replacingOccurrences(of: "_", with: " ").uppercased())
                    .font(.caption2)
                    .fontWeight(.semibold)
                    .lineLimit(1)

                Text(command.scope.title)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)

                Spacer(minLength: 0)

                if let applied {
                    Text(appliedStatus(applied))
                        .font(.caption2.monospacedDigit())
                        .foregroundStyle(applied.skippedReason == nil ? Color.secondary : Color.orange)
                        .lineLimit(1)
                }
            }

            Text(commandDetail)
                .font(.caption2.monospaced())
                .foregroundStyle(.secondary)
                .lineLimit(1)
                .truncationMode(.middle)
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 5)
        .background(Color.accentColor.opacity(0.08))
        .clipShape(RoundedRectangle(cornerRadius: 6, style: .continuous))
    }

    private var commandDetail: String {
        let target = command.targetText
            ?? command.targetEntityID.map { "#\($0)" }
            ?? command.entityType
            ?? "target"
        if let replacement = command.replacement {
            return "\(target) -> \(replacement)"
        }
        if let action = command.action {
            return "\(target) · \(action.title)"
        }
        return target
    }

    private func appliedStatus(_ applied: AppliedRevisionCommand) -> String {
        if applied.skippedReason != nil {
            return "skipped"
        }
        let profileCount = applied.profileRuleIDs.count + applied.updatedProfileRuleIDs.count
        if profileCount > 0 {
            return "\(profileCount) rule\(profileCount == 1 ? "" : "s")"
        }
        return "\(applied.occurrenceCount)"
    }
}

private struct EntityHeaderRow: View {
    var body: some View {
        HStack(spacing: 12) {
            Text("Entity")
                .frame(width: 110, alignment: .leading)
            Text("Source")
                .frame(width: 120, alignment: .leading)
            Text("Replacement")
                .frame(minWidth: 110, maxWidth: .infinity, alignment: .leading)
            Text("Confidence")
                .frame(width: 86, alignment: .trailing)
        }
        .font(.caption)
        .fontWeight(.semibold)
        .foregroundStyle(.secondary)
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
    }
}

private struct EntityRow: View {
    let entity: RedactionEntity
    let isSelected: Bool
    let isHighlighted: Bool
    let highlightDiagnostic: String?
    let action: () -> Void
    let onHover: (Bool) -> Void

    var body: some View {
        Button(action: action) {
            HStack(alignment: .top, spacing: 12) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(entity.type)
                        .font(.caption)
                        .fontWeight(.semibold)
                        .lineLimit(1)
                        .truncationMode(.middle)

                    if let text = entity.text, !text.isEmpty {
                        Text(text)
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                            .truncationMode(.middle)
                            .textSelection(.enabled)
                    }
                }
                .frame(width: 110, alignment: .leading)

                Text(entity.source)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                    .truncationMode(.middle)
                    .frame(width: 120, alignment: .leading)

                Text(entity.replacement)
                    .font(.caption.monospaced())
                    .lineLimit(1)
                    .truncationMode(.middle)
                    .textSelection(.enabled)
                    .frame(minWidth: 110, maxWidth: .infinity, alignment: .leading)

                Text(confidenceText)
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(.secondary)
                    .frame(width: 86, alignment: .trailing)

                if let highlightDiagnostic {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .font(.caption)
                        .foregroundStyle(.orange)
                        .help(highlightDiagnostic)
                        .accessibilityLabel("Highlight warning")
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
            .background(rowBackground)
        }
        .buttonStyle(.plain)
        .contentShape(Rectangle())
        .onHover(perform: onHover)
    }

    private var confidenceText: String {
        guard let confidence = entity.confidence else {
            return "n/a"
        }

        return "\(Int((confidence * 100).rounded()))%"
    }

    private var rowBackground: Color {
        if isSelected {
            return Color.accentColor.opacity(0.14)
        }
        if isHighlighted {
            return Color.accentColor.opacity(0.07)
        }
        return Color.clear
    }
}

private struct EntityInspector: View {
    let entity: RedactionEntity?
    let highlightDiagnostic: String?
    let isSavingProfileRule: Bool
    let profileRuleStatus: String?
    let onProfileRuleAction: (ProfileQuickRuleIntent) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("Inspector")
                .font(.headline)
                .padding(.horizontal, 14)
                .padding(.vertical, 10)

            Divider()

            if let entity {
                ScrollView {
                    VStack(alignment: .leading, spacing: 12) {
                        DetailRow(label: "Original", value: entity.text ?? "n/a", monospaced: true)
                        DetailRow(label: "Replacement", value: entity.replacement, monospaced: true)
                        DetailRow(label: "Type", value: entity.type)
                        DetailRow(label: "Source", value: entity.source)
                        DetailRow(label: "Action", value: entity.action ?? "replace")
                        if let profileRuleID = entity.profileRuleID, !profileRuleID.isEmpty {
                            DetailRow(label: "Profile Rule", value: profileRuleID, monospaced: true)
                        }
                        DetailRow(label: "Confidence", value: confidenceText(for: entity))
                        DetailRow(label: "Span", value: spanText(for: entity), monospaced: true)
                        DetailRow(label: "Highlight", value: highlightDiagnostic ?? "Mapped safely")

                        if let reason = entity.reason, !reason.isEmpty {
                            DetailRow(label: "Reason", value: reason)
                        }

                        Divider()

                        profileActions(for: entity)
                    }
                    .padding(14)
                }
            } else {
                VStack(spacing: 8) {
                    Image(systemName: "sidebar.right")
                        .font(.system(size: 22, weight: .regular))
                        .foregroundStyle(.secondary)
                    Text("Select an entity")
                        .font(.callout)
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .padding(14)
            }
        }
        .background(Color(nsColor: .windowBackgroundColor).opacity(0.55))
    }

    private func profileActions(for entity: RedactionEntity) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Profile Actions")
                .font(.caption)
                .fontWeight(.semibold)
                .foregroundStyle(.secondary)

            Button {
                onProfileRuleAction(.mask)
            } label: {
                Label("Always Mask This", systemImage: "shield.lefthalf.filled")
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .buttonStyle(.bordered)

            Button {
                onProfileRuleAction(.ask)
            } label: {
                Label("Ask Me Next Time", systemImage: "questionmark.circle")
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .buttonStyle(.bordered)

            Button {
                onProfileRuleAction(.allow)
            } label: {
                Label("Always Allow This", systemImage: "checkmark.seal")
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .buttonStyle(.bordered)

            Button {
                onProfileRuleAction(.pattern)
            } label: {
                Label("Add Pattern", systemImage: "plus.rectangle.on.rectangle")
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .buttonStyle(.bordered)

            if isSavingProfileRule {
                ProgressView()
                    .controlSize(.small)
            }

            if let profileRuleStatus, !profileRuleStatus.isEmpty {
                Text(profileRuleStatus)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .disabled(
            isSavingProfileRule
                || (entity.text?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ?? true)
        )
    }

    private func confidenceText(for entity: RedactionEntity) -> String {
        guard let confidence = entity.confidence else { return "n/a" }
        return "\(Int((confidence * 100).rounded()))%"
    }

    private func spanText(for entity: RedactionEntity) -> String {
        guard let start = entity.start, let end = entity.end else {
            return "n/a"
        }
        return "\(start)-\(end)"
    }
}

private struct DetailRow: View {
    let label: String
    let value: String
    var monospaced = false

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(label)
                .font(.caption)
                .fontWeight(.semibold)
                .foregroundStyle(.secondary)

            Text(value.isEmpty ? "n/a" : value)
                .font(monospaced ? .caption.monospaced() : .caption)
                .foregroundStyle(.primary)
                .textSelection(.enabled)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

private struct LearningCandidateRow: View {
    let candidate: ProfileLearningCandidate
    let isSelected: Bool
    let onSelectionChange: (Bool) -> Void

    var body: some View {
        Toggle(isOn: selectionBinding) {
            VStack(alignment: .leading, spacing: 5) {
                HStack(spacing: 8) {
                    Text(candidate.suggestedEntityType)
                        .font(.caption)
                        .fontWeight(.semibold)

                    Text(candidate.sourceDetector)
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    Spacer()

                    Text(candidate.suggestedAction.title)
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    Text(confidenceText)
                        .font(.caption.monospacedDigit())
                        .foregroundStyle(.secondary)
                }

                Text(candidate.pattern)
                    .font(.caption.monospaced())
                    .lineLimit(2)
                    .truncationMode(.middle)
                    .textSelection(.enabled)

                HStack(spacing: 8) {
                    Text(candidate.replacement)
                        .font(.caption.monospaced())
                        .foregroundStyle(.secondary)

                    if !candidate.reason.isEmpty {
                        Text(candidate.reason)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(2)
                    }
                }
            }
            .padding(.vertical, 8)
        }
        .toggleStyle(.checkbox)
        .padding(.horizontal, 16)
        .accessibilityLabel("\(candidate.suggestedEntityType) candidate")
    }

    private var selectionBinding: Binding<Bool> {
        Binding(
            get: { isSelected },
            set: onSelectionChange
        )
    }

    private var confidenceText: String {
        "\(Int((candidate.confidence * 100).rounded()))%"
    }
}

private enum ProfileSettingsTab: String, CaseIterable, Identifiable {
    case rules
    case learn

    var id: String { rawValue }

    var title: String {
        switch self {
        case .rules:
            return "Rules"
        case .learn:
            return "Learn"
        }
    }
}

private struct ModelSettingsView: View {
    let apiClient: PrivacyPreflightAPIClient

    @Environment(\.dismiss) private var dismiss
    @State private var providers: [ModelProvider] = []
    @State private var settings = ModelReviewSettings(
        enableLLMReview: false,
        selectedReviewProviderID: nil,
        allowRawTextForExternalModels: false
    )
    @State private var selectedProviderID: ModelProvider.ID?
    @State private var draft = ModelProviderDraft()
    @State private var isNewProvider = true
    @State private var isLoading = false
    @State private var isSavingProvider = false
    @State private var isSavingSettings = false
    @State private var isTesting = false
    @State private var statusMessage: String?
    @State private var errorMessage: String?

    private var selectedProvider: ModelProvider? {
        guard let selectedProviderID else { return nil }
        return providers.first { $0.id == selectedProviderID }
    }

    private var selectedReviewProvider: ModelProvider? {
        guard let providerID = settings.selectedReviewProviderID else { return nil }
        return providers.first { $0.id == providerID }
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Model Settings")
                        .font(.title3)
                        .fontWeight(.semibold)
                    Text("Local-first review models")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }

                Spacer()

                Button {
                    dismiss()
                } label: {
                    Label("Close", systemImage: "xmark")
                }
                .labelStyle(.iconOnly)
                .buttonStyle(.borderless)
                .help("Close")
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 14)

            Divider()

            if let errorMessage {
                StatusBanner(message: errorMessage, style: .error)
            }

            if let statusMessage {
                HStack {
                    Text(statusMessage)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .textSelection(.enabled)
                    Spacer()
                }
                .padding(.horizontal, 18)
                .padding(.vertical, 8)
                .overlay(Divider(), alignment: .bottom)
            }

            HStack(spacing: 0) {
                providerList
                    .frame(width: 300)

                Divider()

                VStack(spacing: 0) {
                    reviewSettings

                    Divider()

                    providerForm
                }
                .frame(minWidth: 540)
            }
        }
        .task {
            await load()
        }
    }

    private var providerList: some View {
        VStack(spacing: 0) {
            HStack {
                Text("Providers")
                    .font(.headline)
                Text("\(providers.count)")
                    .font(.caption)
                    .foregroundStyle(.secondary)

                Spacer()

                Button {
                    startNewProvider()
                } label: {
                    Label("Add Provider", systemImage: "plus")
                }
                .labelStyle(.iconOnly)
                .help("Add provider")
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 10)

            Divider()

            if isLoading {
                ProgressView()
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else if providers.isEmpty {
                VStack(spacing: 8) {
                    Image(systemName: "cpu")
                        .font(.system(size: 22, weight: .regular))
                        .foregroundStyle(.secondary)
                    Text("No providers")
                        .font(.callout)
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 0) {
                        ForEach(providers) { provider in
                            Button {
                                select(provider)
                            } label: {
                                HStack(alignment: .top, spacing: 10) {
                                    Image(systemName: provider.isLocal ? "desktopcomputer" : "network")
                                        .foregroundStyle(provider.isLocal ? Color.accentColor : Color.orange)
                                        .padding(.top, 1)

                                    VStack(alignment: .leading, spacing: 3) {
                                        Text(provider.name)
                                            .font(.callout)
                                            .fontWeight(.medium)
                                            .lineLimit(1)

                                        Text("\(provider.providerType.title) · \(provider.model)")
                                            .font(.caption)
                                            .foregroundStyle(.secondary)
                                            .lineLimit(1)
                                            .truncationMode(.middle)
                                    }

                                    Spacer(minLength: 0)
                                }
                                .padding(.horizontal, 14)
                                .padding(.vertical, 9)
                                .background(provider.id == selectedProviderID ? Color.accentColor.opacity(0.14) : Color.clear)
                            }
                            .buttonStyle(.plain)

                            Divider()
                        }
                    }
                }
            }
        }
    }

    private var reviewSettings: some View {
        Form {
            Toggle("Enable LLM Review", isOn: $settings.enableLLMReview)

            Picker("Review Model", selection: $settings.selectedReviewProviderID) {
                Text("None").tag(String?.none)
                ForEach(providers) { provider in
                    Text(provider.name).tag(Optional(provider.id))
                }
            }

            Toggle("Allow Raw Text to External Models", isOn: $settings.allowRawTextForExternalModels)
                .disabled(selectedReviewProvider?.isLocal ?? true)

            if let provider = selectedReviewProvider, !provider.isLocal {
                Label(externalWarningText, systemImage: "exclamationmark.triangle.fill")
                    .font(.caption)
                    .foregroundStyle(.orange)
                    .fixedSize(horizontal: false, vertical: true)
            }

            HStack {
                Spacer()

                Button {
                    Task { await saveSettings() }
                } label: {
                    if isSavingSettings {
                        ProgressView()
                            .controlSize(.small)
                            .frame(width: 18, height: 18)
                    } else {
                        Label("Save Review Settings", systemImage: "checkmark")
                    }
                }
                .buttonStyle(.borderedProminent)
                .disabled(isSavingSettings)
            }
        }
        .formStyle(.grouped)
        .frame(minHeight: 160)
    }

    private var providerForm: some View {
        VStack(spacing: 0) {
            HStack {
                Text(isNewProvider ? "New Provider" : "Edit Provider")
                    .font(.headline)

                Spacer()

                if let selectedProvider, !isNewProvider {
                    Text(selectedProvider.id)
                        .font(.caption.monospaced())
                        .foregroundStyle(.secondary)
                        .textSelection(.enabled)
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)

            Divider()

            Form {
                TextField("Name", text: $draft.name)

                Picker("Provider Type", selection: $draft.providerType) {
                    ForEach(ModelProviderType.allCases) { providerType in
                        Text(providerType.title).tag(providerType)
                    }
                }
                .onChange(of: draft.providerType) { _, newValue in
                    draft.applyDefaults(for: newValue)
                }

                TextField("Base URL", text: $draft.baseURL)
                TextField("Model", text: $draft.model)

                SecureField("API Key", text: $draft.apiKey)
                if draft.apiKey.isEmpty, draft.apiKeyConfigured {
                    Text("API key configured")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Toggle("Local Provider", isOn: $draft.isLocal)
                Toggle("JSON Mode", isOn: $draft.supportsJSONMode)

                HStack {
                    TextField("Timeout", text: $draft.timeoutText)
                    TextField("Max Tokens", text: $draft.maxTokensText)
                }
            }
            .formStyle(.grouped)

            Divider()

            HStack {
                Button(role: .destructive) {
                    Task { await deleteSelectedProvider() }
                } label: {
                    Label("Delete", systemImage: "trash")
                }
                .disabled(isNewProvider || selectedProviderID == nil || isSavingProvider)

                Button {
                    Task { await testSelectedProvider() }
                } label: {
                    if isTesting {
                        ProgressView()
                            .controlSize(.small)
                            .frame(width: 18, height: 18)
                    } else {
                        Label("Test", systemImage: "bolt.horizontal")
                    }
                }
                .disabled(isNewProvider || selectedProviderID == nil || isTesting)

                Spacer()

                Button {
                    startNewProvider()
                } label: {
                    Label("New", systemImage: "plus")
                }
                .disabled(isSavingProvider)

                Button {
                    Task { await saveProvider() }
                } label: {
                    if isSavingProvider {
                        ProgressView()
                            .controlSize(.small)
                            .frame(width: 18, height: 18)
                    } else {
                        Label("Save", systemImage: "checkmark")
                    }
                }
                .buttonStyle(.borderedProminent)
                .frame(width: 92)
                .disabled(!draft.isValid || isSavingProvider)
            }
            .padding(16)
        }
    }

    private var externalWarningText: String {
        if settings.allowRawTextForExternalModels {
            return "External review can receive original text."
        }
        return "External review uses redacted-only content."
    }

    @MainActor
    private func load(selecting providerID: ModelProvider.ID? = nil) async {
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }

        do {
            async let loadedProviders = apiClient.fetchModelProviders()
            async let loadedSettings = apiClient.fetchModelSettings()
            let fetchedProviders = try await loadedProviders
            let sortedProviders = fetchedProviders.sorted {
                $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending
            }
            providers = sortedProviders
            settings = try await loadedSettings

            if let providerID, let provider = providers.first(where: { $0.id == providerID }) {
                select(provider)
            } else if let selectedProviderID, let provider = providers.first(where: { $0.id == selectedProviderID }) {
                select(provider)
            } else if let firstProvider = providers.first {
                select(firstProvider)
            } else {
                startNewProvider()
            }
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func startNewProvider() {
        selectedProviderID = nil
        draft = ModelProviderDraft()
        isNewProvider = true
        statusMessage = nil
        errorMessage = nil
    }

    private func select(_ provider: ModelProvider) {
        selectedProviderID = provider.id
        draft = ModelProviderDraft(provider: provider)
        isNewProvider = false
        statusMessage = nil
        errorMessage = nil
    }

    @MainActor
    private func saveProvider() async {
        guard draft.isValid else { return }
        isSavingProvider = true
        statusMessage = nil
        errorMessage = nil
        defer { isSavingProvider = false }

        do {
            let saved: ModelProvider
            if isNewProvider {
                saved = try await apiClient.createModelProvider(draft.input)
                if settings.selectedReviewProviderID == nil {
                    settings.selectedReviewProviderID = saved.id
                }
            } else if let selectedProviderID {
                saved = try await apiClient.updateModelProvider(id: selectedProviderID, provider: draft.input)
            } else {
                return
            }
            statusMessage = "Provider saved."
            await load(selecting: saved.id)
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    @MainActor
    private func saveSettings() async {
        if settings.enableLLMReview, settings.selectedReviewProviderID == nil {
            errorMessage = "Choose a review model before enabling LLM review."
            return
        }

        isSavingSettings = true
        statusMessage = nil
        errorMessage = nil
        defer { isSavingSettings = false }

        do {
            settings = try await apiClient.updateModelSettings(settings)
            statusMessage = "Review settings saved."
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    @MainActor
    private func testSelectedProvider() async {
        guard let selectedProviderID else { return }
        isTesting = true
        statusMessage = nil
        errorMessage = nil
        defer { isTesting = false }

        do {
            let result = try await apiClient.testModelProvider(id: selectedProviderID)
            statusMessage = result.ok ? "Provider test passed." : "Provider test failed: \(result.message)"
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    @MainActor
    private func deleteSelectedProvider() async {
        guard let selectedProviderID else { return }
        isSavingProvider = true
        statusMessage = nil
        errorMessage = nil
        defer { isSavingProvider = false }

        do {
            try await apiClient.deleteModelProvider(id: selectedProviderID)
            statusMessage = "Provider deleted."
            await load()
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

private struct GatewaySettingsView: View {
    let apiClient: PrivacyPreflightAPIClient

    @Environment(\.dismiss) private var dismiss
    @State private var providers: [ModelProvider] = []
    @State private var settings = GatewaySettings.disabled
    @State private var portText = "8765"
    @State private var previewText = "Email ada@example.com."
    @State private var previewResult: GatewayPreviewResponse?
    @State private var isLoading = false
    @State private var isSaving = false
    @State private var isPreviewing = false
    @State private var statusMessage: String?
    @State private var errorMessage: String?

    private var selectedProvider: ModelProvider? {
        guard let providerID = settings.upstreamProviderID else { return nil }
        return gatewayProviders.first { $0.id == providerID }
    }

    private var gatewayProviders: [ModelProvider] {
        providers.filter { $0.providerType != .ollama }
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Gateway Settings")
                        .font(.title3)
                        .fontWeight(.semibold)
                    Text("Local OpenAI-compatible preflight")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }

                Spacer()

                Button {
                    dismiss()
                } label: {
                    Label("Close", systemImage: "xmark")
                }
                .labelStyle(.iconOnly)
                .buttonStyle(.borderless)
                .help("Close")
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 14)

            Divider()

            if let errorMessage {
                StatusBanner(message: errorMessage, style: .error)
            }

            if let statusMessage {
                HStack {
                    Text(statusMessage)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .textSelection(.enabled)
                    Spacer()
                }
                .padding(.horizontal, 18)
                .padding(.vertical, 8)
                .overlay(Divider(), alignment: .bottom)
            }

            if isLoading {
                ProgressView()
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                HStack(spacing: 0) {
                    gatewayForm
                        .frame(width: 390)

                    Divider()

                    previewPanel
                        .frame(minWidth: 470)
                }
            }
        }
        .task {
            await load()
        }
    }

    private var gatewayForm: some View {
        VStack(spacing: 0) {
            Form {
                Toggle("Enable Gateway", isOn: $settings.enabled)

                Picker("Upstream Provider", selection: $settings.upstreamProviderID) {
                    Text("None").tag(String?.none)
                    ForEach(gatewayProviders) { provider in
                        Text(provider.name).tag(Optional(provider.id))
                    }
                }

                TextField("Bind Host", text: $settings.bindHost)
                TextField("Port", text: $portText)

                VStack(alignment: .leading, spacing: 5) {
                    Text("Endpoint")
                        .font(.caption)
                        .fontWeight(.semibold)
                        .foregroundStyle(.secondary)
                    Text(endpointURLText)
                        .font(.caption.monospaced())
                        .textSelection(.enabled)
                        .lineLimit(2)
                        .truncationMode(.middle)
                }

                Toggle("Redact Request Messages", isOn: $settings.redactRequestMessages)
                Toggle("Allow Raw Text Upstream", isOn: $settings.allowRawTextToUpstream)

                Label(rawSharingText, systemImage: rawSharingIcon)
                    .font(.caption)
                    .foregroundStyle(rawSharingColor)
                    .fixedSize(horizontal: false, vertical: true)

                if !isLoopbackHost {
                    Label("Non-loopback bind host", systemImage: "network.badge.shield.half.filled")
                        .font(.caption)
                        .foregroundStyle(.orange)
                }

                if let provider = selectedProvider, !provider.isLocal {
                    Label(externalProviderText, systemImage: "exclamationmark.triangle.fill")
                        .font(.caption)
                        .foregroundStyle(.orange)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
            .formStyle(.grouped)

            Divider()

            HStack {
                Spacer()

                Button {
                    Task { await save() }
                } label: {
                    if isSaving {
                        ProgressView()
                            .controlSize(.small)
                            .frame(width: 18, height: 18)
                    } else {
                        Label("Save", systemImage: "checkmark")
                    }
                }
                .buttonStyle(.borderedProminent)
                .frame(width: 92)
                .disabled(isSaving)
            }
            .padding(16)
        }
    }

    private var previewPanel: some View {
        VStack(spacing: 0) {
            HStack {
                Text("Preview")
                    .font(.headline)

                Spacer()

                Button {
                    Task { await preview() }
                } label: {
                    if isPreviewing {
                        ProgressView()
                            .controlSize(.small)
                            .frame(width: 18, height: 18)
                    } else {
                        Label("Dry Run", systemImage: "eye")
                    }
                }
                .buttonStyle(.borderedProminent)
                .disabled(previewText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || isPreviewing)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)

            Divider()

            VStack(alignment: .leading, spacing: 8) {
                Text("Sample Message")
                    .font(.caption)
                    .fontWeight(.semibold)
                    .foregroundStyle(.secondary)

                TextEditor(text: $previewText)
                    .font(.body.monospaced())
                    .frame(minHeight: 105, idealHeight: 130)
                    .scrollContentBackground(.hidden)
                    .background(Color(nsColor: .textBackgroundColor))
                    .clipShape(RoundedRectangle(cornerRadius: 6, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 6, style: .continuous)
                            .stroke(Color(nsColor: .separatorColor))
                    )
            }
            .padding(16)

            Divider()

            if let previewResult {
                previewResultView(previewResult)
            } else {
                VStack(spacing: 8) {
                    Image(systemName: "eye")
                        .font(.system(size: 22, weight: .regular))
                        .foregroundStyle(.secondary)
                    Text("No preview yet")
                        .font(.callout)
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
    }

    private func previewResultView(_ result: GatewayPreviewResponse) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 8) {
                Label(result.rawTextSent ? "Raw upstream" : "Redacted upstream", systemImage: result.rawTextSent ? "exclamationmark.triangle.fill" : "checkmark.seal")
                    .font(.caption)
                    .foregroundStyle(result.rawTextSent ? Color.orange : Color.green)

                if result.rawTextBlocked {
                    Label("Raw blocked", systemImage: "shield.fill")
                        .font(.caption)
                        .foregroundStyle(.orange)
                }

                Spacer()
            }

            if let warning = result.warning {
                Text(warning)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }

            if !result.messages.isEmpty {
                HStack(spacing: 6) {
                    ForEach(result.messages) { message in
                        ForEach(message.summary.sorted(by: { $0.key < $1.key }), id: \.key) { item in
                            SummaryChip(type: item.key, count: item.value)
                        }
                    }
                }
            }

            Text("Forwarded Request")
                .font(.caption)
                .fontWeight(.semibold)
                .foregroundStyle(.secondary)

            ScrollView {
                Text(result.forwardedRequest.prettyPrintedString)
                    .font(.caption.monospaced())
                    .textSelection(.enabled)
                    .frame(maxWidth: .infinity, alignment: .topLeading)
                    .padding(10)
            }
            .background(Color(nsColor: .textBackgroundColor))
            .clipShape(RoundedRectangle(cornerRadius: 6, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 6, style: .continuous)
                    .stroke(Color(nsColor: .separatorColor))
            )
        }
        .padding(16)
    }

    private var endpointURLText: String {
        var current = settings
        current.port = parsedPort ?? settings.port
        current.bindHost = current.bindHost.trimmingCharacters(in: .whitespacesAndNewlines)
        return current.endpointURL
    }

    private var rawSharingText: String {
        if !settings.redactRequestMessages && settings.allowRawTextToUpstream {
            return "Raw text can be forwarded upstream."
        }
        if !settings.redactRequestMessages {
            return "Raw forwarding is blocked until explicitly allowed."
        }
        return "Request messages are redacted before upstream forwarding."
    }

    private var rawSharingIcon: String {
        return (!settings.redactRequestMessages && settings.allowRawTextToUpstream)
            ? "exclamationmark.triangle.fill"
            : "shield.lefthalf.filled"
    }

    private var rawSharingColor: Color {
        return (!settings.redactRequestMessages && settings.allowRawTextToUpstream)
            ? .orange
            : .secondary
    }

    private var externalProviderText: String {
        if settings.redactRequestMessages {
            return "Non-local upstream receives redacted-only messages."
        }
        return settings.allowRawTextToUpstream
            ? "Non-local upstream can receive original messages."
            : "Non-local raw forwarding is blocked."
    }

    private var isLoopbackHost: Bool {
        let host = settings.bindHost.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        return host == "127.0.0.1" || host == "localhost" || host == "::1" || host == "[::1]"
    }

    private var parsedPort: Int? {
        guard let value = Int(portText.trimmingCharacters(in: .whitespacesAndNewlines)),
              (1...65535).contains(value)
        else {
            return nil
        }
        return value
    }

    @MainActor
    private func load() async {
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }

        do {
            async let loadedProviders = apiClient.fetchModelProviders()
            async let loadedSettings = apiClient.fetchGatewaySettings()
            let fetchedProviders = try await loadedProviders
            providers = fetchedProviders.sorted {
                $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending
            }
            settings = try await loadedSettings
            portText = "\(settings.port)"
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    @MainActor
    private func save() async {
        guard let port = parsedPort else {
            errorMessage = "Choose a port between 1 and 65535."
            return
        }
        if settings.enabled, settings.upstreamProviderID == nil {
            errorMessage = "Choose an upstream provider before enabling the gateway."
            return
        }
        if !settings.redactRequestMessages, !settings.allowRawTextToUpstream {
            errorMessage = "Enable redaction or explicitly allow raw upstream sharing."
            return
        }

        var nextSettings = settings
        nextSettings.bindHost = nextSettings.bindHost.trimmingCharacters(in: .whitespacesAndNewlines)
        nextSettings.port = port

        isSaving = true
        statusMessage = nil
        errorMessage = nil
        defer { isSaving = false }

        do {
            settings = try await apiClient.updateGatewaySettings(nextSettings)
            portText = "\(settings.port)"
            statusMessage = "Gateway settings saved."
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    @MainActor
    private func preview() async {
        let trimmed = previewText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }

        isPreviewing = true
        statusMessage = nil
        errorMessage = nil
        defer { isPreviewing = false }

        let request = GatewayPreviewRequest(
            model: selectedProvider?.model ?? "privacy-preflight-preview",
            messages: [GatewayPreviewMessage(role: "user", content: previewText)]
        )

        do {
            previewResult = try await apiClient.previewGateway(request)
        } catch {
            previewResult = nil
            errorMessage = error.localizedDescription
        }
    }
}

private struct ProfileSettingsView: View {
    let apiClient: PrivacyPreflightAPIClient
    let initialRuleSeed: ProfileRuleSeed?

    @Environment(\.dismiss) private var dismiss
    @State private var selectedTab: ProfileSettingsTab = .rules
    @State private var rules: [ProfileRule] = []
    @State private var selectedRuleID: ProfileRule.ID?
    @State private var draft = ProfileRuleDraft()
    @State private var isNewRule = true
    @State private var isLoading = false
    @State private var isSaving = false
    @State private var hasAppliedInitialRuleSeed = false
    @State private var sampleText = ""
    @State private var learningMode: TextRedactionMode = .balanced
    @State private var learningCandidates: [ProfileLearningCandidate] = []
    @State private var selectedCandidateIDs = Set<ProfileLearningCandidate.ID>()
    @State private var isLearning = false
    @State private var isSavingCandidates = false
    @State private var learningStatus: String?
    @State private var errorMessage: String?

    private var selectedRule: ProfileRule? {
        guard let selectedRuleID else { return nil }
        return rules.first { $0.id == selectedRuleID }
    }

    private var selectedCandidates: [ProfileLearningCandidate] {
        learningCandidates.filter { selectedCandidateIDs.contains($0.id) }
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Profile Settings")
                        .font(.title3)
                        .fontWeight(.semibold)
                    Text("Local redaction rules")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }

                Spacer()

                Button {
                    dismiss()
                } label: {
                    Label("Close", systemImage: "xmark")
                }
                .labelStyle(.iconOnly)
                .buttonStyle(.borderless)
                .help("Close")
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 14)

            Divider()

            if let errorMessage {
                StatusBanner(message: errorMessage, style: .error)
            }

            Picker("Profile Section", selection: $selectedTab) {
                ForEach(ProfileSettingsTab.allCases) { tab in
                    Text(tab.title).tag(tab)
                }
            }
            .pickerStyle(.segmented)
            .frame(width: 260)
            .padding(.horizontal, 18)
            .padding(.vertical, 10)

            Divider()

            if selectedTab == .rules {
                HStack(spacing: 0) {
                    ruleList
                        .frame(width: 280)

                    Divider()

                    ruleForm
                        .frame(minWidth: 460)
                }
            } else {
                learningView
            }
        }
        .task {
            await loadProfile()
            applyInitialRuleSeedIfNeeded()
        }
    }

    private var ruleList: some View {
        VStack(spacing: 0) {
            HStack {
                Text("Rules")
                    .font(.headline)
                Text("\(rules.count)")
                    .font(.caption)
                    .foregroundStyle(.secondary)

                Spacer()

                Button {
                    startNewRule()
                } label: {
                    Label("Add Rule", systemImage: "plus")
                }
                .labelStyle(.iconOnly)
                .help("Add rule")
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 10)

            Divider()

            if isLoading {
                ProgressView()
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else if rules.isEmpty {
                VStack(spacing: 8) {
                    Image(systemName: "list.bullet.rectangle")
                        .font(.system(size: 22, weight: .regular))
                        .foregroundStyle(.secondary)
                    Text("No profile rules")
                        .font(.callout)
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 0) {
                        ForEach(rules) { rule in
                            Button {
                                select(rule)
                            } label: {
                                HStack(alignment: .top, spacing: 10) {
                                    Image(systemName: rule.enabled ? "checkmark.circle.fill" : "circle")
                                        .foregroundStyle(rule.enabled ? Color.accentColor : Color.secondary)
                                        .padding(.top, 1)

                                    VStack(alignment: .leading, spacing: 3) {
                                        Text(rule.label)
                                            .font(.callout)
                                            .fontWeight(.medium)
                                            .lineLimit(1)
                                            .truncationMode(.tail)

                                        Text("\(rule.entityType) · \(rule.action.title)")
                                            .font(.caption)
                                            .foregroundStyle(.secondary)
                                            .lineLimit(1)
                                            .truncationMode(.tail)
                                    }

                                    Spacer(minLength: 0)
                                }
                                .padding(.horizontal, 14)
                                .padding(.vertical, 9)
                                .background(rule.id == selectedRuleID ? Color.accentColor.opacity(0.14) : Color.clear)
                            }
                            .buttonStyle(.plain)

                            Divider()
                        }
                    }
                }
            }
        }
    }

    private var ruleForm: some View {
        VStack(spacing: 0) {
            HStack {
                Text(isNewRule ? "New Rule" : "Edit Rule")
                    .font(.headline)

                Spacer()

                if let selectedRule, !isNewRule {
                    Text(selectedRule.id)
                        .font(.caption.monospaced())
                        .foregroundStyle(.secondary)
                        .textSelection(.enabled)
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)

            Divider()

            Form {
                TextField("Label", text: $draft.label)
                TextField("Entity Type", text: $draft.entityType)

                Picker("Action", selection: $draft.action) {
                    ForEach(ProfileRuleAction.allCases) { action in
                        Text(action.title).tag(action)
                    }
                }
                .pickerStyle(.segmented)

                Toggle("Enabled", isOn: $draft.enabled)

                Picker("Scope", selection: $draft.scope) {
                    ForEach(ProfileRuleScope.allCases) { scope in
                        Text(scope.title).tag(scope)
                    }
                }

                TextField("Replacement Label", text: $draft.replacement)
                    .disabled(draft.action == .allow)

                VStack(alignment: .leading, spacing: 6) {
                    Text("Patterns")
                        .font(.caption)
                        .fontWeight(.semibold)
                        .foregroundStyle(.secondary)
                    TextEditor(text: $draft.patternsText)
                        .font(.body.monospaced())
                        .frame(minHeight: 86)
                        .scrollContentBackground(.hidden)
                        .background(Color(nsColor: .textBackgroundColor))
                        .clipShape(RoundedRectangle(cornerRadius: 6, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 6, style: .continuous)
                                .stroke(Color(nsColor: .separatorColor))
                        )
                }

                VStack(alignment: .leading, spacing: 6) {
                    Text("Aliases")
                        .font(.caption)
                        .fontWeight(.semibold)
                        .foregroundStyle(.secondary)
                    TextEditor(text: $draft.aliasesText)
                        .font(.body.monospaced())
                        .frame(minHeight: 70)
                        .scrollContentBackground(.hidden)
                        .background(Color(nsColor: .textBackgroundColor))
                        .clipShape(RoundedRectangle(cornerRadius: 6, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 6, style: .continuous)
                                .stroke(Color(nsColor: .separatorColor))
                        )
                }
            }
            .formStyle(.grouped)
            .padding(.top, 4)

            Divider()

            HStack {
                Button(role: .destructive) {
                    Task { await deleteSelectedRule() }
                } label: {
                    Label("Delete", systemImage: "trash")
                }
                .disabled(isNewRule || selectedRuleID == nil || isSaving)

                Spacer()

                Button {
                    startNewRule()
                } label: {
                    Label("New", systemImage: "plus")
                }
                .disabled(isSaving)

                Button {
                    Task { await saveRule() }
                } label: {
                    if isSaving {
                        ProgressView()
                            .controlSize(.small)
                            .frame(width: 18, height: 18)
                    } else {
                        Label("Save", systemImage: "checkmark")
                    }
                }
                .buttonStyle(.borderedProminent)
                .frame(width: 92)
                .disabled(!draft.isValid || isSaving)
            }
            .padding(16)
        }
    }

    private var learningView: some View {
        VStack(spacing: 0) {
            HStack {
                Text("Learn From Sample")
                    .font(.headline)

                Spacer()

                Picker("Mode", selection: $learningMode) {
                    ForEach(TextRedactionMode.allCases) { mode in
                        Text(mode.title).tag(mode)
                    }
                }
                .pickerStyle(.segmented)
                .frame(width: 180)
                .disabled(isLearning || isSavingCandidates)

                Button {
                    Task { await learnFromSample() }
                } label: {
                    if isLearning {
                        ProgressView()
                            .controlSize(.small)
                            .frame(width: 18, height: 18)
                    } else {
                        Label("Find Candidates", systemImage: "sparkle.magnifyingglass")
                    }
                }
                .buttonStyle(.borderedProminent)
                .disabled(sampleText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || isLearning)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)

            Divider()

            VStack(alignment: .leading, spacing: 8) {
                Text("Sample Text")
                    .font(.caption)
                    .fontWeight(.semibold)
                    .foregroundStyle(.secondary)

                TextEditor(text: $sampleText)
                    .font(.body.monospaced())
                    .frame(minHeight: 120, idealHeight: 150)
                    .scrollContentBackground(.hidden)
                    .background(Color(nsColor: .textBackgroundColor))
                    .overlay {
                        if sampleText.isEmpty {
                            Text("Paste sample text")
                                .foregroundStyle(.tertiary)
                                .padding(.top, 8)
                                .padding(.leading, 5)
                                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                                .allowsHitTesting(false)
                        }
                    }
                    .clipShape(RoundedRectangle(cornerRadius: 6, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 6, style: .continuous)
                            .stroke(Color(nsColor: .separatorColor))
                    )
            }
            .padding(16)

            Divider()

            HStack {
                Text("Candidates")
                    .font(.headline)
                Text("\(learningCandidates.count)")
                    .font(.caption)
                    .foregroundStyle(.secondary)

                Spacer()

                Button {
                    selectedCandidateIDs = Set(learningCandidates.map { $0.id })
                } label: {
                    Label("Select All", systemImage: "checklist.checked")
                }
                .disabled(learningCandidates.isEmpty || isSavingCandidates)

                Button {
                    selectedCandidateIDs.removeAll()
                } label: {
                    Label("Clear", systemImage: "xmark.circle")
                }
                .disabled(selectedCandidateIDs.isEmpty || isSavingCandidates)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)

            Divider()

            if learningCandidates.isEmpty {
                VStack(spacing: 8) {
                    Image(systemName: "sparkle.magnifyingglass")
                        .font(.system(size: 22, weight: .regular))
                        .foregroundStyle(.secondary)
                    Text(isLearning ? "Finding candidates" : "No candidates")
                        .font(.callout)
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 0) {
                        ForEach(learningCandidates) { candidate in
                            LearningCandidateRow(
                                candidate: candidate,
                                isSelected: selectedCandidateIDs.contains(candidate.id)
                            ) { isSelected in
                                if isSelected {
                                    selectedCandidateIDs.insert(candidate.id)
                                } else {
                                    selectedCandidateIDs.remove(candidate.id)
                                }
                            }
                            Divider()
                        }
                    }
                }
            }

            Divider()

            HStack {
                if let learningStatus {
                    Text(learningStatus)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }

                Spacer()

                Button {
                    Task { await saveSelectedCandidates() }
                } label: {
                    if isSavingCandidates {
                        ProgressView()
                            .controlSize(.small)
                            .frame(width: 18, height: 18)
                    } else {
                        Label("Save Selected", systemImage: "checkmark")
                    }
                }
                .buttonStyle(.borderedProminent)
                .disabled(selectedCandidates.isEmpty || isSavingCandidates)
            }
            .padding(16)
        }
    }

    @MainActor
    private func loadProfile(selecting ruleID: ProfileRule.ID? = nil) async {
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }

        do {
            let profile = try await apiClient.fetchProfile()
            rules = profile.rules.sorted { $0.label.localizedCaseInsensitiveCompare($1.label) == .orderedAscending }

            if let ruleID, let rule = rules.first(where: { $0.id == ruleID }) {
                select(rule)
            } else if let selectedRuleID, let rule = rules.first(where: { $0.id == selectedRuleID }) {
                select(rule)
            } else if let firstRule = rules.first {
                select(firstRule)
            } else {
                startNewRule()
            }
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func applyInitialRuleSeedIfNeeded() {
        guard let initialRuleSeed, !hasAppliedInitialRuleSeed else { return }
        hasAppliedInitialRuleSeed = true
        selectedTab = .rules
        startNewRule(seed: initialRuleSeed)
    }

    private func startNewRule(seed: ProfileRuleSeed? = nil) {
        selectedRuleID = nil
        draft = seed.map(ProfileRuleDraft.init(seed:)) ?? ProfileRuleDraft()
        isNewRule = true
        errorMessage = nil
    }

    private func select(_ rule: ProfileRule) {
        selectedRuleID = rule.id
        draft = ProfileRuleDraft(rule: rule)
        isNewRule = false
        errorMessage = nil
    }

    @MainActor
    private func saveRule() async {
        guard draft.isValid else { return }
        isSaving = true
        errorMessage = nil
        defer { isSaving = false }

        do {
            let savedRule: ProfileRule
            if isNewRule {
                savedRule = try await apiClient.createProfileRule(draft.input)
            } else if let selectedRuleID {
                savedRule = try await apiClient.updateProfileRule(id: selectedRuleID, rule: draft.input)
            } else {
                return
            }
            await loadProfile(selecting: savedRule.id)
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    @MainActor
    private func deleteSelectedRule() async {
        guard let selectedRuleID else { return }
        isSaving = true
        errorMessage = nil
        defer { isSaving = false }

        do {
            try await apiClient.deleteProfileRule(id: selectedRuleID)
            await loadProfile()
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    @MainActor
    private func learnFromSample() async {
        let trimmedSample = sampleText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedSample.isEmpty else { return }

        isLearning = true
        learningStatus = nil
        errorMessage = nil
        defer { isLearning = false }

        do {
            let response = try await apiClient.learnProfileCandidates(
                from: sampleText,
                mode: learningMode
            )
            learningCandidates = response.candidates
            selectedCandidateIDs = Set(response.candidates.map { $0.id })
            learningStatus = response.candidates.isEmpty
                ? "No profile candidates found."
                : "\(response.candidates.count) candidates found."
        } catch {
            learningCandidates = []
            selectedCandidateIDs.removeAll()
            errorMessage = error.localizedDescription
        }
    }

    @MainActor
    private func saveSelectedCandidates() async {
        let candidates = selectedCandidates
        guard !candidates.isEmpty else { return }

        isSavingCandidates = true
        learningStatus = nil
        errorMessage = nil
        defer { isSavingCandidates = false }

        do {
            var savedIDs: [ProfileRule.ID] = []
            for candidate in candidates {
                let rule = try await apiClient.createProfileRule(candidate.profileRuleInput)
                savedIDs.append(rule.id)
            }
            selectedCandidateIDs.removeAll()
            learningStatus = "Saved \(savedIDs.count) profile rules."
            await loadProfile(selecting: savedIDs.first)
            selectedTab = .rules
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

private extension ProfileLearningCandidate {
    var profileRuleInput: ProfileRuleInput {
        ProfileRuleInput(
            label: "Learned \(suggestedEntityType) from \(sourceDetector)",
            entityType: suggestedEntityType,
            patterns: [pattern],
            aliases: aliases,
            replacement: suggestedAction == .allow ? nil : replacement,
            action: suggestedAction,
            enabled: true,
            scope: .global
        )
    }
}

private struct ProfileRuleDraft {
    var label = ""
    var entityType = "CUSTOM"
    var patternsText = ""
    var aliasesText = ""
    var replacement = "[CUSTOM]"
    var action: ProfileRuleAction = .mask
    var enabled = true
    var scope: ProfileRuleScope = .global

    init() {}

    init(seed: ProfileRuleSeed) {
        label = seed.label
        entityType = seed.entityType
        patternsText = seed.pattern
        aliasesText = ""
        replacement = seed.replacement
        action = seed.action
        enabled = true
        scope = .global
    }

    init(rule: ProfileRule) {
        label = rule.label
        entityType = rule.entityType
        patternsText = rule.patterns.joined(separator: "\n")
        aliasesText = rule.aliases.joined(separator: "\n")
        replacement = rule.replacement
        action = rule.action
        enabled = rule.enabled
        scope = rule.scope
    }

    var input: ProfileRuleInput {
        ProfileRuleInput(
            label: label.trimmingCharacters(in: .whitespacesAndNewlines),
            entityType: entityType.trimmingCharacters(in: .whitespacesAndNewlines).uppercased(),
            patterns: terms(from: patternsText),
            aliases: terms(from: aliasesText),
            replacement: action == .allow ? nil : replacement.trimmingCharacters(in: .whitespacesAndNewlines),
            action: action,
            enabled: enabled,
            scope: scope
        )
    }

    var isValid: Bool {
        !label.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            && !entityType.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            && (!terms(from: patternsText).isEmpty || !terms(from: aliasesText).isEmpty)
            && (action == .allow || !replacement.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
    }

    private func terms(from text: String) -> [String] {
        var seen = Set<String>()
        return text
            .split(whereSeparator: \.isNewline)
            .map { String($0).trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
            .filter { term in
                let key = term.lowercased()
                guard !seen.contains(key) else { return false }
                seen.insert(key)
                return true
            }
    }
}

private struct ModelProviderDraft {
    var name = "Ollama"
    var providerType: ModelProviderType = .ollama
    var baseURL = ModelProviderType.ollama.defaultBaseURL
    var apiKey = ""
    var apiKeyConfigured = false
    var model = ModelProviderType.ollama.defaultModel
    var isLocal = true
    var supportsJSONMode = true
    var timeoutText = "30"
    var maxTokensText = "800"

    init() {}

    init(provider: ModelProvider) {
        name = provider.name
        providerType = provider.providerType
        baseURL = provider.baseURL
        apiKey = ""
        apiKeyConfigured = provider.apiKeyConfigured
        model = provider.model
        isLocal = provider.isLocal
        supportsJSONMode = provider.supportsJSONMode
        timeoutText = String(format: "%.0f", provider.timeout)
        maxTokensText = "\(provider.maxTokens)"
    }

    mutating func applyDefaults(for providerType: ModelProviderType) {
        name = providerType.title
        baseURL = providerType.defaultBaseURL
        model = providerType.defaultModel
        isLocal = providerType.defaultIsLocal
    }

    var input: ModelProviderInput {
        ModelProviderInput(
            name: name.trimmingCharacters(in: .whitespacesAndNewlines),
            providerType: providerType,
            baseURL: baseURL.trimmingCharacters(in: .whitespacesAndNewlines),
            apiKey: trimmedAPIKey,
            model: model.trimmingCharacters(in: .whitespacesAndNewlines),
            isLocal: isLocal,
            supportsJSONMode: supportsJSONMode,
            timeout: timeoutValue ?? 30,
            maxTokens: maxTokensValue ?? 800
        )
    }

    var isValid: Bool {
        !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            && !baseURL.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            && !model.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            && timeoutValue != nil
            && maxTokensValue != nil
    }

    private var trimmedAPIKey: String? {
        let trimmed = apiKey.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.isEmpty ? nil : trimmed
    }

    private var timeoutValue: Double? {
        guard let value = Double(timeoutText.trimmingCharacters(in: .whitespacesAndNewlines)),
              value > 0,
              value <= 300
        else {
            return nil
        }
        return value
    }

    private var maxTokensValue: Int? {
        guard let value = Int(maxTokensText.trimmingCharacters(in: .whitespacesAndNewlines)),
              value > 0,
              value <= 8192
        else {
            return nil
        }
        return value
    }
}

private extension Array {
    subscript(safe index: Index) -> Element? {
        indices.contains(index) ? self[index] : nil
    }
}

private struct StatusBanner: View {
    let message: String
    let style: Style

    enum Style {
        case warning
        case error

        var color: Color {
            switch self {
            case .warning:
                return .orange
            case .error:
                return .red
            }
        }

        var icon: String {
            switch self {
            case .warning:
                return "exclamationmark.triangle.fill"
            case .error:
                return "xmark.octagon.fill"
            }
        }
    }

    var body: some View {
        HStack(alignment: .top, spacing: 8) {
            Image(systemName: style.icon)
                .foregroundStyle(style.color)
                .padding(.top, 1)
            Text(message)
                .font(.callout)
                .foregroundStyle(.primary)
                .textSelection(.enabled)
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 10)
        .background(style.color.opacity(0.1))
        .overlay(Divider(), alignment: .bottom)
    }
}
