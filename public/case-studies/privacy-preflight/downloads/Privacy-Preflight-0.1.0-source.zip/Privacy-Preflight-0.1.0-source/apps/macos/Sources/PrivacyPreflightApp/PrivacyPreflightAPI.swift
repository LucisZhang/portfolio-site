import Foundation

enum TextRedactionMode: String, CaseIterable, Identifiable, Codable {
    case balanced
    case strict

    var id: String { rawValue }

    var title: String {
        switch self {
        case .balanced:
            return "Balanced"
        case .strict:
            return "Strict"
        }
    }
}

enum ImageRedactionMode: String, CaseIterable, Identifiable, Codable {
    case safeText = "safe_text"
    case precise

    var id: String { rawValue }

    var title: String {
        switch self {
        case .safeText:
            return "Safe"
        case .precise:
            return "Precise"
        }
    }
}

struct HealthResponse: Decodable {
    let status: String
}

struct TextRedactionResponse: Decodable {
    let redactedText: String
    let entities: [RedactionEntity]
    let summary: [String: Int]

    private enum CodingKeys: String, CodingKey {
        case redactedText = "redacted_text"
        case entities
        case summary
    }
}

struct ImageManualRectangle: Codable, Identifiable, Equatable {
    var id = UUID()
    var x: Double
    var y: Double
    var width: Double
    var height: Double

    private enum CodingKeys: String, CodingKey {
        case x
        case y
        case width
        case height
    }
}

struct ImageOCRBox: Decodable, Identifiable {
    let id: String
    let text: String
    let x: Double
    let y: Double
    let width: Double
    let height: Double
    let confidence: Double
    let source: String
}

struct ImageRedactedBox: Decodable, Identifiable {
    let id: String
    let source: String
    let reason: String
    let ocrBoxID: String?
    let text: String?
    let confidence: Double?
    let entityTypes: [String]
    let textSources: [String]
    let x: Double
    let y: Double
    let width: Double
    let height: Double

    private enum CodingKeys: String, CodingKey {
        case id
        case source
        case reason
        case ocrBoxID = "ocr_box_id"
        case text
        case confidence
        case entityTypes = "entity_types"
        case textSources = "text_sources"
        case x
        case y
        case width
        case height
    }
}

struct ImageRedactionResponse: Decodable {
    let mode: ImageRedactionMode
    let imageWidth: Int
    let imageHeight: Int
    let inputFormat: String
    let outputFormat: String
    let mediaType: String
    let ocrProvider: String
    let ocrBoxes: [ImageOCRBox]
    let redactedBoxes: [ImageRedactedBox]
    let summary: [String: Int]
    let redactedImageBase64: String

    private enum CodingKeys: String, CodingKey {
        case mode
        case imageWidth = "image_width"
        case imageHeight = "image_height"
        case inputFormat = "input_format"
        case outputFormat = "output_format"
        case mediaType = "media_type"
        case ocrProvider = "ocr_provider"
        case ocrBoxes = "ocr_boxes"
        case redactedBoxes = "redacted_boxes"
        case summary
        case redactedImageBase64 = "redacted_image_base64"
    }
}

struct PDFManualRectangle: Codable, Identifiable, Equatable {
    var id = UUID()
    var pageIndex: Int
    var x: Double
    var y: Double
    var width: Double
    var height: Double

    private enum CodingKeys: String, CodingKey {
        case pageIndex = "page_index"
        case x
        case y
        case width
        case height
    }
}

struct PDFPagePreview: Decodable, Identifiable {
    var id: Int { pageIndex }

    let pageIndex: Int
    let width: Double
    let height: Double
    let imageWidth: Int
    let imageHeight: Int
    let mediaType: String
    let previewImageBase64: String

    private enum CodingKeys: String, CodingKey {
        case pageIndex = "page_index"
        case width
        case height
        case imageWidth = "image_width"
        case imageHeight = "image_height"
        case mediaType = "media_type"
        case previewImageBase64 = "preview_image_base64"
    }
}

struct PDFRedactionRegion: Decodable, Identifiable {
    let id: String
    let pageIndex: Int
    let source: String
    let reason: String
    let text: String?
    let confidence: Double?
    let entityTypes: [String]
    let textSources: [String]
    let x: Double
    let y: Double
    let width: Double
    let height: Double

    private enum CodingKeys: String, CodingKey {
        case id
        case pageIndex = "page_index"
        case source
        case reason
        case text
        case confidence
        case entityTypes = "entity_types"
        case textSources = "text_sources"
        case x
        case y
        case width
        case height
    }
}

struct PDFValidationResult: Decodable {
    let status: String
    let safe: Bool
    let message: String
    let redactedTextAbsent: Bool
    let unappliedRedactionAnnotations: Bool
    let checkedTermsCount: Int
    let warnings: [String]

    private enum CodingKeys: String, CodingKey {
        case status
        case safe
        case message
        case redactedTextAbsent = "redacted_text_absent"
        case unappliedRedactionAnnotations = "unapplied_redaction_annotations"
        case checkedTermsCount = "checked_terms_count"
        case warnings
    }
}

struct PDFRedactionAnalysisResponse: Decodable {
    let documentType: String
    let pageCount: Int
    let pages: [PDFPagePreview]
    let redactionRegions: [PDFRedactionRegion]
    let summary: [String: Int]
    let warnings: [String]

    private enum CodingKeys: String, CodingKey {
        case documentType = "document_type"
        case pageCount = "page_count"
        case pages
        case redactionRegions = "redaction_regions"
        case summary
        case warnings
    }
}

struct PDFRedactionExportResponse: Decodable {
    let documentType: String
    let pageCount: Int
    let pages: [PDFPagePreview]
    let redactionRegions: [PDFRedactionRegion]
    let summary: [String: Int]
    let warnings: [String]
    let validation: PDFValidationResult
    let mediaType: String
    let redactedPDFBase64: String

    private enum CodingKeys: String, CodingKey {
        case documentType = "document_type"
        case pageCount = "page_count"
        case pages
        case redactionRegions = "redaction_regions"
        case summary
        case warnings
        case validation
        case mediaType = "media_type"
        case redactedPDFBase64 = "redacted_pdf_base64"
    }
}

struct TextReviewResponse: Decodable {
    let initialResult: TextRedactionResponse
    let reviewResult: ModelReviewResult?
    let finalResult: TextRedactionResponse

    private enum CodingKeys: String, CodingKey {
        case initialResult = "initial_result"
        case reviewResult = "review_result"
        case finalResult = "final_result"
    }
}

struct RedactionEntity: Decodable, Identifiable {
    let id: String
    let text: String?
    let type: String
    let source: String
    let replacement: String
    let confidence: Double?
    let action: String?
    let start: Int?
    let end: Int?
    let reason: String?
    let profileRuleID: String?

    private enum CodingKeys: String, CodingKey {
        case id
        case text
        case type
        case source
        case replacement
        case confidence
        case action
        case start
        case end
        case reason
        case profileRuleID = "profile_rule_id"
    }
}

enum ModelProviderType: String, CaseIterable, Identifiable, Codable {
    case ollama
    case openAICompatible = "openai_compatible"
    case lmStudio = "lm_studio"

    var id: String { rawValue }

    var title: String {
        switch self {
        case .ollama:
            return "Ollama"
        case .openAICompatible:
            return "OpenAI-Compatible"
        case .lmStudio:
            return "LM Studio"
        }
    }

    var defaultBaseURL: String {
        switch self {
        case .ollama:
            return "http://127.0.0.1:11434"
        case .openAICompatible:
            return "http://127.0.0.1:1234/v1"
        case .lmStudio:
            return "http://127.0.0.1:1234/v1"
        }
    }

    var defaultModel: String {
        switch self {
        case .ollama:
            return "llama3.1"
        case .openAICompatible:
            return "local-model"
        case .lmStudio:
            return "local-model"
        }
    }

    var defaultIsLocal: Bool {
        switch self {
        case .ollama, .lmStudio:
            return true
        case .openAICompatible:
            return false
        }
    }
}

struct ModelProviderListResponse: Decodable {
    let providers: [ModelProvider]
}

struct ModelProvider: Codable, Identifiable, Equatable {
    let id: String
    var name: String
    var providerType: ModelProviderType
    var baseURL: String
    var model: String
    var isLocal: Bool
    var supportsJSONMode: Bool
    var timeout: Double
    var maxTokens: Int
    var apiKeyConfigured: Bool
    let createdAt: String
    let updatedAt: String

    private enum CodingKeys: String, CodingKey {
        case id
        case name
        case providerType = "provider_type"
        case baseURL = "base_url"
        case model
        case isLocal = "is_local"
        case supportsJSONMode = "supports_json_mode"
        case timeout
        case maxTokens = "max_tokens"
        case apiKeyConfigured = "api_key_configured"
        case createdAt = "created_at"
        case updatedAt = "updated_at"
    }
}

struct ModelProviderInput: Encodable {
    var name: String
    var providerType: ModelProviderType
    var baseURL: String
    var apiKey: String?
    var model: String
    var isLocal: Bool
    var supportsJSONMode: Bool
    var timeout: Double
    var maxTokens: Int

    private enum CodingKeys: String, CodingKey {
        case name
        case providerType = "provider_type"
        case baseURL = "base_url"
        case apiKey = "api_key"
        case model
        case isLocal = "is_local"
        case supportsJSONMode = "supports_json_mode"
        case timeout
        case maxTokens = "max_tokens"
    }
}

struct ModelProviderTestResponse: Decodable {
    let providerID: String
    let ok: Bool
    let message: String

    private enum CodingKeys: String, CodingKey {
        case providerID = "provider_id"
        case ok
        case message
    }
}

struct ModelReviewSettings: Codable, Equatable {
    var enableLLMReview: Bool
    var selectedReviewProviderID: String?
    var allowRawTextForExternalModels: Bool

    private enum CodingKeys: String, CodingKey {
        case enableLLMReview = "enable_llm_review"
        case selectedReviewProviderID = "selected_review_provider_id"
        case allowRawTextForExternalModels = "allow_raw_text_for_external_models"
    }
}

struct GatewaySettings: Codable, Equatable {
    var enabled: Bool
    var bindHost: String
    var port: Int
    var upstreamProviderID: String?
    var allowRawTextToUpstream: Bool
    var redactRequestMessages: Bool

    static let disabled = GatewaySettings(
        enabled: false,
        bindHost: "127.0.0.1",
        port: 8765,
        upstreamProviderID: nil,
        allowRawTextToUpstream: false,
        redactRequestMessages: true
    )

    var endpointURL: String {
        let host = bindHost.contains(":") && !bindHost.hasPrefix("[") ? "[\(bindHost)]" : bindHost
        return "http://\(host):\(port)/v1"
    }

    private enum CodingKeys: String, CodingKey {
        case enabled
        case bindHost = "bind_host"
        case port
        case upstreamProviderID = "upstream_provider_id"
        case allowRawTextToUpstream = "allow_raw_text_to_upstream"
        case redactRequestMessages = "redact_request_messages"
    }
}

struct GatewayPreviewResponse: Decodable {
    let gatewayEnabled: Bool
    let endpointURL: String
    let upstreamProviderID: String?
    let upstreamProviderName: String?
    let upstreamProviderIsLocal: Bool?
    let rawTextSent: Bool
    let rawTextBlocked: Bool
    let warning: String?
    let forwardedRequest: JSONValue
    let messages: [GatewayMessageRedactionSummary]

    private enum CodingKeys: String, CodingKey {
        case gatewayEnabled = "gateway_enabled"
        case endpointURL = "endpoint_url"
        case upstreamProviderID = "upstream_provider_id"
        case upstreamProviderName = "upstream_provider_name"
        case upstreamProviderIsLocal = "upstream_provider_is_local"
        case rawTextSent = "raw_text_sent"
        case rawTextBlocked = "raw_text_blocked"
        case warning
        case forwardedRequest = "forwarded_request"
        case messages
    }
}

struct GatewayMessageRedactionSummary: Decodable, Identifiable {
    var id: Int { index }

    let index: Int
    let role: String?
    let textPartCount: Int
    let entities: [GatewayRedactionEntity]
    let summary: [String: Int]

    private enum CodingKeys: String, CodingKey {
        case index
        case role
        case textPartCount = "text_part_count"
        case entities
        case summary
    }
}

struct GatewayRedactionEntity: Decodable, Identifiable {
    let id: String
    let type: String
    let start: Int
    let end: Int
    let confidence: Double
    let source: String
    let action: String
    let replacement: String
    let profileRuleID: String?

    private enum CodingKeys: String, CodingKey {
        case id
        case type
        case start
        case end
        case confidence
        case source
        case action
        case replacement
        case profileRuleID = "profile_rule_id"
    }
}

struct ClearLocalDataResponse: Decodable {
    let clearedPaths: [String]
    let skippedPaths: [String]
    let keychainEntriesCleared: Int
    let message: String

    private enum CodingKeys: String, CodingKey {
        case clearedPaths = "cleared_paths"
        case skippedPaths = "skipped_paths"
        case keychainEntriesCleared = "keychain_entries_cleared"
        case message
    }
}

enum JSONValue: Codable, Equatable {
    case string(String)
    case number(Double)
    case bool(Bool)
    case object([String: JSONValue])
    case array([JSONValue])
    case null

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if container.decodeNil() {
            self = .null
        } else if let value = try? container.decode(Bool.self) {
            self = .bool(value)
        } else if let value = try? container.decode(Double.self) {
            self = .number(value)
        } else if let value = try? container.decode(String.self) {
            self = .string(value)
        } else if let value = try? container.decode([String: JSONValue].self) {
            self = .object(value)
        } else if let value = try? container.decode([JSONValue].self) {
            self = .array(value)
        } else {
            throw DecodingError.dataCorruptedError(in: container, debugDescription: "Unsupported JSON value.")
        }
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        switch self {
        case .string(let value):
            try container.encode(value)
        case .number(let value):
            try container.encode(value)
        case .bool(let value):
            try container.encode(value)
        case .object(let value):
            try container.encode(value)
        case .array(let value):
            try container.encode(value)
        case .null:
            try container.encodeNil()
        }
    }

    var foundationValue: Any {
        switch self {
        case .string(let value):
            return value
        case .number(let value):
            return value
        case .bool(let value):
            return value
        case .object(let value):
            return value.mapValues { $0.foundationValue }
        case .array(let value):
            return value.map { $0.foundationValue }
        case .null:
            return NSNull()
        }
    }

    var prettyPrintedString: String {
        guard JSONSerialization.isValidJSONObject(foundationValue),
              let data = try? JSONSerialization.data(
                withJSONObject: foundationValue,
                options: [.prettyPrinted, .sortedKeys]
              ),
              let text = String(data: data, encoding: .utf8)
        else {
            return ""
        }
        return text
    }
}

struct ModelReviewResult: Decodable {
    let providerID: String?
    let providerName: String?
    let providerIsLocal: Bool
    let rawTextSent: Bool
    let rawTextBlocked: Bool
    let warning: String?
    let parsed: Bool
    let parseError: String?
    let suggestion: ModelReviewSuggestion?
    let appliedMissedItems: [AppliedReviewSuggestion]
    let invalidSuggestions: [String]

    private enum CodingKeys: String, CodingKey {
        case providerID = "provider_id"
        case providerName = "provider_name"
        case providerIsLocal = "provider_is_local"
        case rawTextSent = "raw_text_sent"
        case rawTextBlocked = "raw_text_blocked"
        case warning
        case parsed
        case parseError = "parse_error"
        case suggestion
        case appliedMissedItems = "applied_missed_items"
        case invalidSuggestions = "invalid_suggestions"
    }
}

struct ModelReviewSuggestion: Decodable {
    let passed: Bool
    let riskLevel: String
    let missedItems: [ModelReviewMissedItem]
    let falsePositives: [ModelReviewFalsePositive]
    let suggestedPolicyUpdates: [ModelSuggestedPolicyUpdate]

    private enum CodingKeys: String, CodingKey {
        case passed = "pass"
        case riskLevel = "risk_level"
        case missedItems = "missed_items"
        case falsePositives = "false_positives"
        case suggestedPolicyUpdates = "suggested_policy_updates"
    }
}

struct ModelReviewMissedItem: Decodable {
    let text: String
    let entityType: String
    let replacement: String?
    let reason: String?

    private enum CodingKeys: String, CodingKey {
        case text
        case entityType = "entity_type"
        case replacement
        case reason
    }
}

struct ModelReviewFalsePositive: Decodable {
    let entityID: String?
    let text: String?
    let entityType: String?
    let reason: String?

    private enum CodingKeys: String, CodingKey {
        case entityID = "entity_id"
        case text
        case entityType = "entity_type"
        case reason
    }
}

struct ModelSuggestedPolicyUpdate: Decodable {
    let entityType: String?
    let pattern: String?
    let replacement: String?
    let action: String?
    let reason: String?

    private enum CodingKeys: String, CodingKey {
        case entityType = "entity_type"
        case pattern
        case replacement
        case action
        case reason
    }
}

struct AppliedReviewSuggestion: Decodable {
    let text: String
    let entityType: String
    let replacement: String
    let occurrenceCount: Int

    private enum CodingKeys: String, CodingKey {
        case text
        case entityType = "entity_type"
        case replacement
        case occurrenceCount = "occurrence_count"
    }
}

enum RevisionScope: String, CaseIterable, Identifiable, Codable {
    case currentDocument = "current_document"
    case profile

    var id: String { rawValue }

    var title: String {
        switch self {
        case .currentDocument:
            return "This Document"
        case .profile:
            return "Save to Profile"
        }
    }
}

struct RevisionCommand: Codable, Equatable {
    let intent: String
    let targetText: String?
    let targetEntityID: String?
    let entityType: String?
    let replacement: String?
    let action: ProfileRuleAction?
    let scope: RevisionScope
    let reason: String?

    private enum CodingKeys: String, CodingKey {
        case intent
        case targetText = "target_text"
        case targetEntityID = "target_entity_id"
        case entityType = "entity_type"
        case replacement
        case action
        case scope
        case reason
    }
}

struct RevisionParseResult: Decodable {
    let parser: String
    let providerID: String?
    let providerName: String?
    let providerIsLocal: Bool
    let rawTextSent: Bool
    let rawTextBlocked: Bool
    let warning: String?
    let parsed: Bool
    let parseError: String?
    let commands: [RevisionCommand]
    let invalidCommands: [String]

    private enum CodingKeys: String, CodingKey {
        case parser
        case providerID = "provider_id"
        case providerName = "provider_name"
        case providerIsLocal = "provider_is_local"
        case rawTextSent = "raw_text_sent"
        case rawTextBlocked = "raw_text_blocked"
        case warning
        case parsed
        case parseError = "parse_error"
        case commands
        case invalidCommands = "invalid_commands"
    }
}

struct AppliedRevisionCommand: Decodable {
    let command: RevisionCommand
    let occurrenceCount: Int
    let profileRuleIDs: [String]
    let updatedProfileRuleIDs: [String]
    let skippedReason: String?

    private enum CodingKeys: String, CodingKey {
        case command
        case occurrenceCount = "occurrence_count"
        case profileRuleIDs = "profile_rule_ids"
        case updatedProfileRuleIDs = "updated_profile_rule_ids"
        case skippedReason = "skipped_reason"
    }
}

struct TextRevisionResponse: Decodable {
    let initialResult: TextRedactionResponse
    let parseResult: RevisionParseResult
    let finalResult: TextRedactionResponse
    let appliedCommands: [AppliedRevisionCommand]
    let profileRules: [ProfileRule]

    private enum CodingKeys: String, CodingKey {
        case initialResult = "initial_result"
        case parseResult = "parse_result"
        case finalResult = "final_result"
        case appliedCommands = "applied_commands"
        case profileRules = "profile_rules"
    }
}

enum ProfileRuleAction: String, CaseIterable, Identifiable, Codable {
    case mask
    case ask
    case allow

    var id: String { rawValue }

    var title: String {
        switch self {
        case .mask:
            return "Always Mask"
        case .ask:
            return "Ask Me"
        case .allow:
            return "Allow"
        }
    }
}

enum ProfileRuleScope: String, CaseIterable, Identifiable, Codable {
    case global
    case text

    var id: String { rawValue }

    var title: String {
        switch self {
        case .global:
            return "Global"
        case .text:
            return "Text"
        }
    }
}

struct RedactionProfile: Codable {
    var version: Int
    var rules: [ProfileRule]
}

struct ProfileLearningResponse: Decodable {
    let candidates: [ProfileLearningCandidate]
}

struct ProfileLearningCandidate: Decodable, Identifiable, Equatable {
    let id: String
    let suggestedEntityType: String
    let pattern: String
    let aliases: [String]
    let replacement: String
    let suggestedAction: ProfileRuleAction
    let sourceDetector: String
    let confidence: Double
    let reason: String

    private enum CodingKeys: String, CodingKey {
        case id
        case suggestedEntityType = "suggested_entity_type"
        case pattern
        case aliases
        case replacement
        case suggestedAction = "suggested_action"
        case sourceDetector = "source_detector"
        case confidence
        case reason
    }
}

struct ProfileRule: Codable, Identifiable, Equatable {
    let id: String
    var label: String
    var entityType: String
    var patterns: [String]
    var aliases: [String]
    var replacement: String
    var action: ProfileRuleAction
    var enabled: Bool
    var scope: ProfileRuleScope
    let createdAt: String
    let updatedAt: String

    private enum CodingKeys: String, CodingKey {
        case id
        case label
        case entityType = "entity_type"
        case patterns
        case aliases
        case replacement
        case action
        case enabled
        case scope
        case createdAt = "created_at"
        case updatedAt = "updated_at"
    }
}

struct ProfileRuleInput: Encodable {
    var label: String
    var entityType: String
    var patterns: [String]
    var aliases: [String]
    var replacement: String?
    var action: ProfileRuleAction
    var enabled: Bool
    var scope: ProfileRuleScope

    private enum CodingKeys: String, CodingKey {
        case label
        case entityType = "entity_type"
        case patterns
        case aliases
        case replacement
        case action
        case enabled
        case scope
    }
}

enum PrivacyPreflightAPIError: LocalizedError {
    case workerUnavailable(String)
    case timeout
    case invalidResponse
    case serverStatus(Int)
    case serverMessage(Int, String)
    case requestFailed(String)

    var errorDescription: String? {
        switch self {
        case .workerUnavailable(let endpoint):
            return "The local worker is not running at \(endpoint). Start the worker, then try again."
        case .timeout:
            return "The local worker did not respond in time. Check that it is still running, then try again."
        case .invalidResponse:
            return "The worker responded, but the app could not read the response. Make sure the app and worker are from the same project version."
        case .serverStatus(let code):
            return "The worker returned an unexpected HTTP \(code) response."
        case .serverMessage(_, let message):
            return message
        case .requestFailed(let message):
            return message
        }
    }

    var isWorkerAvailabilityError: Bool {
        switch self {
        case .workerUnavailable, .timeout:
            return true
        case .invalidResponse, .serverStatus, .serverMessage, .requestFailed:
            return false
        }
    }
}

struct PrivacyPreflightAPIClient {
    let baseURL: URL
    private let session: URLSession
    private let decoder = JSONDecoder()
    private let encoder = JSONEncoder()

    init(baseURL: URL = WorkerLifecycleManager.configuredEndpointURL) {
        self.baseURL = baseURL

        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 30
        configuration.timeoutIntervalForResource = 180
        self.session = URLSession(configuration: configuration)
    }

    private var baseURLDisplayString: String {
        baseURL.absoluteString.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
    }

    func checkHealth() async throws -> HealthResponse {
        var request = URLRequest(url: baseURL.appendingPathComponent("health"))
        request.httpMethod = "GET"
        request.timeoutInterval = 2

        do {
            let data = try await data(for: request)
            return try decoder.decode(HealthResponse.self, from: data)
        } catch let error as PrivacyPreflightAPIError {
            throw error
        } catch is DecodingError {
            throw PrivacyPreflightAPIError.invalidResponse
        } catch {
            throw map(error)
        }
    }

    func redactText(_ text: String, mode: TextRedactionMode) async throws -> TextRedactionResponse {
        let url = baseURL
            .appendingPathComponent("redact")
            .appendingPathComponent("text")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.timeoutInterval = 12
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        do {
            request.httpBody = try encoder.encode(TextRedactionRequest(text: text, mode: mode))
            let data = try await data(for: request)
            return try decoder.decode(TextRedactionResponse.self, from: data)
        } catch let error as PrivacyPreflightAPIError {
            throw error
        } catch let error as EncodingError {
            throw PrivacyPreflightAPIError.requestFailed(error.localizedDescription)
        } catch is DecodingError {
            throw PrivacyPreflightAPIError.invalidResponse
        } catch {
            throw map(error)
        }
    }

    func redactTextWithReview(
        _ text: String,
        mode: TextRedactionMode,
        settings: ModelReviewSettings
    ) async throws -> TextReviewResponse {
        let url = baseURL
            .appendingPathComponent("redact")
            .appendingPathComponent("text")
            .appendingPathComponent("review")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.timeoutInterval = 45
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        do {
            request.httpBody = try encoder.encode(
                TextReviewRequest(
                    text: text,
                    mode: mode,
                    providerID: settings.selectedReviewProviderID,
                    enableLLMReview: settings.enableLLMReview,
                    allowRawTextForExternalModels: settings.allowRawTextForExternalModels
                )
            )
            let data = try await data(for: request)
            return try decoder.decode(TextReviewResponse.self, from: data)
        } catch let error as PrivacyPreflightAPIError {
            throw error
        } catch let error as EncodingError {
            throw PrivacyPreflightAPIError.requestFailed(error.localizedDescription)
        } catch is DecodingError {
            throw PrivacyPreflightAPIError.invalidResponse
        } catch {
            throw map(error)
        }
    }

    func redactImage(
        fileURL: URL,
        mode: ImageRedactionMode,
        manualRectangles: [ImageManualRectangle]
    ) async throws -> ImageRedactionResponse {
        let url = baseURL
            .appendingPathComponent("redact")
            .appendingPathComponent("image")
        var request = URLRequest(url: url)
        let boundary = "PrivacyPreflightBoundary-\(UUID().uuidString)"
        request.httpMethod = "POST"
        request.timeoutInterval = 60
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        do {
            let fileData = try Data(contentsOf: fileURL)
            let rectanglesData = try encoder.encode(manualRectangles)
            let rectanglesJSON = String(data: rectanglesData, encoding: .utf8) ?? "[]"
            request.httpBody = multipartImageBody(
                boundary: boundary,
                fileURL: fileURL,
                fileData: fileData,
                mode: mode,
                manualRectanglesJSON: rectanglesJSON
            )
            let data = try await data(for: request)
            return try decoder.decode(ImageRedactionResponse.self, from: data)
        } catch let error as PrivacyPreflightAPIError {
            throw error
        } catch let error as EncodingError {
            throw PrivacyPreflightAPIError.requestFailed(error.localizedDescription)
        } catch is DecodingError {
            throw PrivacyPreflightAPIError.invalidResponse
        } catch {
            throw map(error)
        }
    }

    func analyzePDF(
        fileURL: URL,
        mode: TextRedactionMode
    ) async throws -> PDFRedactionAnalysisResponse {
        let url = baseURL
            .appendingPathComponent("redact")
            .appendingPathComponent("pdf")
            .appendingPathComponent("analyze")
        var request = URLRequest(url: url)
        let boundary = "PrivacyPreflightBoundary-\(UUID().uuidString)"
        request.httpMethod = "POST"
        request.timeoutInterval = 90
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        do {
            let fileData = try Data(contentsOf: fileURL)
            request.httpBody = multipartPDFBody(
                boundary: boundary,
                fileURL: fileURL,
                fileData: fileData,
                mode: mode,
                manualRectanglesJSON: nil
            )
            let data = try await data(for: request)
            return try decoder.decode(PDFRedactionAnalysisResponse.self, from: data)
        } catch let error as PrivacyPreflightAPIError {
            throw error
        } catch is DecodingError {
            throw PrivacyPreflightAPIError.invalidResponse
        } catch {
            throw map(error)
        }
    }

    func exportRedactedPDF(
        fileURL: URL,
        mode: TextRedactionMode,
        manualRectangles: [PDFManualRectangle]
    ) async throws -> PDFRedactionExportResponse {
        let url = baseURL
            .appendingPathComponent("redact")
            .appendingPathComponent("pdf")
            .appendingPathComponent("export")
        var request = URLRequest(url: url)
        let boundary = "PrivacyPreflightBoundary-\(UUID().uuidString)"
        request.httpMethod = "POST"
        request.timeoutInterval = 150
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        do {
            let fileData = try Data(contentsOf: fileURL)
            let rectanglesData = try encoder.encode(manualRectangles)
            let rectanglesJSON = String(data: rectanglesData, encoding: .utf8) ?? "[]"
            request.httpBody = multipartPDFBody(
                boundary: boundary,
                fileURL: fileURL,
                fileData: fileData,
                mode: mode,
                manualRectanglesJSON: rectanglesJSON
            )
            let data = try await data(for: request)
            return try decoder.decode(PDFRedactionExportResponse.self, from: data)
        } catch let error as PrivacyPreflightAPIError {
            throw error
        } catch let error as EncodingError {
            throw PrivacyPreflightAPIError.requestFailed(error.localizedDescription)
        } catch is DecodingError {
            throw PrivacyPreflightAPIError.invalidResponse
        } catch {
            throw map(error)
        }
    }

    func reviseText(
        _ text: String,
        mode: TextRedactionMode,
        instruction: String,
        scope: RevisionScope,
        selectedEntityID: String?,
        settings: ModelReviewSettings
    ) async throws -> TextRevisionResponse {
        let url = baseURL
            .appendingPathComponent("redact")
            .appendingPathComponent("text")
            .appendingPathComponent("revise")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.timeoutInterval = 45
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        do {
            request.httpBody = try encoder.encode(
                TextRevisionRequest(
                    text: text,
                    mode: mode,
                    instruction: instruction,
                    scope: scope,
                    selectedEntityID: selectedEntityID,
                    providerID: settings.selectedReviewProviderID,
                    enableModelParsing: settings.enableLLMReview,
                    allowRawTextForExternalModels: settings.allowRawTextForExternalModels
                )
            )
            let data = try await data(for: request)
            return try decoder.decode(TextRevisionResponse.self, from: data)
        } catch let error as PrivacyPreflightAPIError {
            throw error
        } catch let error as EncodingError {
            throw PrivacyPreflightAPIError.requestFailed(error.localizedDescription)
        } catch is DecodingError {
            throw PrivacyPreflightAPIError.invalidResponse
        } catch {
            throw map(error)
        }
    }

    func fetchProfile() async throws -> RedactionProfile {
        var request = URLRequest(url: baseURL.appendingPathComponent("profile"))
        request.httpMethod = "GET"
        request.timeoutInterval = 8

        do {
            let data = try await data(for: request)
            return try decoder.decode(RedactionProfile.self, from: data)
        } catch let error as PrivacyPreflightAPIError {
            throw error
        } catch is DecodingError {
            throw PrivacyPreflightAPIError.invalidResponse
        } catch {
            throw map(error)
        }
    }

    func learnProfileCandidates(from text: String, mode: TextRedactionMode) async throws -> ProfileLearningResponse {
        let url = baseURL
            .appendingPathComponent("profile")
            .appendingPathComponent("learn-from-text")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.timeoutInterval = 12
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        do {
            request.httpBody = try encoder.encode(ProfileLearningRequest(text: text, mode: mode))
            let data = try await data(for: request)
            return try decoder.decode(ProfileLearningResponse.self, from: data)
        } catch let error as PrivacyPreflightAPIError {
            throw error
        } catch let error as EncodingError {
            throw PrivacyPreflightAPIError.requestFailed(error.localizedDescription)
        } catch is DecodingError {
            throw PrivacyPreflightAPIError.invalidResponse
        } catch {
            throw map(error)
        }
    }

    func createProfileRule(_ rule: ProfileRuleInput) async throws -> ProfileRule {
        let url = baseURL
            .appendingPathComponent("profile")
            .appendingPathComponent("rules")
        return try await sendProfileRule(rule, to: url, method: "POST")
    }

    func updateProfileRule(id: String, rule: ProfileRuleInput) async throws -> ProfileRule {
        let url = baseURL
            .appendingPathComponent("profile")
            .appendingPathComponent("rules")
            .appendingPathComponent(id)
        return try await sendProfileRule(rule, to: url, method: "PUT")
    }

    func deleteProfileRule(id: String) async throws {
        let url = baseURL
            .appendingPathComponent("profile")
            .appendingPathComponent("rules")
            .appendingPathComponent(id)
        var request = URLRequest(url: url)
        request.httpMethod = "DELETE"
        request.timeoutInterval = 8

        do {
            _ = try await data(for: request)
        } catch let error as PrivacyPreflightAPIError {
            throw error
        } catch {
            throw map(error)
        }
    }

    func fetchModelProviders() async throws -> [ModelProvider] {
        let url = baseURL
            .appendingPathComponent("models")
            .appendingPathComponent("providers")
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = 8

        do {
            let data = try await data(for: request)
            return try decoder.decode(ModelProviderListResponse.self, from: data).providers
        } catch let error as PrivacyPreflightAPIError {
            throw error
        } catch is DecodingError {
            throw PrivacyPreflightAPIError.invalidResponse
        } catch {
            throw map(error)
        }
    }

    func createModelProvider(_ provider: ModelProviderInput) async throws -> ModelProvider {
        let url = baseURL
            .appendingPathComponent("models")
            .appendingPathComponent("providers")
        return try await sendModelProvider(provider, to: url, method: "POST")
    }

    func updateModelProvider(id: String, provider: ModelProviderInput) async throws -> ModelProvider {
        let url = baseURL
            .appendingPathComponent("models")
            .appendingPathComponent("providers")
            .appendingPathComponent(id)
        return try await sendModelProvider(provider, to: url, method: "PUT")
    }

    func deleteModelProvider(id: String) async throws {
        let url = baseURL
            .appendingPathComponent("models")
            .appendingPathComponent("providers")
            .appendingPathComponent(id)
        var request = URLRequest(url: url)
        request.httpMethod = "DELETE"
        request.timeoutInterval = 8

        do {
            _ = try await data(for: request)
        } catch let error as PrivacyPreflightAPIError {
            throw error
        } catch {
            throw map(error)
        }
    }

    func testModelProvider(id: String) async throws -> ModelProviderTestResponse {
        let url = baseURL
            .appendingPathComponent("models")
            .appendingPathComponent("providers")
            .appendingPathComponent(id)
            .appendingPathComponent("test")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.timeoutInterval = 20

        do {
            let data = try await data(for: request)
            return try decoder.decode(ModelProviderTestResponse.self, from: data)
        } catch let error as PrivacyPreflightAPIError {
            throw error
        } catch is DecodingError {
            throw PrivacyPreflightAPIError.invalidResponse
        } catch {
            throw map(error)
        }
    }

    func fetchModelSettings() async throws -> ModelReviewSettings {
        let url = baseURL
            .appendingPathComponent("models")
            .appendingPathComponent("settings")
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = 8

        do {
            let data = try await data(for: request)
            return try decoder.decode(ModelReviewSettings.self, from: data)
        } catch let error as PrivacyPreflightAPIError {
            throw error
        } catch is DecodingError {
            throw PrivacyPreflightAPIError.invalidResponse
        } catch {
            throw map(error)
        }
    }

    func updateModelSettings(_ settings: ModelReviewSettings) async throws -> ModelReviewSettings {
        let url = baseURL
            .appendingPathComponent("models")
            .appendingPathComponent("settings")
        var request = URLRequest(url: url)
        request.httpMethod = "PUT"
        request.timeoutInterval = 8
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        do {
            request.httpBody = try encoder.encode(settings)
            let data = try await data(for: request)
            return try decoder.decode(ModelReviewSettings.self, from: data)
        } catch let error as PrivacyPreflightAPIError {
            throw error
        } catch let error as EncodingError {
            throw PrivacyPreflightAPIError.requestFailed(error.localizedDescription)
        } catch is DecodingError {
            throw PrivacyPreflightAPIError.invalidResponse
        } catch {
            throw map(error)
        }
    }

    func fetchGatewaySettings() async throws -> GatewaySettings {
        let url = baseURL
            .appendingPathComponent("gateway")
            .appendingPathComponent("settings")
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = 8

        do {
            let data = try await data(for: request)
            return try decoder.decode(GatewaySettings.self, from: data)
        } catch let error as PrivacyPreflightAPIError {
            throw error
        } catch is DecodingError {
            throw PrivacyPreflightAPIError.invalidResponse
        } catch {
            throw map(error)
        }
    }

    func updateGatewaySettings(_ settings: GatewaySettings) async throws -> GatewaySettings {
        let url = baseURL
            .appendingPathComponent("gateway")
            .appendingPathComponent("settings")
        var request = URLRequest(url: url)
        request.httpMethod = "PUT"
        request.timeoutInterval = 8
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        do {
            request.httpBody = try encoder.encode(settings)
            let data = try await data(for: request)
            return try decoder.decode(GatewaySettings.self, from: data)
        } catch let error as PrivacyPreflightAPIError {
            throw error
        } catch let error as EncodingError {
            throw PrivacyPreflightAPIError.requestFailed(error.localizedDescription)
        } catch is DecodingError {
            throw PrivacyPreflightAPIError.invalidResponse
        } catch {
            throw map(error)
        }
    }

    func previewGateway(_ previewRequest: GatewayPreviewRequest) async throws -> GatewayPreviewResponse {
        let url = baseURL
            .appendingPathComponent("gateway")
            .appendingPathComponent("preview")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.timeoutInterval = 12
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        do {
            request.httpBody = try encoder.encode(previewRequest)
            let data = try await data(for: request)
            return try decoder.decode(GatewayPreviewResponse.self, from: data)
        } catch let error as PrivacyPreflightAPIError {
            throw error
        } catch let error as EncodingError {
            throw PrivacyPreflightAPIError.requestFailed(error.localizedDescription)
        } catch is DecodingError {
            throw PrivacyPreflightAPIError.invalidResponse
        } catch {
            throw map(error)
        }
    }

    func fetchPrivacyDiagnosticsData() async throws -> Data {
        let url = baseURL
            .appendingPathComponent("privacy")
            .appendingPathComponent("diagnostics")
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = 8

        do {
            return try await data(for: request)
        } catch let error as PrivacyPreflightAPIError {
            throw error
        } catch {
            throw map(error)
        }
    }

    func clearLocalData(clearKeychainAPIKeys: Bool) async throws -> ClearLocalDataResponse {
        let url = baseURL
            .appendingPathComponent("privacy")
            .appendingPathComponent("clear-local-data")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.timeoutInterval = 12
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        do {
            request.httpBody = try encoder.encode(
                ClearLocalDataRequest(clearKeychainAPIKeys: clearKeychainAPIKeys)
            )
            let data = try await data(for: request)
            return try decoder.decode(ClearLocalDataResponse.self, from: data)
        } catch let error as PrivacyPreflightAPIError {
            throw error
        } catch let error as EncodingError {
            throw PrivacyPreflightAPIError.requestFailed(error.localizedDescription)
        } catch is DecodingError {
            throw PrivacyPreflightAPIError.invalidResponse
        } catch {
            throw map(error)
        }
    }

    private func sendProfileRule(_ rule: ProfileRuleInput, to url: URL, method: String) async throws -> ProfileRule {
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.timeoutInterval = 8
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        do {
            request.httpBody = try encoder.encode(rule)
            let data = try await data(for: request)
            return try decoder.decode(ProfileRule.self, from: data)
        } catch let error as PrivacyPreflightAPIError {
            throw error
        } catch let error as EncodingError {
            throw PrivacyPreflightAPIError.requestFailed(error.localizedDescription)
        } catch is DecodingError {
            throw PrivacyPreflightAPIError.invalidResponse
        } catch {
            throw map(error)
        }
    }

    private func sendModelProvider(_ provider: ModelProviderInput, to url: URL, method: String) async throws -> ModelProvider {
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.timeoutInterval = 8
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        do {
            request.httpBody = try encoder.encode(provider)
            let data = try await data(for: request)
            return try decoder.decode(ModelProvider.self, from: data)
        } catch let error as PrivacyPreflightAPIError {
            throw error
        } catch let error as EncodingError {
            throw PrivacyPreflightAPIError.requestFailed(error.localizedDescription)
        } catch is DecodingError {
            throw PrivacyPreflightAPIError.invalidResponse
        } catch {
            throw map(error)
        }
    }

    private func multipartImageBody(
        boundary: String,
        fileURL: URL,
        fileData: Data,
        mode: ImageRedactionMode,
        manualRectanglesJSON: String
    ) -> Data {
        var body = Data()
        body.appendUTF8("--\(boundary)\r\n")
        body.appendUTF8("Content-Disposition: form-data; name=\"mode\"\r\n\r\n")
        body.appendUTF8("\(mode.rawValue)\r\n")
        body.appendUTF8("--\(boundary)\r\n")
        body.appendUTF8("Content-Disposition: form-data; name=\"manual_rectangles\"\r\n\r\n")
        body.appendUTF8("\(manualRectanglesJSON)\r\n")
        body.appendUTF8("--\(boundary)\r\n")
        body.appendUTF8("Content-Disposition: form-data; name=\"image\"; filename=\"\(fileURL.lastPathComponent)\"\r\n")
        body.appendUTF8("Content-Type: \(imageMediaType(for: fileURL))\r\n\r\n")
        body.append(fileData)
        body.appendUTF8("\r\n--\(boundary)--\r\n")
        return body
    }

    private func multipartPDFBody(
        boundary: String,
        fileURL: URL,
        fileData: Data,
        mode: TextRedactionMode,
        manualRectanglesJSON: String?
    ) -> Data {
        var body = Data()
        body.appendUTF8("--\(boundary)\r\n")
        body.appendUTF8("Content-Disposition: form-data; name=\"mode\"\r\n\r\n")
        body.appendUTF8("\(mode.rawValue)\r\n")
        if let manualRectanglesJSON {
            body.appendUTF8("--\(boundary)\r\n")
            body.appendUTF8("Content-Disposition: form-data; name=\"manual_rectangles\"\r\n\r\n")
            body.appendUTF8("\(manualRectanglesJSON)\r\n")
        }
        body.appendUTF8("--\(boundary)\r\n")
        body.appendUTF8("Content-Disposition: form-data; name=\"pdf\"; filename=\"\(fileURL.lastPathComponent)\"\r\n")
        body.appendUTF8("Content-Type: application/pdf\r\n\r\n")
        body.append(fileData)
        body.appendUTF8("\r\n--\(boundary)--\r\n")
        return body
    }

    private func imageMediaType(for fileURL: URL) -> String {
        switch fileURL.pathExtension.lowercased() {
        case "jpg", "jpeg":
            return "image/jpeg"
        default:
            return "image/png"
        }
    }

    private func data(for request: URLRequest) async throws -> Data {
        let (data, response) = try await session.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse else {
            throw PrivacyPreflightAPIError.invalidResponse
        }
        guard (200..<300).contains(httpResponse.statusCode) else {
            if let errorResponse = try? decoder.decode(ServerErrorResponse.self, from: data),
               let detail = errorResponse.message,
               !detail.isEmpty {
                throw PrivacyPreflightAPIError.serverMessage(httpResponse.statusCode, detail)
            }
            throw PrivacyPreflightAPIError.serverStatus(httpResponse.statusCode)
        }
        return data
    }

    private func map(_ error: Error) -> PrivacyPreflightAPIError {
        guard let urlError = error as? URLError else {
            return .requestFailed(error.localizedDescription)
        }

        switch urlError.code {
        case .timedOut:
            return .timeout
        case .cannotConnectToHost, .cannotFindHost, .networkConnectionLost, .notConnectedToInternet, .dnsLookupFailed:
            return .workerUnavailable(baseURLDisplayString)
        default:
            return .requestFailed(urlError.localizedDescription)
        }
    }
}

private struct TextRedactionRequest: Encodable {
    let text: String
    let mode: TextRedactionMode
}

private struct ServerErrorResponse: Decodable {
    let message: String?

    private enum CodingKeys: String, CodingKey {
        case detail
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        if let detail = try? container.decode(String.self, forKey: .detail) {
            message = detail
        } else {
            message = nil
        }
    }
}

private struct TextReviewRequest: Encodable {
    let text: String
    let mode: TextRedactionMode
    let providerID: String?
    let enableLLMReview: Bool?
    let allowRawTextForExternalModels: Bool?

    private enum CodingKeys: String, CodingKey {
        case text
        case mode
        case providerID = "provider_id"
        case enableLLMReview = "enable_llm_review"
        case allowRawTextForExternalModels = "allow_raw_text_for_external_models"
    }
}

private struct TextRevisionRequest: Encodable {
    let text: String
    let mode: TextRedactionMode
    let instruction: String
    let scope: RevisionScope
    let selectedEntityID: String?
    let providerID: String?
    let enableModelParsing: Bool?
    let allowRawTextForExternalModels: Bool?

    private enum CodingKeys: String, CodingKey {
        case text
        case mode
        case instruction
        case scope
        case selectedEntityID = "selected_entity_id"
        case providerID = "provider_id"
        case enableModelParsing = "enable_model_parsing"
        case allowRawTextForExternalModels = "allow_raw_text_for_external_models"
    }
}

private struct ClearLocalDataRequest: Encodable {
    let clearProfile = true
    let clearModelProviderSettings = true
    let clearKeychainAPIKeys: Bool

    private enum CodingKeys: String, CodingKey {
        case clearProfile = "clear_profile"
        case clearModelProviderSettings = "clear_model_provider_settings"
        case clearKeychainAPIKeys = "clear_keychain_api_keys"
    }
}

private struct ProfileLearningRequest: Encodable {
    let text: String
    let mode: TextRedactionMode
}

struct GatewayPreviewRequest: Encodable {
    let model: String
    let messages: [GatewayPreviewMessage]
    let stream: Bool = false
}

struct GatewayPreviewMessage: Encodable {
    let role: String
    let content: String
}

private extension Data {
    mutating func appendUTF8(_ string: String) {
        append(Data(string.utf8))
    }
}
