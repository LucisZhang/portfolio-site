import AppKit
import SwiftUI

@MainActor
final class AppDelegate: NSObject, NSApplicationDelegate {
    func applicationWillTerminate(_ notification: Notification) {
        WorkerLifecycleManager.shared.stopSynchronouslyOnAppExit()
    }
}

@main
struct PrivacyPreflightApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate
    @StateObject private var workerManager = WorkerLifecycleManager.shared

    var body: some Scene {
        WindowGroup {
            ContentView(workerManager: workerManager)
        }
        .windowStyle(.titleBar)
    }
}
