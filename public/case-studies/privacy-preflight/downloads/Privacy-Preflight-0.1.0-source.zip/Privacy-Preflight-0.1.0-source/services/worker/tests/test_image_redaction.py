import base64
import json
from io import BytesIO

from fastapi.testclient import TestClient
from PIL import Image
from PIL.PngImagePlugin import PngInfo

from app.config import WorkerSettings
from app.image_redaction import ImageRedactionService, OCRTextBox
from app.main import create_app
from app.profile_store import ProfileStore
from app.redaction import TextRedactionPipeline


class StubOCRProvider:
    name = "stub"

    def __init__(self, boxes: list[OCRTextBox]) -> None:
        self.boxes = boxes

    def extract_text_boxes(self, image, *, image_bytes: bytes, image_format: str):
        return self.boxes


def _client(tmp_path, boxes: list[OCRTextBox]) -> TestClient:
    pipeline = TextRedactionPipeline()
    image_service = ImageRedactionService(
        ocr_provider=StubOCRProvider(boxes),
        text_pipeline=pipeline,
    )
    return TestClient(
        create_app(
            settings=WorkerSettings(),
            profile_store=ProfileStore(tmp_path / "profile.json"),
            redaction_pipeline=pipeline,
            image_redaction_service=image_service,
        )
    )


def _sample_png() -> bytes:
    image = Image.new("RGB", (160, 80), "white")
    buffer = BytesIO()
    image.save(buffer, format="PNG")
    return buffer.getvalue()


def _sample_png_with_metadata() -> bytes:
    image = Image.new("RGB", (160, 80), "white")
    metadata = PngInfo()
    metadata.add_text("Comment", "private note")
    metadata.add_text("Software", "camera app")
    metadata.add_text("Creation Time", "2026-05-28T10:00:00Z")
    buffer = BytesIO()
    image.save(buffer, format="PNG", pnginfo=metadata)
    return buffer.getvalue()


def _sample_jpeg_with_exif() -> bytes:
    image = Image.new("RGB", (160, 80), "white")
    exif = Image.Exif()
    exif[0x010F] = "Private Camera Maker"
    exif[0x0110] = "Private Camera Model"
    exif[0x0131] = "Private Software"
    exif[0x0132] = "2026:05:28 10:00:00"
    buffer = BytesIO()
    image.save(buffer, format="JPEG", exif=exif, comment=b"private comment")
    return buffer.getvalue()


def _post_image(
    client: TestClient,
    *,
    mode: str,
    manual_rectangles=None,
    image_bytes: bytes | None = None,
    filename: str = "sample.png",
    media_type: str = "image/png",
):
    data = {"mode": mode}
    if manual_rectangles is not None:
        data["manual_rectangles"] = json.dumps(manual_rectangles)
    return client.post(
        "/redact/image",
        data=data,
        files={"image": (filename, image_bytes or _sample_png(), media_type)},
    )


def _decoded_output(payload: dict) -> Image.Image:
    return Image.open(BytesIO(base64.b64decode(payload["redacted_image_base64"])))


def test_image_endpoint_accepts_sample_image_and_safe_mode_redacts_ocr_boxes(tmp_path) -> None:
    client = _client(
        tmp_path,
        [
            OCRTextBox(
                text="hello",
                x=20,
                y=20,
                width=30,
                height=16,
                confidence=0.9,
                source="stub",
            )
        ],
    )

    response = _post_image(client, mode="safe_text")

    assert response.status_code == 200
    payload = response.json()
    assert payload["mode"] == "safe_text"
    assert payload["ocr_provider"] == "stub"
    assert len(payload["ocr_boxes"]) == 1
    assert len(payload["redacted_boxes"]) == 1
    assert payload["redacted_boxes"][0]["source"] == "ocr"

    output = _decoded_output(payload).convert("RGB")
    assert output.getpixel((25, 25)) == (0, 0, 0)
    assert output.getpixel((5, 5)) == (255, 255, 255)


def test_precise_mode_redacts_only_sensitive_ocr_boxes(tmp_path) -> None:
    client = _client(
        tmp_path,
        [
            OCRTextBox(
                text="hello",
                x=20,
                y=20,
                width=30,
                height=16,
                confidence=0.9,
                source="stub",
            ),
            OCRTextBox(
                text="ada@example.com",
                x=70,
                y=20,
                width=60,
                height=16,
                confidence=0.9,
                source="stub",
            ),
        ],
    )

    response = _post_image(client, mode="precise")

    assert response.status_code == 200
    payload = response.json()
    assert len(payload["ocr_boxes"]) == 2
    assert len(payload["redacted_boxes"]) == 1
    assert payload["redacted_boxes"][0]["source"] == "text_pipeline"
    assert payload["redacted_boxes"][0]["entity_types"] == ["EMAIL"]

    output = _decoded_output(payload).convert("RGB")
    assert output.getpixel((75, 25)) == (0, 0, 0)
    assert output.getpixel((25, 25)) == (255, 255, 255)


def test_manual_rectangle_overwrites_pixels(tmp_path) -> None:
    client = _client(tmp_path, [])

    response = _post_image(
        client,
        mode="precise",
        manual_rectangles=[{"x": 10, "y": 10, "width": 25, "height": 20}],
    )

    assert response.status_code == 200
    payload = response.json()
    assert payload["summary"] == {"manual": 1}
    assert payload["redacted_boxes"][0]["source"] == "manual"

    output = _decoded_output(payload).convert("RGB")
    assert output.getpixel((15, 15)) == (0, 0, 0)
    assert output.getpixel((50, 15)) == (255, 255, 255)


def test_redacted_png_export_strips_metadata(tmp_path) -> None:
    client = _client(tmp_path, [])
    source = Image.open(BytesIO(_sample_png_with_metadata()))
    assert source.info["Comment"] == "private note"
    assert source.info["Software"] == "camera app"

    response = _post_image(
        client,
        mode="precise",
        manual_rectangles=[{"x": 10, "y": 10, "width": 25, "height": 20}],
        image_bytes=_sample_png_with_metadata(),
    )

    assert response.status_code == 200
    output = _decoded_output(response.json())
    assert "Comment" not in output.info
    assert "Software" not in output.info
    assert "Creation Time" not in output.info


def test_redacted_jpeg_export_strips_exif_and_comment_metadata(tmp_path) -> None:
    client = _client(tmp_path, [])
    source = Image.open(BytesIO(_sample_jpeg_with_exif()))
    assert source.getexif()[0x010F] == "Private Camera Maker"
    assert source.info["comment"] == b"private comment"

    response = _post_image(
        client,
        mode="precise",
        manual_rectangles=[{"x": 10, "y": 10, "width": 25, "height": 20}],
        image_bytes=_sample_jpeg_with_exif(),
        filename="sample.jpg",
        media_type="image/jpeg",
    )

    assert response.status_code == 200
    output = _decoded_output(response.json())
    assert dict(output.getexif()) == {}
    assert "comment" not in output.info
    assert "exif" not in output.info


def test_raw_ocr_text_is_not_logged(tmp_path, caplog) -> None:
    sensitive_text = "secret-person@example.com"
    client = _client(
        tmp_path,
        [
            OCRTextBox(
                text=sensitive_text,
                x=20,
                y=20,
                width=80,
                height=16,
                confidence=0.9,
                source="stub",
            )
        ],
    )

    with caplog.at_level("INFO"):
        response = _post_image(client, mode="precise")

    assert response.status_code == 200
    assert sensitive_text not in caplog.text
