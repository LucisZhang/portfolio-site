from fastapi.testclient import TestClient

from app.config import WorkerSettings
from app.main import create_app
from app.model_provider_store import InMemorySecretStore, ModelProviderStore
from app.profile_store import ProfileStore


def test_privacy_diagnostics_exclude_raw_profile_terms_and_api_keys(tmp_path) -> None:
    secret_store = InMemorySecretStore()
    client, _profile_store, _provider_store = _client(tmp_path, secret_store)

    profile_response = client.post(
        "/profile/rules",
        json={
            "label": "Private Project",
            "entity_type": "PROJECT",
            "patterns": ["Project Nightingale"],
            "aliases": ["Nightingale Secret"],
            "replacement": "[PROJECT]",
            "action": "mask",
            "enabled": True,
            "scope": "global",
        },
    )
    assert profile_response.status_code == 200

    provider_response = _create_provider(client, api_key="sk-private-diagnostic-key")
    assert provider_response.status_code == 200

    response = client.get("/privacy/diagnostics")

    assert response.status_code == 200
    payload = response.json()
    assert payload["profile_rule_count"] == 1
    assert payload["model_provider_count"] == 1
    assert payload["history_enabled"] is False
    assert "Project Nightingale" not in response.text
    assert "Nightingale Secret" not in response.text
    assert "sk-private-diagnostic-key" not in response.text


def test_clear_local_data_keeps_keychain_entries_by_default(tmp_path) -> None:
    secret_store = InMemorySecretStore()
    client, profile_store, provider_store = _client(tmp_path, secret_store)

    profile_response = client.post(
        "/profile/rules",
        json={
            "label": "Private Term",
            "entity_type": "PROJECT",
            "patterns": ["Project Nightingale"],
            "aliases": [],
            "replacement": "[PROJECT]",
            "action": "mask",
            "enabled": True,
            "scope": "global",
        },
    )
    assert profile_response.status_code == 200
    provider_response = _create_provider(client, api_key="sk-private-clear-key")
    assert provider_response.status_code == 200
    provider_id = provider_response.json()["id"]
    assert profile_store.profile_path.exists()
    assert provider_store.config_path.exists()
    assert secret_store.get_secret(provider_id) == "sk-private-clear-key"

    response = client.post("/privacy/clear-local-data", json={})

    assert response.status_code == 200
    payload = response.json()
    assert str(profile_store.profile_path) in payload["cleared_paths"]
    assert str(provider_store.config_path) in payload["cleared_paths"]
    assert payload["keychain_entries_cleared"] == 0
    assert not profile_store.profile_path.exists()
    assert not provider_store.config_path.exists()
    assert secret_store.get_secret(provider_id) == "sk-private-clear-key"
    assert client.get("/profile").json()["rules"] == []


def test_clear_local_data_can_clear_keychain_entries(tmp_path) -> None:
    secret_store = InMemorySecretStore()
    client, _profile_store, _provider_store = _client(tmp_path, secret_store)
    provider_response = _create_provider(client, api_key="sk-private-remove-key")
    assert provider_response.status_code == 200
    provider_id = provider_response.json()["id"]

    response = client.post(
        "/privacy/clear-local-data",
        json={"clear_keychain_api_keys": True},
    )

    assert response.status_code == 200
    assert response.json()["keychain_entries_cleared"] == 1
    assert secret_store.get_secret(provider_id) is None


def _client(
    tmp_path,
    secret_store: InMemorySecretStore,
) -> tuple[TestClient, ProfileStore, ModelProviderStore]:
    profile_store = ProfileStore(tmp_path / "profile.json")
    provider_store = ModelProviderStore(
        tmp_path / "model_providers.json",
        secret_store=secret_store,
    )
    app = create_app(
        settings=WorkerSettings(app_data_dir=str(tmp_path)),
        profile_store=profile_store,
        model_provider_store=provider_store,
    )
    return TestClient(app), profile_store, provider_store


def _create_provider(
    client: TestClient,
    *,
    api_key: str | None,
):
    return client.post(
        "/models/providers",
        json={
            "name": "Diagnostics Provider",
            "provider_type": "openai_compatible",
            "base_url": "https://api.example.test/v1",
            "api_key": api_key,
            "model": "test-model",
            "is_local": False,
            "supports_json_mode": True,
            "timeout": 10,
            "max_tokens": 300,
        },
    )
