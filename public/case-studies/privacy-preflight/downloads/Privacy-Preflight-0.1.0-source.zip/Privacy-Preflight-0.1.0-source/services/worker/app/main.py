import json
import tempfile
from pathlib import Path

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from pydantic import TypeAdapter, ValidationError

from .config import load_settings
from .gateway import GatewayRequestError, gateway_endpoint_url, prepare_gateway_request
from .image_redaction import (
    ImageRedactionError,
    ImageRedactionService,
    InvalidImageError,
    OCRUnavailableError,
)
from .model_clients import (
    HTTPModelProviderClient,
    ModelProviderClient,
    ModelProviderClientError,
)
from .model_provider_store import (
    ModelProviderNotFoundError,
    ModelProviderStorageError,
    ModelProviderStore,
    ModelProviderValidationError,
    SecretStoreError,
)
from .model_review import run_model_review
from .profile_store import (
    ProfileRuleNotFoundError,
    ProfileStorageError,
    ProfileStore,
    ProfileValidationError,
    default_app_data_dir,
)
from .pdf_redaction import (
    InvalidPDFError,
    PDFDependencyError,
    PDFOCRUnavailableError,
    PDFRedactionError,
    PDFRedactionService,
    PDFValidationFailedError,
)
from .redaction import TextRedactionPipeline
from .revision import apply_revision_commands, build_revision_parse_result
from .schemas import (
    ClearLocalDataRequest,
    ClearLocalDataResponse,
    GatewayPreviewResponse,
    GatewaySettings,
    HealthResponse,
    ImageRectangle,
    ImageRedactionResponse,
    LocalDataPath,
    LocalDataSummaryResponse,
    ModelProvider,
    ModelProviderListResponse,
    ModelProviderPayload,
    ModelProviderTestResponse,
    ModelReviewSettings,
    PDFManualRectangle,
    PDFRedactionAnalysisResponse,
    PDFRedactionExportResponse,
    PrivacyDiagnosticsResponse,
    Profile,
    ProfileLearningRequest,
    ProfileLearningResponse,
    ProfileRule,
    ProfileRulePayload,
    RevisionParseRequest,
    RevisionParseResponse,
    RevisionParseResult,
    TextRedactionRequest,
    TextRedactionResponse,
    TextRevisionRequest,
    TextRevisionResponse,
    TextReviewRequest,
    TextReviewResponse,
)


def create_app(
    *,
    settings: object | None = None,
    profile_store: ProfileStore | None = None,
    model_provider_store: ModelProviderStore | None = None,
    model_client: ModelProviderClient | None = None,
    redaction_pipeline: TextRedactionPipeline | None = None,
    image_redaction_service: ImageRedactionService | None = None,
    pdf_redaction_service: PDFRedactionService | None = None,
) -> FastAPI:
    worker_settings = settings or load_settings()
    store = profile_store or ProfileStore.from_settings(worker_settings)
    provider_store = model_provider_store or ModelProviderStore.from_settings(
        worker_settings
    )
    review_client = model_client or HTTPModelProviderClient()
    pipeline = redaction_pipeline or TextRedactionPipeline.from_settings(
        worker_settings,
        profile_rules_loader=store.load_enabled_rules,
    )
    image_service = image_redaction_service or ImageRedactionService.from_settings(
        worker_settings,
        text_pipeline=pipeline,
    )
    pdf_service = pdf_redaction_service or PDFRedactionService.from_settings(
        worker_settings,
        text_pipeline=pipeline,
    )

    app = FastAPI(
        title="Privacy Preflight Worker",
        version="0.1.0",
        description="Local-only worker for privacy redaction workflows.",
    )

    @app.get("/health", response_model=HealthResponse)
    async def health() -> HealthResponse:
        return HealthResponse(status="ok")

    @app.get("/privacy/local-data", response_model=LocalDataSummaryResponse)
    async def local_data_summary() -> LocalDataSummaryResponse:
        return _local_data_summary(worker_settings, store, provider_store)

    @app.get("/privacy/diagnostics", response_model=PrivacyDiagnosticsResponse)
    async def privacy_diagnostics() -> PrivacyDiagnosticsResponse:
        try:
            profile_rule_count = len(store.get_profile().rules)
            model_provider_count = len(provider_store.list_providers())
            model_settings = provider_store.get_settings()
            gateway_settings = provider_store.get_gateway_settings()
        except (ProfileStorageError, ModelProviderStorageError) as exc:
            raise HTTPException(
                status_code=500,
                detail="Local diagnostics could not be collected.",
            ) from exc

        summary = _local_data_summary(worker_settings, store, provider_store)
        return PrivacyDiagnosticsResponse(
            app_data_dir=summary.app_data_dir,
            profile_rule_count=profile_rule_count,
            model_provider_count=model_provider_count,
            llm_review_enabled=model_settings.enable_llm_review,
            external_raw_text_enabled=model_settings.allow_raw_text_for_external_models,
            gateway_enabled=gateway_settings.enabled,
            gateway_bind_host=gateway_settings.bind_host,
            gateway_redacts_requests=gateway_settings.redact_request_messages,
            paths=summary.paths,
            notes=[
                "Diagnostics exclude submitted text, OCR output, PDF text, prompts, profile terms, and API keys.",
                "History is disabled by default.",
            ],
        )

    @app.post("/privacy/clear-local-data", response_model=ClearLocalDataResponse)
    async def clear_local_data(
        request: ClearLocalDataRequest,
    ) -> ClearLocalDataResponse:
        cleared_paths: list[str] = []
        skipped_paths: list[str] = []
        keychain_entries_cleared = 0

        if request.clear_profile:
            try:
                if store.clear_profile():
                    cleared_paths.append(str(store.profile_path))
                else:
                    skipped_paths.append(str(store.profile_path))
            except ProfileStorageError as exc:
                raise HTTPException(
                    status_code=500,
                    detail="Profile data could not be cleared locally.",
                ) from exc

        if request.clear_model_provider_settings:
            try:
                cleared, keychain_entries_cleared = provider_store.clear_config(
                    clear_keychain_api_keys=request.clear_keychain_api_keys,
                )
            except (ModelProviderStorageError, SecretStoreError) as exc:
                raise HTTPException(
                    status_code=500,
                    detail="Model provider data could not be cleared locally.",
                ) from exc
            if cleared:
                cleared_paths.append(str(provider_store.config_path))
            else:
                skipped_paths.append(str(provider_store.config_path))

        return ClearLocalDataResponse(
            cleared_paths=cleared_paths,
            skipped_paths=skipped_paths,
            keychain_entries_cleared=keychain_entries_cleared,
            message="Local data clear completed.",
        )

    @app.get("/profile", response_model=Profile)
    async def get_profile() -> Profile:
        return _load_profile_or_500(store)

    @app.put("/profile", response_model=Profile)
    async def put_profile(profile: Profile) -> Profile:
        try:
            return store.replace_profile(profile)
        except ProfileValidationError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except ProfileStorageError as exc:
            raise HTTPException(
                status_code=500,
                detail="Profile could not be saved locally.",
            ) from exc

    @app.post("/profile/rules", response_model=ProfileRule)
    async def create_profile_rule(payload: ProfileRulePayload) -> ProfileRule:
        try:
            return store.add_rule(payload)
        except ProfileValidationError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except ProfileStorageError as exc:
            raise HTTPException(
                status_code=500,
                detail="Profile could not be saved locally.",
            ) from exc

    @app.post("/profile/learn-from-text", response_model=ProfileLearningResponse)
    async def learn_from_text(request: ProfileLearningRequest) -> ProfileLearningResponse:
        try:
            candidates = pipeline.learn_profile_candidates(
                text=request.text,
                mode=request.mode,
            )
        except ProfileStorageError as exc:
            raise HTTPException(
                status_code=500,
                detail="Profile could not be loaded locally.",
            ) from exc

        return ProfileLearningResponse(candidates=candidates)

    @app.get("/models/providers", response_model=ModelProviderListResponse)
    async def list_model_providers() -> ModelProviderListResponse:
        try:
            return ModelProviderListResponse(providers=provider_store.list_providers())
        except ModelProviderStorageError as exc:
            raise HTTPException(
                status_code=500,
                detail="Model provider configuration could not be loaded locally.",
            ) from exc

    @app.post("/models/providers", response_model=ModelProvider)
    async def create_model_provider(payload: ModelProviderPayload) -> ModelProvider:
        try:
            return provider_store.add_provider(payload)
        except (ModelProviderValidationError, SecretStoreError) as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except ModelProviderStorageError as exc:
            raise HTTPException(
                status_code=500,
                detail="Model provider configuration could not be saved locally.",
            ) from exc

    @app.put("/models/providers/{provider_id}", response_model=ModelProvider)
    async def update_model_provider(
        provider_id: str,
        payload: ModelProviderPayload,
    ) -> ModelProvider:
        try:
            return provider_store.update_provider(provider_id, payload)
        except ModelProviderNotFoundError as exc:
            raise HTTPException(status_code=404, detail="Model provider not found.") from exc
        except (ModelProviderValidationError, SecretStoreError) as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except ModelProviderStorageError as exc:
            raise HTTPException(
                status_code=500,
                detail="Model provider configuration could not be saved locally.",
            ) from exc

    @app.delete("/models/providers/{provider_id}", status_code=204)
    async def delete_model_provider(provider_id: str) -> None:
        try:
            provider_store.delete_provider(provider_id)
        except ModelProviderNotFoundError as exc:
            raise HTTPException(status_code=404, detail="Model provider not found.") from exc
        except (ModelProviderStorageError, SecretStoreError) as exc:
            raise HTTPException(
                status_code=500,
                detail="Model provider configuration could not be saved locally.",
            ) from exc

    @app.post(
        "/models/providers/{provider_id}/test",
        response_model=ModelProviderTestResponse,
    )
    async def test_model_provider(provider_id: str) -> ModelProviderTestResponse:
        try:
            provider = provider_store.get_provider(provider_id, include_api_key=True)
            result = await review_client.test_provider(provider)
        except ModelProviderNotFoundError as exc:
            raise HTTPException(status_code=404, detail="Model provider not found.") from exc
        except (ModelProviderStorageError, SecretStoreError) as exc:
            raise HTTPException(
                status_code=500,
                detail="Model provider configuration could not be loaded locally.",
            ) from exc

        return ModelProviderTestResponse(
            provider_id=provider.id,
            ok=result.ok,
            message=result.message,
        )

    @app.get("/models/settings", response_model=ModelReviewSettings)
    async def get_model_settings() -> ModelReviewSettings:
        try:
            return provider_store.get_settings()
        except ModelProviderStorageError as exc:
            raise HTTPException(
                status_code=500,
                detail="Model provider settings could not be loaded locally.",
            ) from exc

    @app.put("/models/settings", response_model=ModelReviewSettings)
    async def update_model_settings(settings: ModelReviewSettings) -> ModelReviewSettings:
        try:
            return provider_store.update_settings(settings)
        except ModelProviderValidationError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except ModelProviderStorageError as exc:
            raise HTTPException(
                status_code=500,
                detail="Model provider settings could not be saved locally.",
            ) from exc

    @app.get("/gateway/settings", response_model=GatewaySettings)
    async def get_gateway_settings() -> GatewaySettings:
        try:
            return provider_store.get_gateway_settings()
        except ModelProviderStorageError as exc:
            raise HTTPException(
                status_code=500,
                detail="Gateway settings could not be loaded locally.",
            ) from exc

    @app.put("/gateway/settings", response_model=GatewaySettings)
    async def update_gateway_settings(settings: GatewaySettings) -> GatewaySettings:
        try:
            return provider_store.update_gateway_settings(settings)
        except ModelProviderValidationError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except ModelProviderStorageError as exc:
            raise HTTPException(
                status_code=500,
                detail="Gateway settings could not be saved locally.",
            ) from exc

    @app.post("/gateway/preview", response_model=GatewayPreviewResponse)
    async def preview_gateway(request: Request) -> GatewayPreviewResponse:
        try:
            gateway_settings = provider_store.get_gateway_settings()
            payload = await request.json()
            provider = _gateway_provider_or_none(provider_store, gateway_settings)
            if provider is None:
                prepared = prepare_gateway_request(
                    payload,
                    settings=gateway_settings,
                    provider=_preview_provider(gateway_settings, payload),
                    pipeline=pipeline,
                )
                return GatewayPreviewResponse(
                    gateway_enabled=gateway_settings.enabled,
                    endpoint_url=gateway_endpoint_url(gateway_settings),
                    forwarded_request=prepared.forwarded_request,
                    messages=prepared.messages,
                    raw_text_sent=prepared.raw_text_sent,
                    raw_text_blocked=prepared.raw_text_blocked,
                    warning="Choose an upstream provider before enabling the gateway.",
                )

            prepared = prepare_gateway_request(
                payload,
                settings=gateway_settings,
                provider=provider,
                pipeline=pipeline,
            )
        except GatewayRequestError as exc:
            raise HTTPException(status_code=exc.status_code, detail=exc.detail) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail="Request body must be JSON.") from exc
        except ModelProviderStorageError as exc:
            raise HTTPException(
                status_code=500,
                detail="Gateway settings could not be loaded locally.",
            ) from exc
        except (ProfileStorageError, Exception) as exc:
            if isinstance(exc, HTTPException):
                raise
            raise HTTPException(
                status_code=500,
                detail="Gateway redaction failed locally; request was not forwarded.",
            ) from exc

        return GatewayPreviewResponse(
            gateway_enabled=gateway_settings.enabled,
            endpoint_url=gateway_endpoint_url(gateway_settings),
            upstream_provider_id=provider.id,
            upstream_provider_name=provider.name,
            upstream_provider_is_local=provider.is_local,
            raw_text_sent=prepared.raw_text_sent,
            raw_text_blocked=prepared.raw_text_blocked,
            warning=prepared.warning,
            forwarded_request=prepared.forwarded_request,
            messages=prepared.messages,
        )

    @app.get("/v1/models")
    async def gateway_models() -> dict[str, object]:
        try:
            gateway_settings = provider_store.get_gateway_settings()
            if not gateway_settings.enabled:
                raise HTTPException(status_code=403, detail="Gateway is disabled.")
            provider = _gateway_provider(provider_store, gateway_settings)
        except ModelProviderNotFoundError as exc:
            raise HTTPException(status_code=404, detail="Gateway upstream provider not found.") from exc
        except ModelProviderValidationError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except ModelProviderStorageError as exc:
            raise HTTPException(
                status_code=500,
                detail="Gateway settings could not be loaded locally.",
            ) from exc

        return {
            "object": "list",
            "data": [
                {
                    "id": provider.model,
                    "object": "model",
                    "created": 0,
                    "owned_by": "privacy-preflight",
                }
            ],
        }

    @app.post("/v1/chat/completions")
    async def gateway_chat_completions(request: Request) -> dict[str, object]:
        try:
            gateway_settings = provider_store.get_gateway_settings()
            if not gateway_settings.enabled:
                raise HTTPException(status_code=403, detail="Gateway is disabled.")
            provider = _gateway_provider(
                provider_store,
                gateway_settings,
                include_api_key=True,
            )
            payload = await request.json()
            debug_summary = bool(
                isinstance(payload, dict) and payload.get("privacy_preflight_debug")
            )
            prepared = prepare_gateway_request(
                payload,
                settings=gateway_settings,
                provider=provider,
                pipeline=pipeline,
            )
            response = await review_client.chat_completion(
                provider,
                prepared.forwarded_request,
            )
        except HTTPException:
            raise
        except GatewayRequestError as exc:
            raise HTTPException(status_code=exc.status_code, detail=exc.detail) from exc
        except ModelProviderValidationError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail="Request body must be JSON.") from exc
        except ModelProviderNotFoundError as exc:
            raise HTTPException(status_code=404, detail="Gateway upstream provider not found.") from exc
        except (ModelProviderStorageError, SecretStoreError) as exc:
            raise HTTPException(
                status_code=500,
                detail="Gateway provider configuration could not be loaded locally.",
            ) from exc
        except ProfileStorageError as exc:
            raise HTTPException(
                status_code=500,
                detail="Gateway redaction failed locally; request was not forwarded.",
            ) from exc
        except ModelProviderClientError as exc:
            raise HTTPException(
                status_code=502,
                detail="Gateway upstream request failed without exposing provider details.",
            ) from exc
        except Exception as exc:
            raise HTTPException(
                status_code=500,
                detail="Gateway redaction failed locally; request was not forwarded.",
            ) from exc

        if debug_summary:
            response["privacy_preflight"] = {
                "raw_text_sent": prepared.raw_text_sent,
                "raw_text_blocked": prepared.raw_text_blocked,
                "warning": prepared.warning,
                "messages": [
                    message.model_dump(mode="json") for message in prepared.messages
                ],
            }
        return response

    @app.put("/profile/rules/{rule_id}", response_model=ProfileRule)
    async def update_profile_rule(
        rule_id: str,
        payload: ProfileRulePayload,
    ) -> ProfileRule:
        try:
            return store.update_rule(rule_id, payload)
        except ProfileRuleNotFoundError as exc:
            raise HTTPException(status_code=404, detail="Profile rule not found.") from exc
        except ProfileValidationError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except ProfileStorageError as exc:
            raise HTTPException(
                status_code=500,
                detail="Profile could not be saved locally.",
            ) from exc

    @app.delete("/profile/rules/{rule_id}", status_code=204)
    async def delete_profile_rule(rule_id: str) -> None:
        try:
            store.delete_rule(rule_id)
        except ProfileRuleNotFoundError as exc:
            raise HTTPException(status_code=404, detail="Profile rule not found.") from exc
        except ProfileStorageError as exc:
            raise HTTPException(
                status_code=500,
                detail="Profile could not be saved locally.",
            ) from exc

    @app.post("/redact/text", response_model=TextRedactionResponse)
    async def redact_text(request: TextRedactionRequest) -> TextRedactionResponse:
        try:
            result = pipeline.redact(text=request.text, mode=request.mode)
        except ProfileStorageError as exc:
            raise HTTPException(
                status_code=500,
                detail="Profile could not be loaded locally.",
            ) from exc

        return TextRedactionResponse(
            redacted_text=result.redacted_text,
            entities=result.entities,
            summary=result.summary,
        )

    @app.post("/redact/image", response_model=ImageRedactionResponse)
    async def redact_image(
        image: UploadFile = File(...),
        mode: str = Form("safe_text"),
        manual_rectangles: str | None = Form(default=None),
    ) -> ImageRedactionResponse:
        if mode not in {"safe_text", "precise"}:
            raise HTTPException(
                status_code=400,
                detail="Image redaction mode must be safe_text or precise.",
            )

        max_image_bytes = int(getattr(worker_settings, "max_image_bytes", 15 * 1024 * 1024))
        image_bytes = await image.read(max_image_bytes + 1)
        if len(image_bytes) > max_image_bytes:
            raise HTTPException(
                status_code=413,
                detail="Image is larger than the configured local processing limit.",
            )

        try:
            rectangles = _parse_manual_rectangles(manual_rectangles)
            return image_service.redact(
                image_bytes,
                mode=mode,  # type: ignore[arg-type]
                manual_rectangles=rectangles,
            )
        except InvalidImageError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except OCRUnavailableError as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc
        except ProfileStorageError as exc:
            raise HTTPException(
                status_code=500,
                detail="Profile could not be loaded locally.",
            ) from exc
        except ImageRedactionError as exc:
            raise HTTPException(
                status_code=500,
                detail="Image redaction failed locally.",
            ) from exc

    @app.post("/redact/pdf/analyze", response_model=PDFRedactionAnalysisResponse)
    async def analyze_pdf(
        pdf: UploadFile = File(...),
        mode: str = Form("balanced"),
    ) -> PDFRedactionAnalysisResponse:
        if mode not in {"balanced", "strict"}:
            raise HTTPException(
                status_code=400,
                detail="PDF redaction mode must be balanced or strict.",
            )

        pdf_bytes = await _read_limited_pdf(pdf, worker_settings)
        try:
            return pdf_service.analyze(
                pdf_bytes,
                mode=mode,
            )
        except InvalidPDFError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except (PDFDependencyError, PDFOCRUnavailableError) as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc
        except ProfileStorageError as exc:
            raise HTTPException(
                status_code=500,
                detail="Profile could not be loaded locally.",
            ) from exc
        except PDFRedactionError as exc:
            raise HTTPException(
                status_code=500,
                detail="PDF analysis failed locally.",
            ) from exc

    @app.post("/redact/pdf/export", response_model=PDFRedactionExportResponse)
    async def export_pdf(
        pdf: UploadFile = File(...),
        mode: str = Form("balanced"),
        manual_rectangles: str | None = Form(default=None),
    ) -> PDFRedactionExportResponse:
        if mode not in {"balanced", "strict"}:
            raise HTTPException(
                status_code=400,
                detail="PDF redaction mode must be balanced or strict.",
            )

        pdf_bytes = await _read_limited_pdf(pdf, worker_settings)
        try:
            rectangles = _parse_pdf_manual_rectangles(manual_rectangles)
            return pdf_service.export(
                pdf_bytes,
                mode=mode,
                manual_rectangles=rectangles,
            )
        except InvalidPDFError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except (PDFDependencyError, PDFOCRUnavailableError) as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc
        except PDFValidationFailedError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        except ProfileStorageError as exc:
            raise HTTPException(
                status_code=500,
                detail="Profile could not be loaded locally.",
            ) from exc
        except PDFRedactionError as exc:
            raise HTTPException(
                status_code=500,
                detail="PDF redaction failed locally.",
            ) from exc

    @app.post("/redact/text/review", response_model=TextReviewResponse)
    async def redact_text_with_review(request: TextReviewRequest) -> TextReviewResponse:
        try:
            initial = pipeline.redact(text=request.text, mode=request.mode)
            settings = provider_store.get_settings()
            enable_review = (
                request.enable_llm_review
                if request.enable_llm_review is not None
                else settings.enable_llm_review
            )
            provider_id = request.provider_id or settings.selected_review_provider_id
            if not enable_review or not provider_id:
                initial_response = _text_response(initial)
                return TextReviewResponse(
                    initial_result=initial_response,
                    review_result=None,
                    final_result=initial_response,
                )

            provider = provider_store.get_provider(provider_id, include_api_key=True)
            allow_raw_external = (
                request.allow_raw_text_for_external_models
                if request.allow_raw_text_for_external_models is not None
                else settings.allow_raw_text_for_external_models
            )
            profile_rules = store.load_enabled_rules()
            review_result, final = await run_model_review(
                text=request.text,
                mode=request.mode,
                initial_result=initial,
                provider=provider,
                allow_raw_text_for_external_models=allow_raw_external,
                profile_rules=profile_rules,
                pipeline=pipeline,
                client=review_client,
            )
        except ProfileStorageError as exc:
            raise HTTPException(
                status_code=500,
                detail="Profile could not be loaded locally.",
            ) from exc
        except ModelProviderNotFoundError as exc:
            raise HTTPException(status_code=404, detail="Model provider not found.") from exc
        except (ModelProviderStorageError, SecretStoreError) as exc:
            raise HTTPException(
                status_code=500,
                detail="Model provider configuration could not be loaded locally.",
            ) from exc
        except ModelProviderClientError as exc:
            raise HTTPException(
                status_code=502,
                detail="Model provider review failed without exposing provider details.",
            ) from exc

        return TextReviewResponse(
            initial_result=_text_response(initial),
            review_result=review_result,
            final_result=_text_response(final),
        )

    @app.post("/revision/parse", response_model=RevisionParseResponse)
    async def parse_revision(request: RevisionParseRequest) -> RevisionParseResponse:
        try:
            initial = pipeline.redact(text=request.text, mode=request.mode)
            parse_result = await _revision_parse_result(
                request=request,
                initial=initial,
                store=store,
                provider_store=provider_store,
                client=review_client,
            )
        except ProfileStorageError as exc:
            raise HTTPException(
                status_code=500,
                detail="Profile could not be loaded locally.",
            ) from exc
        except ModelProviderNotFoundError as exc:
            raise HTTPException(status_code=404, detail="Model provider not found.") from exc
        except (ModelProviderStorageError, SecretStoreError) as exc:
            raise HTTPException(
                status_code=500,
                detail="Model provider configuration could not be loaded locally.",
            ) from exc
        except ModelProviderClientError as exc:
            raise HTTPException(
                status_code=502,
                detail="Model provider revision parsing failed without exposing provider details.",
            ) from exc

        return RevisionParseResponse(
            initial_result=_text_response(initial),
            parse_result=parse_result,
        )

    @app.post("/redact/text/revise", response_model=TextRevisionResponse)
    async def revise_text(request: TextRevisionRequest) -> TextRevisionResponse:
        try:
            initial = pipeline.redact(text=request.text, mode=request.mode)
            parse_result = (
                RevisionParseResult(
                    parser="deterministic",
                    commands=request.commands,
                )
                if request.commands is not None
                else await _revision_parse_result(
                    request=request,
                    initial=initial,
                    store=store,
                    provider_store=provider_store,
                    client=review_client,
                )
            )
            if not parse_result.parsed:
                final = initial
                applied_commands = []
                profile_rules = []
            else:
                final, applied_commands, profile_rules = apply_revision_commands(
                    text=request.text,
                    mode=request.mode,
                    initial_result=initial,
                    commands=parse_result.commands,
                    pipeline=pipeline,
                    profile_store=store,
                )
        except ProfileValidationError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except ProfileStorageError as exc:
            raise HTTPException(
                status_code=500,
                detail="Profile could not be loaded locally.",
            ) from exc
        except ModelProviderNotFoundError as exc:
            raise HTTPException(status_code=404, detail="Model provider not found.") from exc
        except (ModelProviderStorageError, SecretStoreError) as exc:
            raise HTTPException(
                status_code=500,
                detail="Model provider configuration could not be loaded locally.",
            ) from exc
        except ModelProviderClientError as exc:
            raise HTTPException(
                status_code=502,
                detail="Model provider revision parsing failed without exposing provider details.",
            ) from exc

        return TextRevisionResponse(
            initial_result=_text_response(initial),
            parse_result=parse_result,
            final_result=_text_response(final),
            applied_commands=applied_commands,
            profile_rules=profile_rules,
        )

    return app


def _local_data_summary(
    settings: object,
    store: ProfileStore,
    provider_store: ModelProviderStore,
) -> LocalDataSummaryResponse:
    app_data_dir = _configured_app_data_dir(settings)
    worker_log_dir = app_data_dir / "Logs"
    temp_dir = Path(tempfile.gettempdir())

    paths = [
        _local_data_path("Profile rules", store.profile_path),
        _local_data_path("Model provider settings", provider_store.config_path),
        _local_data_path("Worker lifecycle logs", worker_log_dir),
        _local_data_path("Temporary OCR/PDF files", temp_dir),
    ]

    return LocalDataSummaryResponse(
        app_data_dir=str(app_data_dir),
        profile_path=str(store.profile_path),
        model_provider_path=str(provider_store.config_path),
        worker_log_dir=str(worker_log_dir),
        temp_dir=str(temp_dir),
        history_enabled=False,
        paths=paths,
    )


def _configured_app_data_dir(settings: object) -> Path:
    configured_app_data_dir = getattr(settings, "app_data_dir", None)
    if configured_app_data_dir:
        return Path(configured_app_data_dir).expanduser()
    return default_app_data_dir()


def _local_data_path(label: str, path: Path) -> LocalDataPath:
    return LocalDataPath(
        label=label,
        path=str(path),
        exists=path.exists(),
        contains_raw_content_by_design=False,
    )


def _load_profile_or_500(store: ProfileStore) -> Profile:
    try:
        return store.get_profile()
    except ProfileStorageError as exc:
        raise HTTPException(
            status_code=500,
            detail="Profile could not be loaded locally.",
        ) from exc


def _parse_manual_rectangles(value: str | None) -> list[ImageRectangle]:
    if not value:
        return []
    try:
        payload = json.loads(value)
        return TypeAdapter(list[ImageRectangle]).validate_python(payload)
    except (json.JSONDecodeError, ValidationError) as exc:
        raise HTTPException(
            status_code=400,
            detail="manual_rectangles must be a JSON array of rectangles.",
        ) from exc


def _parse_pdf_manual_rectangles(value: str | None) -> list[PDFManualRectangle]:
    if not value:
        return []
    try:
        payload = json.loads(value)
        return TypeAdapter(list[PDFManualRectangle]).validate_python(payload)
    except (json.JSONDecodeError, ValidationError) as exc:
        raise HTTPException(
            status_code=400,
            detail="manual_rectangles must be a JSON array of page rectangles.",
        ) from exc


async def _read_limited_pdf(pdf: UploadFile, settings: object) -> bytes:
    max_pdf_bytes = int(getattr(settings, "max_pdf_bytes", 50 * 1024 * 1024))
    pdf_bytes = await pdf.read(max_pdf_bytes + 1)
    if len(pdf_bytes) > max_pdf_bytes:
        raise HTTPException(
            status_code=413,
            detail="PDF is larger than the configured local processing limit.",
        )
    return pdf_bytes


def _gateway_provider(
    provider_store: ModelProviderStore,
    settings: GatewaySettings,
    *,
    include_api_key: bool = False,
) -> ModelProvider:
    if not settings.upstream_provider_id:
        raise ModelProviderNotFoundError("gateway upstream provider is not configured")
    provider = provider_store.get_provider(
        settings.upstream_provider_id,
        include_api_key=include_api_key,
    )
    if provider.provider_type == "ollama":
        raise ModelProviderValidationError(
            "Gateway upstream provider must be OpenAI-compatible."
        )
    return provider


def _gateway_provider_or_none(
    provider_store: ModelProviderStore,
    settings: GatewaySettings,
) -> ModelProvider | None:
    if not settings.upstream_provider_id:
        return None
    try:
        provider = provider_store.get_provider(settings.upstream_provider_id)
    except ModelProviderNotFoundError:
        return None
    return provider if provider.provider_type != "ollama" else None


def _preview_provider(settings: GatewaySettings, payload: object) -> ModelProvider:
    model = "configured-upstream-model"
    if isinstance(payload, dict) and isinstance(payload.get("model"), str):
        model = payload["model"]
    return ModelProvider(
        id=settings.upstream_provider_id or "gateway_preview",
        name="Gateway Preview",
        provider_type="openai_compatible",
        base_url="http://127.0.0.1/v1",
        model=model,
        is_local=True,
        supports_json_mode=True,
        timeout=30,
        max_tokens=800,
        api_key_configured=False,
        created_at="1970-01-01T00:00:00Z",
        updated_at="1970-01-01T00:00:00Z",
    )


def _text_response(result: object) -> TextRedactionResponse:
    return TextRedactionResponse(
        redacted_text=result.redacted_text,
        entities=result.entities,
        summary=result.summary,
    )


async def _revision_parse_result(
    *,
    request: RevisionParseRequest,
    initial: object,
    store: ProfileStore,
    provider_store: ModelProviderStore,
    client: ModelProviderClient,
) -> RevisionParseResult:
    settings = provider_store.get_settings()
    enable_model_parsing = (
        request.enable_model_parsing
        if request.enable_model_parsing is not None
        else settings.enable_llm_review
    )
    provider = None
    if enable_model_parsing:
        provider_id = request.provider_id or settings.selected_review_provider_id
        if provider_id is None:
            provider_id = _first_local_provider_id(provider_store)
        if provider_id is not None:
            provider = provider_store.get_provider(provider_id, include_api_key=True)

    allow_raw_external = (
        request.allow_raw_text_for_external_models
        if request.allow_raw_text_for_external_models is not None
        else settings.allow_raw_text_for_external_models
    )

    return await build_revision_parse_result(
        text=request.text,
        instruction=request.instruction,
        requested_scope=request.scope,
        selected_entity_id=request.selected_entity_id,
        initial_result=initial,
        profile_rules=store.load_enabled_rules(),
        provider=provider,
        allow_raw_text_for_external_models=allow_raw_external,
        client=client,
    )


def _first_local_provider_id(provider_store: ModelProviderStore) -> str | None:
    for provider in provider_store.list_providers():
        if provider.is_local:
            return provider.id
    return None


app = create_app()
