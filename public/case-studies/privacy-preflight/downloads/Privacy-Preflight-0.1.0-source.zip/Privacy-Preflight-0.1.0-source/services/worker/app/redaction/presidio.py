from __future__ import annotations

from collections.abc import Sequence
import os
from pathlib import Path
import tempfile
from typing import Any
from importlib import import_module

from .detectors import DetectionCandidate, RedactionMode


class PresidioUnavailableError(RuntimeError):
    """Raised when Presidio is enabled but cannot be loaded locally."""


class PresidioDetector:
    name = "presidio"

    _TYPE_ALIASES = {
        "EMAIL_ADDRESS": "EMAIL",
        "PHONE_NUMBER": "PHONE",
        "IP_ADDRESS": "IP_ADDRESS",
        "URL": "URL",
    }

    def __init__(
        self,
        *,
        analyzer: Any | None = None,
        language: str = "en",
        entities: Sequence[str] | None = None,
        recognizers: Sequence[Any] | None = None,
        score_threshold: float = 0.35,
    ) -> None:
        self._analyzer = analyzer
        self.language = language
        self.entities = list(entities) if entities else None
        self.recognizers = list(recognizers) if recognizers else []
        self.score_threshold = score_threshold

    def detect(self, text: str, mode: RedactionMode) -> list[DetectionCandidate]:
        analyzer = self._get_analyzer()
        results = analyzer.analyze(
            text=text,
            language=self.language,
            entities=self.entities,
            score_threshold=self.score_threshold,
        )
        return [
            candidate
            for result in results
            if (candidate := self._map_result(result))
        ]

    def _get_analyzer(self) -> Any:
        if self._analyzer is not None:
            return self._analyzer

        try:
            from presidio_analyzer import AnalyzerEngine
        except ImportError as exc:
            raise PresidioUnavailableError(
                "Presidio is enabled but presidio-analyzer is not installed. "
                'Install the worker with the "presidio" extra.'
            ) from exc

        try:
            self._configure_tldextract()
            analyzer = AnalyzerEngine()
            for recognizer in self.recognizers:
                analyzer.registry.add_recognizer(recognizer)
        except Exception as exc:  # pragma: no cover - depends on optional local models.
            raise PresidioUnavailableError(
                "Presidio is enabled but the analyzer could not start. "
                "Check that the required local NLP model is installed."
            ) from exc

        self._analyzer = analyzer
        return analyzer

    def _configure_tldextract(self) -> None:
        cache_dir = Path(tempfile.gettempdir()) / "privacy-preflight-tldextract"
        os.environ.setdefault("TLDEXTRACT_CACHE", str(cache_dir))
        try:
            tldextract = import_module("tldextract")
            tldextract_module = import_module("tldextract.tldextract")
        except ImportError:
            return

        extractor = tldextract.TLDExtract(
            suffix_list_urls=(),
            cache_dir=os.environ["TLDEXTRACT_CACHE"],
        )
        tldextract_module.TLD_EXTRACTOR = extractor

    def _map_result(self, result: Any) -> DetectionCandidate | None:
        entity_type = getattr(result, "entity_type", None)
        start = getattr(result, "start", None)
        end = getattr(result, "end", None)
        score = getattr(result, "score", 0.0)
        if entity_type is None or start is None or end is None:
            return None

        try:
            start_int = int(start)
            end_int = int(end)
            confidence = min(1.0, max(0.0, float(score)))
        except (TypeError, ValueError):
            return None

        if end_int <= start_int:
            return None

        source_type = str(entity_type)
        mapped_type = self._TYPE_ALIASES.get(source_type, source_type)
        return DetectionCandidate(
            type=mapped_type,
            start=start_int,
            end=end_int,
            confidence=confidence,
            source="presidio",
            reason=self._reason(source_type, mapped_type, result),
        )

    def _reason(self, source_type: str, mapped_type: str, result: Any) -> str:
        recognizer_name = self._recognizer_name(result)
        type_note = (
            f"Presidio analyzer detected {source_type}."
            if source_type == mapped_type
            else f"Presidio analyzer detected {source_type}, mapped to {mapped_type}."
        )
        if recognizer_name:
            return f"{type_note} Recognizer: {recognizer_name}."
        return type_note

    def _recognizer_name(self, result: Any) -> str | None:
        metadata = getattr(result, "recognition_metadata", None)
        if not isinstance(metadata, dict):
            return None
        recognizer_name = metadata.get("recognizer_name")
        if recognizer_name:
            return str(recognizer_name)
        return None
