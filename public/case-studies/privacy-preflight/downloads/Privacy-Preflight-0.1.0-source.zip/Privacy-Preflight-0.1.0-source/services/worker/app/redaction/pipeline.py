from __future__ import annotations

from collections import Counter
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from typing import Any

from app.schemas import ProfileLearningCandidate, ProfileRule, RedactionEntity

from .chinese import build_chinese_detectors
from .detectors import DetectionCandidate, Detector, DeterministicRegexDetector
from .presidio import PresidioDetector
from .privacy_filter import PrivacyFilterDetector
from .profile import ProfileRuleDetector


@dataclass(frozen=True)
class RedactionResult:
    redacted_text: str
    entities: list[RedactionEntity]
    summary: dict[str, int]


class TextRedactionPipeline:
    _REPLACEMENTS = {
        "EMAIL": "[EMAIL]",
        "PHONE": "[PHONE]",
        "URL": "[URL]",
        "IP_ADDRESS": "[IP_ADDRESS]",
        "LOCAL_PATH": "[LOCAL_PATH]",
        "API_KEY": "[API_KEY]",
        "ID": "[ID]",
        "PERSON": "[PERSON]",
        "SCHOOL": "[SCHOOL]",
        "COMPANY": "[COMPANY]",
        "ORGANIZATION": "[ORGANIZATION]",
        "LOCATION": "[LOCATION]",
        "ADDRESS": "[ADDRESS]",
        "DATE": "[DATE]",
        "CUSTOM": "[CUSTOM]",
    }
    _TYPE_PRIORITY = {
        "API_KEY": 90,
        "LOCAL_PATH": 80,
        "ADDRESS": 75,
        "DATE": 65,
        "URL": 70,
        "SCHOOL": 65,
        "COMPANY": 65,
        "ORGANIZATION": 65,
        "PERSON": 65,
        "LOCATION": 65,
        "EMAIL": 60,
        "PHONE": 50,
        "IP_ADDRESS": 50,
        "CUSTOM": 20,
        "ID": 10,
    }

    def __init__(
        self,
        detectors: list[Detector] | None = None,
        *,
        enable_presidio: bool = False,
        presidio_detector: Detector | None = None,
        presidio_language: str = "en",
        presidio_score_threshold: float = 0.35,
        enable_privacy_filter: bool = False,
        privacy_filter_detector: Detector | None = None,
        privacy_filter_model_path: str | None = None,
        privacy_filter_model_id: str | None = None,
        privacy_filter_runtime: str = "opf",
        privacy_filter_device: str = "cpu",
        enable_chinese_ner: bool = True,
        chinese_detectors: list[Detector] | None = None,
        chinese_ner_provider: str = "dictionary_only",
        chinese_ner_model_path: str | None = None,
        dictionary_path: str | None = None,
        profile_rules: Iterable[ProfileRule] | None = None,
        profile_rules_loader: Callable[[], Iterable[ProfileRule]] | None = None,
    ) -> None:
        if detectors is not None:
            self.detectors = detectors
            return

        self.detectors: list[Detector] = [DeterministicRegexDetector()]
        if enable_chinese_ner:
            self.detectors.extend(
                chinese_detectors
                if chinese_detectors is not None
                else build_chinese_detectors(
                    provider=chinese_ner_provider,
                    model_path=chinese_ner_model_path,
                    dictionary_path=dictionary_path,
                )
            )
        if enable_privacy_filter:
            self.detectors.append(
                privacy_filter_detector
                or PrivacyFilterDetector(
                    model_path=privacy_filter_model_path,
                    model_id=privacy_filter_model_id,
                    runtime=privacy_filter_runtime,
                    device=privacy_filter_device,
                )
            )
        if profile_rules is not None or profile_rules_loader is not None:
            self.detectors.append(
                ProfileRuleDetector(
                    rules=profile_rules,
                    rules_loader=profile_rules_loader,
                )
            )
        if enable_presidio:
            self.detectors.append(
                presidio_detector
                or PresidioDetector(
                    language=presidio_language,
                    score_threshold=presidio_score_threshold,
                )
            )

    @classmethod
    def from_settings(
        cls,
        settings: Any,
        *,
        presidio_detector: Detector | None = None,
        privacy_filter_detector: Detector | None = None,
        chinese_detectors: list[Detector] | None = None,
        profile_rules: Iterable[ProfileRule] | None = None,
        profile_rules_loader: Callable[[], Iterable[ProfileRule]] | None = None,
    ) -> "TextRedactionPipeline":
        return cls(
            enable_presidio=bool(getattr(settings, "enable_presidio", False)),
            presidio_detector=presidio_detector,
            presidio_language=str(getattr(settings, "presidio_language", "en")),
            presidio_score_threshold=float(
                getattr(settings, "presidio_score_threshold", 0.35)
            ),
            enable_privacy_filter=bool(
                getattr(settings, "enable_privacy_filter", False)
            ),
            privacy_filter_detector=privacy_filter_detector,
            privacy_filter_model_path=getattr(
                settings, "privacy_filter_model_path", None
            ),
            privacy_filter_model_id=getattr(settings, "privacy_filter_model_id", None),
            privacy_filter_runtime=str(
                getattr(settings, "privacy_filter_runtime", "opf")
            ),
            privacy_filter_device=str(getattr(settings, "privacy_filter_device", "cpu")),
            enable_chinese_ner=bool(getattr(settings, "enable_chinese_ner", True)),
            chinese_detectors=chinese_detectors,
            chinese_ner_provider=str(
                getattr(settings, "chinese_ner_provider", "dictionary_only")
            ),
            chinese_ner_model_path=getattr(settings, "chinese_ner_model_path", None),
            dictionary_path=getattr(settings, "dictionary_path", None),
            profile_rules=profile_rules,
            profile_rules_loader=profile_rules_loader,
        )

    def redact(
        self,
        text: str,
        mode: str = "balanced",
        *,
        extra_candidates: Iterable[DetectionCandidate] | None = None,
    ) -> RedactionResult:
        candidates: list[DetectionCandidate] = []
        for detector in self.detectors:
            candidates.extend(detector.detect(text, mode))
        if extra_candidates is not None:
            candidates.extend(extra_candidates)

        selected_candidates = self._resolve_conflicts(candidates)
        entities = self._build_entities(text, selected_candidates)
        redacted_text = self._apply_replacements(text, entities)
        summary = dict(sorted(Counter(entity.type for entity in entities).items()))
        return RedactionResult(
            redacted_text=redacted_text,
            entities=entities,
            summary=summary,
        )

    def learn_profile_candidates(
        self,
        text: str,
        mode: str = "balanced",
    ) -> list[ProfileLearningCandidate]:
        candidates: list[DetectionCandidate] = []
        for detector in self.detectors:
            candidates.extend(detector.detect(text, mode))

        selected_candidates = self._resolve_conflicts(candidates)
        return self._build_learning_candidates(text, selected_candidates)

    def _resolve_conflicts(
        self, candidates: list[DetectionCandidate]
    ) -> list[DetectionCandidate]:
        valid_candidates = [
            candidate
            for candidate in candidates
            if candidate.start >= 0 and candidate.end > candidate.start
        ]
        allowlist_candidates = [
            candidate
            for candidate in valid_candidates
            if self._is_allowlist_candidate(candidate)
        ]
        redaction_candidates = [
            candidate
            for candidate in valid_candidates
            if not self._is_allowlist_candidate(candidate)
        ]
        if allowlist_candidates:
            redaction_candidates = [
                candidate
                for candidate in redaction_candidates
                if not any(
                    self._overlaps(candidate, allowlist_candidate)
                    and self._allowlist_suppresses(allowlist_candidate, candidate)
                    for allowlist_candidate in allowlist_candidates
                )
            ]

        sorted_candidates = sorted(
            redaction_candidates,
            key=lambda candidate: (candidate.start, candidate.end, candidate.type),
        )

        selected: list[DetectionCandidate] = []
        for candidate in sorted_candidates:
            if not selected or not self._overlaps(selected[-1], candidate):
                selected.append(candidate)
                continue

            selected[-1] = self._prefer_candidate(selected[-1], candidate)

        return selected

    def _build_entities(
        self, text: str, candidates: list[DetectionCandidate]
    ) -> list[RedactionEntity]:
        entities: list[RedactionEntity] = []
        for index, candidate in enumerate(candidates, start=1):
            replacement = candidate.replacement or self._REPLACEMENTS.get(
                candidate.type, f"[{candidate.type}]"
            )
            entities.append(
                RedactionEntity(
                    id=f"ent_{index:04d}",
                    text=text[candidate.start : candidate.end],
                    type=candidate.type,
                    start=candidate.start,
                    end=candidate.end,
                    confidence=candidate.confidence,
                    source=candidate.source,
                    action=candidate.action,
                    replacement=replacement,
                    reason=candidate.reason,
                    profile_rule_id=candidate.profile_rule_id,
                )
            )
        return entities

    def _build_learning_candidates(
        self,
        text: str,
        candidates: list[DetectionCandidate],
    ) -> list[ProfileLearningCandidate]:
        suggestions: list[ProfileLearningCandidate] = []
        seen: set[tuple[str, str, str]] = set()

        for candidate in candidates:
            if candidate.source == "profile":
                continue

            pattern = text[candidate.start : candidate.end].strip()
            if not pattern:
                continue

            suggested_action = self._suggested_profile_action(candidate)
            dedupe_key = (
                candidate.type,
                pattern.casefold(),
                suggested_action,
            )
            if dedupe_key in seen:
                continue
            seen.add(dedupe_key)

            replacement = candidate.replacement or self._REPLACEMENTS.get(
                candidate.type, f"[{candidate.type}]"
            )
            suggestions.append(
                ProfileLearningCandidate(
                    id=f"cand_{len(suggestions) + 1:04d}",
                    suggested_entity_type=candidate.type,
                    pattern=pattern,
                    aliases=[],
                    replacement=replacement,
                    suggested_action=suggested_action,
                    source_detector=candidate.source,
                    confidence=candidate.confidence,
                    reason=candidate.reason,
                )
            )

        return suggestions

    def _suggested_profile_action(self, candidate: DetectionCandidate) -> str:
        if candidate.action in {"mask", "ask", "allow"}:
            return candidate.action
        return "mask"

    def _apply_replacements(self, text: str, entities: list[RedactionEntity]) -> str:
        redacted_text = text
        for entity in reversed(entities):
            if entity.action == "allow":
                continue
            redacted_text = (
                redacted_text[: entity.start]
                + entity.replacement
                + redacted_text[entity.end :]
            )
        return redacted_text

    def _prefer_candidate(
        self, current: DetectionCandidate, incoming: DetectionCandidate
    ) -> DetectionCandidate:
        if self._is_regex_api_key(current):
            return current
        if self._is_regex_api_key(incoming):
            return incoming

        if self._is_revision_candidate(current) and not self._is_revision_candidate(
            incoming
        ):
            return current
        if self._is_revision_candidate(incoming) and not self._is_revision_candidate(
            current
        ):
            return incoming

        if self._is_profile_candidate(current) and not self._is_profile_candidate(
            incoming
        ):
            return current
        if self._is_profile_candidate(incoming) and not self._is_profile_candidate(
            current
        ):
            return incoming

        if self._contains(current, incoming) and current.length != incoming.length:
            return current
        if self._contains(incoming, current) and current.length != incoming.length:
            return incoming

        current_rank = self._candidate_rank(current)
        incoming_rank = self._candidate_rank(incoming)
        if incoming_rank > current_rank:
            return incoming
        return current

    def _candidate_rank(self, candidate: DetectionCandidate) -> tuple[float, int, int]:
        return (
            candidate.confidence,
            candidate.length,
            self._TYPE_PRIORITY.get(candidate.type, 0),
        )

    def _is_regex_api_key(self, candidate: DetectionCandidate) -> bool:
        return candidate.type == "API_KEY" and candidate.source.startswith("regex:")

    def _is_allowlist_candidate(self, candidate: DetectionCandidate) -> bool:
        return (
            candidate.action == "allow"
            or candidate.type == "ALLOW"
            or candidate.source.startswith("allowlist")
        )

    def _allowlist_suppresses(
        self, _allowlist_candidate: DetectionCandidate, candidate: DetectionCandidate
    ) -> bool:
        if self._is_regex_api_key(candidate):
            return False
        return True

    def _is_profile_candidate(self, candidate: DetectionCandidate) -> bool:
        return candidate.source == "profile"

    def _is_revision_candidate(self, candidate: DetectionCandidate) -> bool:
        return candidate.source == "revision"

    def _overlaps(
        self, left: DetectionCandidate, right: DetectionCandidate
    ) -> bool:
        return left.start < right.end and right.start < left.end

    def _contains(
        self, left: DetectionCandidate, right: DetectionCandidate
    ) -> bool:
        return left.start <= right.start and left.end >= right.end
