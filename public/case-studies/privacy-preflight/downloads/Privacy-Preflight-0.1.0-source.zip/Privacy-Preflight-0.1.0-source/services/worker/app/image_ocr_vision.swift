import AppKit
import Foundation
import Vision

struct OCRBox: Encodable {
    let text: String
    let x: Double
    let y: Double
    let width: Double
    let height: Double
    let confidence: Double
}

struct OCRPayload: Encodable {
    let boxes: [OCRBox]
}

func fail(_ message: String) -> Never {
    FileHandle.standardError.write(Data(message.utf8))
    exit(1)
}

guard CommandLine.arguments.count == 2 else {
    fail("missing image path")
}

let imagePath = CommandLine.arguments[1]
guard let image = NSImage(contentsOfFile: imagePath) else {
    fail("image could not be loaded")
}

var proposedRect = CGRect(origin: .zero, size: image.size)
guard let cgImage = image.cgImage(forProposedRect: &proposedRect, context: nil, hints: nil) else {
    fail("image could not be converted")
}

let request = VNRecognizeTextRequest()
request.recognitionLevel = .accurate
request.usesLanguageCorrection = true
request.recognitionLanguages = ["zh-Hans", "en-US"]

let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
do {
    try handler.perform([request])
} catch {
    fail("vision request failed: \(error.localizedDescription)")
}

let imageWidth = Double(cgImage.width)
let imageHeight = Double(cgImage.height)
let observations = request.results ?? []
let boxes = observations.compactMap { observation -> OCRBox? in
    guard let candidate = observation.topCandidates(1).first else {
        return nil
    }

    let text = candidate.string.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !text.isEmpty else {
        return nil
    }

    let bounds = observation.boundingBox
    return OCRBox(
        text: text,
        x: bounds.minX * imageWidth,
        y: (1.0 - bounds.maxY) * imageHeight,
        width: bounds.width * imageWidth,
        height: bounds.height * imageHeight,
        confidence: Double(candidate.confidence)
    )
}

let encoder = JSONEncoder()
guard let output = try? encoder.encode(OCRPayload(boxes: boxes)) else {
    fail("json encoding failed")
}

FileHandle.standardOutput.write(output)
