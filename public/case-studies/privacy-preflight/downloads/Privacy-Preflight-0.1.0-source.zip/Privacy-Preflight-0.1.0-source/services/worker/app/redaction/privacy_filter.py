from __future__ import annotations

from importlib import import_module
from pathlib import Path
from typing import Any

from .detectors import DetectionCandidate, RedactionMode


class PrivacyFilterUnavailableError(RuntimeError):
    """Raised when OpenAI Privacy Filter is enabled but unavailable locally."""


class PrivacyFilterDetector:
    name = "privacy_filter"

    _TYPE_ALIASES = {
        "private_person": "PERSON",
        "private_email": "EMAIL",
        "private_phone": "PHONE",
        "private_url": "URL",
        "private_address": "ADDRESS",
        "private_date": "DATE",
        "account_number": "ID",
        "secret": "API_KEY",
    }
    _REPLACEMENTS = {
        "PERSON": "[PERSON]",
        "EMAIL": "[EMAIL]",
        "PHONE": "[PHONE]",
        "URL": "[URL]",
        "ADDRESS": "[ADDRESS]",
        "DATE": "[DATE]",
        "ID": "[ID]",
        "API_KEY": "[API_KEY]",
    }

    def __init__(
        self,
        *,
        redactor: Any | None = None,
        model_path: str | None = None,
        model_id: str | None = None,
        runtime: str = "opf",
        device: str = "cpu",
    ) -> None:
        self._redactor = redactor
        self.model_path = model_path
        self.model_id = model_id
        self.runtime = runtime
        self.device = device

    def detect(self, text: str, mode: RedactionMode) -> list[DetectionCandidate]:
        redactor = self._get_redactor()
        try:
            result = redactor.redact(text)
        except Exception as exc:  # pragma: no cover - depends on optional runtime.
            raise PrivacyFilterUnavailableError(
                "OpenAI Privacy Filter inference failed locally. "
                "Check the configured checkpoint and runtime."
            ) from exc

        warning = self._result_field(result, "warning")
        spans = self._result_field(result, "detected_spans") or []
        candidates: list[DetectionCandidate] = []
        for span in spans:
            candidate = self._map_span(text, span, warning=warning)
            if candidate is not None:
                candidates.append(candidate)
        return candidates

    def _get_redactor(self) -> Any:
        if self._redactor is not None:
            return self._redactor

        if self.runtime != "opf":
            raise PrivacyFilterUnavailableError(
                f"Unsupported Privacy Filter runtime: {self.runtime}."
            )

        try:
            opf = import_module("opf")
            redactor_cls = getattr(opf, "OPF")
        except (ImportError, AttributeError) as exc:
            raise PrivacyFilterUnavailableError(
                "OpenAI Privacy Filter is enabled but the optional opf package is "
                "not installed. Install the official openai/privacy-filter package "
                "and configure a local checkpoint path."
            ) from exc

        model_reference = self.model_path or self.model_id
        try:
            self._redactor = redactor_cls(
                model=(
                    str(Path(model_reference).expanduser())
                    if model_reference
                    else None
                ),
                device=self.device,
                output_mode="typed",
            )
        except Exception as exc:  # pragma: no cover - depends on optional runtime.
            raise PrivacyFilterUnavailableError(
                "OpenAI Privacy Filter could not be initialized locally. "
                "Check the optional dependency and checkpoint path."
            ) from exc
        return self._redactor

    def _map_span(
        self,
        text: str,
        span: Any,
        *,
        warning: str | None,
    ) -> DetectionCandidate | None:
        label = str(self._span_field(span, "label") or "")
        mapped_type = self._TYPE_ALIASES.get(label)
        if mapped_type is None:
            return None

        start = self._span_field(span, "start")
        end = self._span_field(span, "end")
        span_text = self._span_field(span, "text")
        try:
            start_int = int(start)
            end_int = int(end)
        except (TypeError, ValueError):
            return None
        if end_int <= start_int:
            return None

        span_text_str = str(span_text) if span_text is not None else ""
        normalized_span = self._normalize_offsets(
            text,
            start=start_int,
            end=end_int,
            span_text=span_text_str,
        )
        if normalized_span is None:
            return None
        start_int, end_int = normalized_span

        confidence = self._confidence(span)
        reason = f"OpenAI Privacy Filter detected {label}, mapped to {mapped_type}."
        if warning:
            reason = f"{reason} Offset warning: tokenizer decode mismatch."

        return DetectionCandidate(
            type=mapped_type,
            start=start_int,
            end=end_int,
            confidence=confidence,
            source="privacy_filter",
            reason=reason,
            replacement=self._REPLACEMENTS.get(mapped_type, f"[{mapped_type}]"),
        )

    def _normalize_offsets(
        self,
        text: str,
        *,
        start: int,
        end: int,
        span_text: str,
    ) -> tuple[int, int] | None:
        if 0 <= start < end <= len(text) and (
            not span_text or text[start:end] == span_text
        ):
            return start, end

        if not span_text:
            return None
        first = text.find(span_text)
        if first < 0:
            return None
        second = text.find(span_text, first + len(span_text))
        if second >= 0:
            return None
        return first, first + len(span_text)

    def _confidence(self, span: Any) -> float:
        for field in ("confidence", "score", "probability"):
            value = self._span_field(span, field)
            if value is None:
                continue
            try:
                return min(1.0, max(0.0, float(value)))
            except (TypeError, ValueError):
                continue
        return 0.78

    def _result_field(self, result: Any, field: str) -> Any:
        if isinstance(result, dict):
            return result.get(field)
        return getattr(result, field, None)

    def _span_field(self, span: Any, field: str) -> Any:
        if isinstance(span, dict):
            return span.get(field)
        return getattr(span, field, None)
