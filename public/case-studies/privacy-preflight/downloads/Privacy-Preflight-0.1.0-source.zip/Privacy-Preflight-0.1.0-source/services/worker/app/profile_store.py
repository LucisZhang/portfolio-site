from __future__ import annotations

import json
import re
from datetime import UTC, datetime
from pathlib import Path
from uuid import uuid4

from .schemas import Profile, ProfileRule, ProfileRulePayload


class ProfileStorageError(RuntimeError):
    """Raised when the local profile cannot be loaded or saved."""


class ProfileValidationError(ValueError):
    """Raised when a profile update is invalid."""


class ProfileRuleNotFoundError(KeyError):
    """Raised when a requested profile rule does not exist."""


class ProfileStore:
    def __init__(self, profile_path: str | Path) -> None:
        self.profile_path = Path(profile_path).expanduser()

    @classmethod
    def from_settings(cls, settings: object) -> "ProfileStore":
        configured_profile_path = getattr(settings, "profile_path", None)
        if configured_profile_path:
            return cls(configured_profile_path)

        configured_app_data_dir = getattr(settings, "app_data_dir", None)
        app_data_dir = (
            Path(configured_app_data_dir).expanduser()
            if configured_app_data_dir
            else default_app_data_dir()
        )
        return cls(app_data_dir / "profile.json")

    def get_profile(self) -> Profile:
        if not self.profile_path.exists():
            return Profile()

        try:
            raw_json = self.profile_path.read_text(encoding="utf-8")
            profile = Profile.model_validate_json(raw_json)
        except OSError as exc:
            raise ProfileStorageError("Profile file could not be read.") from exc
        except ValueError as exc:
            raise ProfileStorageError("Profile file is not valid profile JSON.") from exc

        try:
            self._validate_unique_rule_ids(profile)
        except ProfileValidationError as exc:
            raise ProfileStorageError("Profile file is not valid profile JSON.") from exc
        return profile

    def replace_profile(self, profile: Profile) -> Profile:
        self._validate_unique_rule_ids(profile)
        self._save(profile)
        return profile

    def add_rule(self, payload: ProfileRulePayload) -> ProfileRule:
        profile = self.get_profile()
        existing_ids = {rule.id for rule in profile.rules}
        rule = self._build_rule(payload, existing_ids=existing_ids)
        profile.rules.append(rule)
        self._save(profile)
        return rule

    def update_rule(self, rule_id: str, payload: ProfileRulePayload) -> ProfileRule:
        profile = self.get_profile()
        existing_ids = {rule.id for rule in profile.rules if rule.id != rule_id}

        for index, existing_rule in enumerate(profile.rules):
            if existing_rule.id != rule_id:
                continue

            rule = self._build_rule(
                payload,
                rule_id=existing_rule.id,
                created_at=existing_rule.created_at,
                existing_ids=existing_ids,
            )
            profile.rules[index] = rule
            self._save(profile)
            return rule

        raise ProfileRuleNotFoundError(rule_id)

    def delete_rule(self, rule_id: str) -> None:
        profile = self.get_profile()
        next_rules = [rule for rule in profile.rules if rule.id != rule_id]
        if len(next_rules) == len(profile.rules):
            raise ProfileRuleNotFoundError(rule_id)

        profile.rules = next_rules
        self._save(profile)

    def clear_profile(self) -> bool:
        try:
            if self.profile_path.exists():
                self.profile_path.unlink()
                return True
            return False
        except OSError as exc:
            raise ProfileStorageError("Profile file could not be cleared.") from exc

    def load_enabled_rules(self) -> list[ProfileRule]:
        return [rule for rule in self.get_profile().rules if rule.enabled]

    def _build_rule(
        self,
        payload: ProfileRulePayload,
        *,
        existing_ids: set[str],
        rule_id: str | None = None,
        created_at: str | None = None,
    ) -> ProfileRule:
        entity_type = payload.entity_type.strip().upper()
        if not re.match(r"^[A-Z][A-Z0-9_]{1,63}$", entity_type):
            raise ProfileValidationError(
                "Profile rule entity_type must be an uppercase-style identifier."
            )

        timestamp = _utc_timestamp()
        final_rule_id = rule_id or self._new_rule_id(payload.label, existing_ids)
        replacement = payload.replacement or f"[{entity_type}]"

        return ProfileRule(
            id=final_rule_id,
            label=payload.label,
            entity_type=entity_type,
            patterns=payload.patterns,
            aliases=payload.aliases,
            replacement=replacement,
            action=payload.action,
            enabled=payload.enabled,
            scope=payload.scope,
            created_at=created_at or timestamp,
            updated_at=timestamp,
        )

    def _new_rule_id(self, label: str, existing_ids: set[str]) -> str:
        slug = re.sub(r"[^a-z0-9]+", "_", label.casefold()).strip("_")[:40]
        if not slug:
            slug = "rule"

        for _ in range(10):
            candidate = f"profile_{slug}_{uuid4().hex[:8]}"
            if candidate not in existing_ids:
                return candidate

        raise ProfileValidationError("Could not allocate a unique profile rule id.")

    def _save(self, profile: Profile) -> None:
        data = profile.model_dump(mode="json")
        try:
            self.profile_path.parent.mkdir(parents=True, exist_ok=True)
            temp_path = self.profile_path.with_name(f"{self.profile_path.name}.tmp")
            temp_path.write_text(
                json.dumps(data, ensure_ascii=False, indent=2) + "\n",
                encoding="utf-8",
            )
            temp_path.replace(self.profile_path)
        except OSError as exc:
            raise ProfileStorageError("Profile file could not be saved.") from exc

    def _validate_unique_rule_ids(self, profile: Profile) -> None:
        seen: set[str] = set()
        for rule in profile.rules:
            if rule.id in seen:
                raise ProfileValidationError("Profile rule ids must be unique.")
            seen.add(rule.id)


def default_app_data_dir() -> Path:
    return Path.home() / "Library" / "Application Support" / "Privacy Preflight"


def _utc_timestamp() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")
