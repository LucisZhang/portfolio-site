from __future__ import annotations

from fastapi.testclient import TestClient

from app.config import WorkerSettings
from app.main import create_app
from app.profile_store import ProfileStore
from app.redaction import TextRedactionPipeline
from app.schemas import ProfileRulePayload


def test_profile_rule_create_update_delete(tmp_path) -> None:
    client = _client(tmp_path)

    created_response = client.post(
        "/profile/rules",
        json={
            "label": "Client Project",
            "entity_type": "CUSTOM",
            "patterns": ["Project Phoenix"],
            "replacement": "[PROJECT]",
            "action": "mask",
            "enabled": True,
            "scope": "global",
        },
    )

    assert created_response.status_code == 200
    created_rule = created_response.json()
    rule_id = created_rule["id"]
    assert created_rule["replacement"] == "[PROJECT]"
    assert created_rule["created_at"]
    assert created_rule["updated_at"]

    updated_response = client.put(
        f"/profile/rules/{rule_id}",
        json={
            "label": "Client Project Updated",
            "entity_type": "CUSTOM",
            "patterns": ["Project Phoenix"],
            "aliases": ["Phoenix"],
            "replacement": "[CLIENT_PROJECT]",
            "action": "ask",
            "enabled": False,
            "scope": "text",
        },
    )

    assert updated_response.status_code == 200
    updated_rule = updated_response.json()
    assert updated_rule["id"] == rule_id
    assert updated_rule["label"] == "Client Project Updated"
    assert updated_rule["aliases"] == ["Phoenix"]
    assert updated_rule["replacement"] == "[CLIENT_PROJECT]"
    assert updated_rule["action"] == "ask"
    assert updated_rule["enabled"] is False
    assert updated_rule["scope"] == "text"
    assert updated_rule["created_at"] == created_rule["created_at"]

    delete_response = client.delete(f"/profile/rules/{rule_id}")
    assert delete_response.status_code == 204

    profile_response = client.get("/profile")
    assert profile_response.status_code == 200
    assert profile_response.json() == {"version": 1, "rules": []}


def test_profile_persistence(tmp_path) -> None:
    profile_path = tmp_path / "profile.json"
    store = ProfileStore(profile_path)
    created_rule = store.add_rule(
        ProfileRulePayload(
            label="Tsinghua",
            entity_type="SCHOOL",
            patterns=["清华大学"],
            replacement="[SCHOOL]",
            action="mask",
        )
    )

    reloaded = ProfileStore(profile_path).get_profile()

    assert reloaded.rules[0].id == created_rule.id
    assert reloaded.rules[0].label == "Tsinghua"
    assert reloaded.rules[0].patterns == ["清华大学"]


def test_profile_mask_rule_applies(tmp_path) -> None:
    store = _store_with_rules(
        tmp_path,
        [
            ProfileRulePayload(
                label="Client Project",
                entity_type="CUSTOM",
                patterns=["Project Phoenix"],
                replacement="[PROJECT]",
                action="mask",
            )
        ],
    )
    result = _pipeline(store).redact("Ship Project Phoenix notes.")

    assert result.redacted_text == "Ship [PROJECT] notes."
    assert result.summary == {"CUSTOM": 1}
    assert result.entities[0].source == "profile"
    assert result.entities[0].action == "mask"
    assert result.entities[0].profile_rule_id == store.get_profile().rules[0].id


def test_profile_allow_rule_suppresses_normal_match(tmp_path) -> None:
    store = _store_with_rules(
        tmp_path,
        [
            ProfileRulePayload(
                label="Public Support Email",
                entity_type="EMAIL",
                patterns=["support@example.com"],
                action="allow",
            )
        ],
    )
    result = _pipeline(store).redact("Contact support@example.com.")

    assert result.redacted_text == "Contact support@example.com."
    assert result.entities == []
    assert result.summary == {}


def test_profile_ask_rule_returns_action_ask(tmp_path) -> None:
    store = _store_with_rules(
        tmp_path,
        [
            ProfileRulePayload(
                label="Review Project",
                entity_type="CUSTOM",
                patterns=["Project Atlas"],
                replacement="[PROJECT]",
                action="ask",
            )
        ],
    )
    result = _pipeline(store).redact("Discuss Project Atlas.")

    assert result.redacted_text == "Discuss [PROJECT]."
    assert result.entities[0].action == "ask"
    assert result.entities[0].profile_rule_id == store.get_profile().rules[0].id


def test_profile_rule_id_appears_in_entities(tmp_path) -> None:
    store = _store_with_rules(
        tmp_path,
        [
            ProfileRulePayload(
                label="Person",
                entity_type="PERSON",
                patterns=["Ada Lovelace"],
                replacement="[PERSON]",
                action="mask",
            )
        ],
    )
    rule_id = store.get_profile().rules[0].id

    result = _pipeline(store).redact("Ada Lovelace is listed.")

    assert result.entities[0].source == "profile"
    assert result.entities[0].profile_rule_id == rule_id


def test_learn_from_text_returns_candidates_without_mutating_profile(tmp_path) -> None:
    profile_path = tmp_path / "profile.json"
    client = _client(tmp_path)
    text = "Email ada@example.com. 我的学校是北京理工大学。"

    response = client.post(
        "/profile/learn-from-text",
        json={"text": text, "mode": "balanced"},
    )

    assert response.status_code == 200
    payload = response.json()
    candidates = payload["candidates"]
    assert {candidate["suggested_entity_type"] for candidate in candidates} >= {
        "EMAIL",
        "SCHOOL",
    }
    email_candidate = next(
        candidate for candidate in candidates if candidate["suggested_entity_type"] == "EMAIL"
    )
    assert email_candidate["pattern"] == "ada@example.com"
    assert email_candidate["replacement"] == "[EMAIL]"
    assert email_candidate["suggested_action"] == "mask"
    assert email_candidate["source_detector"] == "regex:email"

    profile_response = client.get("/profile")
    assert profile_response.status_code == 200
    assert profile_response.json() == {"version": 1, "rules": []}
    assert not profile_path.exists()


def test_saving_selected_learning_candidate_creates_profile_rule(tmp_path) -> None:
    client = _client(tmp_path)
    learn_response = client.post(
        "/profile/learn-from-text",
        json={"text": "Contact ada@example.com."},
    )
    candidate = learn_response.json()["candidates"][0]

    create_response = client.post(
        "/profile/rules",
        json=_rule_payload_from_candidate(candidate),
    )

    assert create_response.status_code == 200
    rule = create_response.json()
    assert rule["entity_type"] == "EMAIL"
    assert rule["patterns"] == ["ada@example.com"]
    assert rule["replacement"] == "[EMAIL]"
    assert rule["action"] == "mask"


def test_quick_add_from_selected_entity_creates_correct_rule(tmp_path) -> None:
    client = _client(tmp_path)
    redact_response = client.post(
        "/redact/text",
        json={"text": "Contact ada@example.com."},
    )
    entity = redact_response.json()["entities"][0]

    create_response = client.post(
        "/profile/rules",
        json={
            "label": "Quick EMAIL rule",
            "entity_type": entity["type"],
            "patterns": [entity["text"]],
            "aliases": [],
            "replacement": entity["replacement"],
            "action": "ask",
            "enabled": True,
            "scope": "global",
        },
    )

    assert create_response.status_code == 200
    rule = create_response.json()
    assert rule["entity_type"] == "EMAIL"
    assert rule["patterns"] == ["ada@example.com"]
    assert rule["replacement"] == "[EMAIL]"
    assert rule["action"] == "ask"


def test_quick_allow_rule_suppresses_future_match(tmp_path) -> None:
    client = _client(tmp_path)
    text = "Contact support@example.com."
    entity = client.post("/redact/text", json={"text": text}).json()["entities"][0]

    create_response = client.post(
        "/profile/rules",
        json={
            "label": "Allow support email",
            "entity_type": entity["type"],
            "patterns": [entity["text"]],
            "aliases": [],
            "action": "allow",
            "enabled": True,
            "scope": "global",
        },
    )
    second_redact_response = client.post("/redact/text", json={"text": text})

    assert create_response.status_code == 200
    assert second_redact_response.status_code == 200
    assert second_redact_response.json()["redacted_text"] == text
    assert second_redact_response.json()["entities"] == []


def test_learn_from_text_handles_chinese_and_mixed_language_terms(tmp_path) -> None:
    client = _client(tmp_path)
    text = "我的学校是北京理工大学，也叫 Beijing Institute of Technology。"

    response = client.post("/profile/learn-from-text", json={"text": text})

    assert response.status_code == 200
    candidates = response.json()["candidates"]
    school_patterns = {
        candidate["pattern"]
        for candidate in candidates
        if candidate["suggested_entity_type"] == "SCHOOL"
    }
    assert "北京理工大学" in school_patterns
    assert "Beijing Institute of Technology" in school_patterns


def test_learn_from_text_does_not_persist_raw_sample_text(tmp_path) -> None:
    profile_path = tmp_path / "profile.json"
    store = _store_with_rules(
        tmp_path,
        [
            ProfileRulePayload(
                label="Existing",
                entity_type="CUSTOM",
                patterns=["ExistingTerm"],
                replacement="[CUSTOM]",
                action="mask",
            )
        ],
    )
    client = TestClient(
        create_app(
            settings=WorkerSettings(),
            profile_store=store,
        )
    )
    sample_text = "Private sample ada@example.com and Project Unpersisted."
    before = profile_path.read_text(encoding="utf-8")

    response = client.post("/profile/learn-from-text", json={"text": sample_text})

    assert response.status_code == 200
    after = profile_path.read_text(encoding="utf-8")
    assert after == before
    assert "Private sample" not in after
    assert "Project Unpersisted" not in after
    assert "ada@example.com" not in after


def test_learn_from_text_uses_profile_context_to_avoid_duplicate_candidates(tmp_path) -> None:
    store = _store_with_rules(
        tmp_path,
        [
            ProfileRulePayload(
                label="Existing School",
                entity_type="SCHOOL",
                patterns=["北京理工大学"],
                replacement="[SCHOOL]",
                action="mask",
            ),
            ProfileRulePayload(
                label="Allowed Support Email",
                entity_type="EMAIL",
                patterns=["support@example.com"],
                action="allow",
            ),
        ],
    )
    client = TestClient(
        create_app(
            settings=WorkerSettings(),
            profile_store=store,
        )
    )

    response = client.post(
        "/profile/learn-from-text",
        json={"text": "support@example.com 北京理工大学 ada@example.com"},
    )

    assert response.status_code == 200
    patterns = {candidate["pattern"] for candidate in response.json()["candidates"]}
    assert "support@example.com" not in patterns
    assert "北京理工大学" not in patterns
    assert "ada@example.com" in patterns


def test_chinese_and_mixed_language_profile_rule_applies(tmp_path) -> None:
    store = _store_with_rules(
        tmp_path,
        [
            ProfileRulePayload(
                label="Tsinghua",
                entity_type="SCHOOL",
                patterns=["清华大学"],
                aliases=["Tsinghua University"],
                replacement="[SCHOOL]",
                action="mask",
            )
        ],
    )
    result = _pipeline(store).redact("我在清华大学，也叫 Tsinghua University")

    assert result.redacted_text == "我在[SCHOOL]，也叫 [SCHOOL]"
    assert [entity.source for entity in result.entities] == ["profile", "profile"]
    assert [entity.profile_rule_id for entity in result.entities] == [
        store.get_profile().rules[0].id,
        store.get_profile().rules[0].id,
    ]


def test_profile_allow_rule_does_not_suppress_regex_api_key(tmp_path) -> None:
    secret = "fixture-key-0000000000000000"
    store = _store_with_rules(
        tmp_path,
        [
            ProfileRulePayload(
                label="Do Not Allow Secrets",
                entity_type="API_KEY",
                patterns=[secret],
                action="allow",
            )
        ],
    )
    result = _pipeline(store).redact(f"OPENAI_API_KEY={secret}")

    assert result.redacted_text == "OPENAI_API_KEY=[API_KEY]"
    assert result.entities[0].source.startswith("regex:")
    assert result.entities[0].type == "API_KEY"


def _client(tmp_path) -> TestClient:
    return TestClient(
        create_app(
            settings=WorkerSettings(),
            profile_store=ProfileStore(tmp_path / "profile.json"),
        )
    )


def _store_with_rules(
    tmp_path,
    payloads: list[ProfileRulePayload],
) -> ProfileStore:
    store = ProfileStore(tmp_path / "profile.json")
    for payload in payloads:
        store.add_rule(payload)
    return store


def _pipeline(store: ProfileStore) -> TextRedactionPipeline:
    return TextRedactionPipeline(profile_rules_loader=store.load_enabled_rules)


def _rule_payload_from_candidate(candidate: dict[str, object]) -> dict[str, object]:
    return {
        "label": f"Learned {candidate['suggested_entity_type']} rule",
        "entity_type": candidate["suggested_entity_type"],
        "patterns": [candidate["pattern"]],
        "aliases": candidate["aliases"],
        "replacement": candidate["replacement"],
        "action": candidate["suggested_action"],
        "enabled": True,
        "scope": "global",
    }
