import base64
import json
from io import BytesIO

import pypdfium2 as pdfium
from fastapi.testclient import TestClient
from PIL import Image, ImageDraw
from pypdf import PdfReader
from reportlab.lib.utils import ImageReader
from reportlab.pdfgen.canvas import Canvas

from app.config import WorkerSettings
from app.image_redaction import OCRTextBox
from app.main import create_app
from app.pdf_redaction import PDFRedactionService
from app.profile_store import ProfileStore
from app.redaction import TextRedactionPipeline


class StubOCRProvider:
    name = "stub"

    def __init__(self, boxes: list[OCRTextBox]) -> None:
        self.boxes = boxes

    def extract_text_boxes(self, image, *, image_bytes: bytes, image_format: str):
        return self.boxes


def _client(tmp_path, ocr_boxes: list[OCRTextBox] | None = None) -> TestClient:
    pipeline = TextRedactionPipeline()
    pdf_service = PDFRedactionService(
        ocr_provider=StubOCRProvider(ocr_boxes or []),
        text_pipeline=pipeline,
    )
    return TestClient(
        create_app(
            settings=WorkerSettings(image_ocr_provider="none"),
            profile_store=ProfileStore(tmp_path / "profile.json"),
            redaction_pipeline=pipeline,
            pdf_redaction_service=pdf_service,
        )
    )


def _text_pdf_bytes(text: str) -> bytes:
    output = BytesIO()
    pdf = Canvas(output, pagesize=(300, 180), invariant=1)
    pdf.setFont("Helvetica", 14)
    pdf.drawString(36, 108, text)
    pdf.save()
    return output.getvalue()


def _overlay_pdf_bytes(text: str) -> bytes:
    output = BytesIO()
    pdf = Canvas(output, pagesize=(300, 180), invariant=1)
    pdf.setFont("Helvetica", 14)
    pdf.drawString(36, 108, text)
    pdf.setFillColorRGB(0, 0, 0)
    pdf.rect(32, 96, 228, 30, stroke=0, fill=1)
    pdf.save()
    return output.getvalue()


def _scanned_pdf_bytes() -> bytes:
    image = Image.new("RGB", (220, 110), "white")
    draw = ImageDraw.Draw(image)
    draw.text((20, 28), "scan@example.com", fill=(0, 0, 0))
    image_buffer = BytesIO()
    image.save(image_buffer, format="PNG")

    output = BytesIO()
    pdf = Canvas(output, pagesize=(220, 110), invariant=1)
    pdf.drawImage(ImageReader(image_buffer), 0, 0, width=220, height=110)
    pdf.save()
    return output.getvalue()


def _post_analyze(client: TestClient, pdf_bytes: bytes):
    return client.post(
        "/redact/pdf/analyze",
        data={"mode": "balanced"},
        files={"pdf": ("sample.pdf", pdf_bytes, "application/pdf")},
    )


def _post_export(
    client: TestClient,
    pdf_bytes: bytes,
    *,
    manual_rectangles=None,
):
    data = {"mode": "balanced"}
    if manual_rectangles is not None:
        data["manual_rectangles"] = json.dumps(manual_rectangles)
    return client.post(
        "/redact/pdf/export",
        data=data,
        files={"pdf": ("sample.pdf", pdf_bytes, "application/pdf")},
    )


def _output_pdf_bytes(payload: dict) -> bytes:
    return base64.b64decode(payload["redacted_pdf_base64"])


def _extract_pdf_text(pdf_bytes: bytes) -> str:
    return "\n".join(page.extract_text() or "" for page in PdfReader(BytesIO(pdf_bytes)).pages)


def _has_redaction_annotations(pdf_bytes: bytes) -> bool:
    for page in PdfReader(BytesIO(pdf_bytes)).pages:
        for reference in page.get("/Annots") or []:
            if str(reference.get_object().get("/Subtype")).lower() == "/redact":
                return True
    return False


def _first_page_image(pdf_bytes: bytes) -> Image.Image:
    doc = pdfium.PdfDocument(pdf_bytes)
    try:
        page = doc[0]
        bitmap = page.render(scale=1)
        try:
            return bitmap.to_pil().convert("RGB")
        finally:
            bitmap.close()
            page.close()
    finally:
        doc.close()


def _first_page_image_count(pdf_bytes: bytes) -> int:
    page = PdfReader(BytesIO(pdf_bytes)).pages[0]
    resources = page.get("/Resources") or {}
    xobjects = resources.get("/XObject") or {}
    return sum(1 for reference in xobjects.values() if str(reference.get_object().get("/Subtype")) == "/Image")


def test_text_pdf_sensitive_string_is_not_extractable_after_redaction(tmp_path) -> None:
    source = _text_pdf_bytes("Contact ada@example.com before sending.")
    assert "ada@example.com" in _extract_pdf_text(source)
    client = _client(tmp_path)

    analyze_response = _post_analyze(client, source)
    assert analyze_response.status_code == 200
    assert analyze_response.json()["document_type"] == "text"
    assert analyze_response.json()["redaction_regions"][0]["source"] == "text_pdf"

    export_response = _post_export(client, source)

    assert export_response.status_code == 200
    payload = export_response.json()
    output = _output_pdf_bytes(payload)
    assert payload["validation"]["status"] == "passed"
    assert "ada@example.com" not in _extract_pdf_text(output)
    assert _extract_pdf_text(output).strip() == ""
    assert _first_page_image_count(output) >= 1


def test_black_rectangle_overlay_alone_is_not_used_as_final_output(tmp_path) -> None:
    source = _overlay_pdf_bytes("Hidden overlay leak: ada@example.com")
    assert "ada@example.com" in _extract_pdf_text(source)
    client = _client(tmp_path)

    response = _post_export(client, source)

    assert response.status_code == 200
    output = _output_pdf_bytes(response.json())
    assert "ada@example.com" not in _extract_pdf_text(output)
    assert _extract_pdf_text(output).strip() == ""
    assert not _has_redaction_annotations(output)
    assert _first_page_image_count(output) >= 1


def test_rasterization_fallback_removes_extractable_text_layer(tmp_path) -> None:
    source = _text_pdf_bytes("Fallback check phone 415-555-0188.")
    assert "415-555-0188" in _extract_pdf_text(source)
    client = _client(tmp_path)

    response = _post_export(client, source)

    assert response.status_code == 200
    output = _output_pdf_bytes(response.json())
    assert _extract_pdf_text(output).strip() == ""
    assert "415-555-0188" not in _extract_pdf_text(output)
    assert _first_page_image_count(output) >= 1


def test_scanned_pdf_redaction_burns_into_page_image(tmp_path) -> None:
    source = _scanned_pdf_bytes()
    assert _extract_pdf_text(source).strip() == ""
    client = _client(
        tmp_path,
        [
            OCRTextBox(
                text="scan@example.com",
                x=40,
                y=56,
                width=180,
                height=24,
                confidence=0.95,
                source="stub",
            )
        ],
    )

    response = _post_export(client, source)

    assert response.status_code == 200
    payload = response.json()
    assert payload["document_type"] == "scanned"
    assert payload["redaction_regions"][0]["source"] == "ocr"
    output = _output_pdf_bytes(payload)
    rendered = _first_page_image(output)
    assert rendered.getpixel((30, 35)) == (0, 0, 0)


def test_manual_rectangle_redaction_is_destructive(tmp_path) -> None:
    source = _text_pdf_bytes("Manual-only visible project name.")
    client = _client(tmp_path)

    response = _post_export(
        client,
        source,
        manual_rectangles=[
            {"page_index": 0, "x": 30, "y": 52, "width": 200, "height": 34}
        ],
    )

    assert response.status_code == 200
    payload = response.json()
    assert payload["validation"]["status"] == "warning"
    assert payload["redaction_regions"][0]["source"] == "manual"
    output = _output_pdf_bytes(payload)
    assert _extract_pdf_text(output).strip() == ""
    rendered = _first_page_image(output)
    assert rendered.getpixel((40, 60)) == (0, 0, 0)


def test_original_pdf_is_not_overwritten(tmp_path) -> None:
    source = _text_pdf_bytes("Contact ada@example.com before sending.")
    source_path = tmp_path / "source.pdf"
    source_path.write_bytes(source)
    client = _client(tmp_path)

    response = _post_export(client, source_path.read_bytes())

    assert response.status_code == 200
    assert source_path.read_bytes() == source
    assert _output_pdf_bytes(response.json()) != source
