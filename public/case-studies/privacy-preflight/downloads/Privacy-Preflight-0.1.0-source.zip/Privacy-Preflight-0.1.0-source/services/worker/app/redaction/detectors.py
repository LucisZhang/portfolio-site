from __future__ import annotations

import ipaddress
import re
from dataclasses import dataclass
from typing import Protocol


RedactionMode = str


@dataclass(frozen=True)
class DetectionCandidate:
    type: str
    start: int
    end: int
    confidence: float
    source: str
    reason: str
    replacement: str | None = None
    action: str = "replace"
    profile_rule_id: str | None = None

    @property
    def length(self) -> int:
        return self.end - self.start


class Detector(Protocol):
    name: str

    def detect(self, text: str, mode: RedactionMode) -> list[DetectionCandidate]:
        """Return sensitive spans in original text offsets."""


class DeterministicRegexDetector:
    name = "deterministic_regex"

    _EMAIL_RE = re.compile(
        r"(?<![A-Z0-9._%+-])"
        r"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}"
        r"(?![A-Z0-9_%+-])",
        re.IGNORECASE,
    )
    _PHONE_RE = re.compile(
        r"(?<!\d)(?:"
        r"(?:\+?86[\s.-]?)?1[3-9]\d(?:[\s.-]?\d){8}"
        r"|(?:\+?\d{1,3}[\s.-]?)?(?:\(\d{3}\)|\d{3})[\s.-]?"
        r"\d{3}[\s.-]?\d{4}(?:\s*(?:x|ext\.?)\s*\d{1,6})?"
        r")(?!\d)",
        re.IGNORECASE,
    )
    _URL_RE = re.compile(r"(?i)\b(?:https?://|www\.)[^\s<>'\"]+")
    _IPV4_RE = re.compile(
        r"(?<![\w.])(?:\d{1,3}\.){3}\d{1,3}(?![\w.])"
    )
    _IPV6_RE = re.compile(
        r"(?<![\w:])(?:[A-F0-9]{1,4}:){2,}[A-F0-9:]{1,}(?![\w:])",
        re.IGNORECASE,
    )
    _LOCAL_PATH_WITH_EXTENSION_RE = re.compile(
        r"(?<![:\w])"
        r"(?:~|/(?:Users|Volumes|private|var|tmp|Applications))"
        r"(?:/[^\n\r/<>:\"|?*]+)+?"
        r"\.[A-Za-z0-9]{1,12}"
    )
    _LOCAL_PATH_RE = re.compile(
        r"(?<![:\w])(?:"
        r"/Users/[^\s/<>:\"|?*]+(?:/[^\s/<>:\"|?*]+)*"
        r"|/(?:Volumes|private|var|tmp|Applications)/[^\s/<>:\"|?*]+(?:/[^\s/<>:\"|?*]+)*"
        r"|~/[^\s/<>:\"|?*]+(?:/[^\s/<>:\"|?*]+)*"
        r")"
    )
    _SECRET_ASSIGNMENT_RE = re.compile(
        r"""
        \b
        [A-Z0-9_]*
        (?:API[_-]?KEY|TOKEN|SECRET|PASSWORD|PASSWD|PWD|ACCESS[_-]?TOKEN|
           AUTH[_-]?TOKEN|CLIENT[_-]?SECRET|PRIVATE[_-]?KEY)
        [A-Z0-9_]*
        \b
        \s*(?:=|:)\s*
        (?P<quote>["']?)
        (?P<secret>[A-Za-z0-9][A-Za-z0-9._~+/=-]{15,})
        (?P=quote)
        """,
        re.IGNORECASE | re.VERBOSE,
    )
    _KNOWN_SECRET_PATTERNS: tuple[tuple[re.Pattern[str], str], ...] = (
        (
            re.compile(r"(?<![A-Za-z0-9_-])sk-(?:proj-)?[A-Za-z0-9_-]{20,}(?![A-Za-z0-9_-])"),
            "OpenAI-like secret key prefix.",
        ),
        (
            re.compile(r"(?<![A-Za-z0-9])github_pat_[A-Za-z0-9_]{30,}(?![A-Za-z0-9_])"),
            "GitHub fine-grained token prefix.",
        ),
        (
            re.compile(r"(?<![A-Za-z0-9])gh[pousr]_[A-Za-z0-9]{30,}(?![A-Za-z0-9])"),
            "GitHub token prefix.",
        ),
        (
            re.compile(r"(?<![A-Za-z0-9])AKIA[0-9A-Z]{16}(?![A-Za-z0-9])"),
            "AWS access key identifier pattern.",
        ),
        (
            re.compile(r"(?<![A-Za-z0-9_-])AIza[0-9A-Za-z_-]{35}(?![A-Za-z0-9_-])"),
            "Google API key prefix.",
        ),
        (
            re.compile(r"(?<![A-Za-z0-9-])xox[baprs]-[A-Za-z0-9-]{20,}(?![A-Za-z0-9-])"),
            "Slack token prefix.",
        ),
        (
            re.compile(r"(?<![A-Za-z0-9])(?:sk|pk)_(?:live|test)_[A-Za-z0-9]{16,}(?![A-Za-z0-9])"),
            "Stripe key prefix.",
        ),
        (
            re.compile(r"(?<![A-Za-z0-9_-])eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}(?![A-Za-z0-9_-])"),
            "JWT-like bearer token structure.",
        ),
    )
    _LONG_ID_RE = re.compile(
        r"(?<![A-Za-z0-9_-])"
        r"(?=[A-Za-z0-9_-]{20,}\b)"
        r"(?=[A-Za-z0-9_-]*[A-Za-z])"
        r"(?=[A-Za-z0-9_-]*\d)"
        r"[A-Za-z0-9][A-Za-z0-9_-]{19,}"
        r"(?![A-Za-z0-9_-])"
    )
    _ID_CONTEXT_RE = re.compile(
        r"(?i)(?:id|identifier|session|trace|request|correlation|token|key)\s*[:=#-]?\s*$"
    )
    _TRAILING_CHARS = ".,;:!?)]}'\""
    _PLACEHOLDER_WORDS = (
        "example",
        "sample",
        "placeholder",
        "changeme",
        "replace",
        "redacted",
        "your_",
        "xxxx",
    )

    def detect(self, text: str, mode: RedactionMode) -> list[DetectionCandidate]:
        candidates: list[DetectionCandidate] = []
        candidates.extend(self._detect_emails(text))
        candidates.extend(self._detect_phones(text))
        candidates.extend(self._detect_urls(text))
        candidates.extend(self._detect_ip_addresses(text))
        candidates.extend(self._detect_local_paths(text))
        candidates.extend(self._detect_api_keys(text))
        candidates.extend(self._detect_long_ids(text, mode))
        return candidates

    def _detect_emails(self, text: str) -> list[DetectionCandidate]:
        return [
            DetectionCandidate(
                type="EMAIL",
                start=match.start(),
                end=match.end(),
                confidence=0.98,
                source="regex:email",
                reason="Matched a standard email address pattern.",
            )
            for match in self._EMAIL_RE.finditer(text)
        ]

    def _detect_phones(self, text: str) -> list[DetectionCandidate]:
        candidates: list[DetectionCandidate] = []
        for match in self._PHONE_RE.finditer(text):
            value = match.group(0)
            digit_count = sum(char.isdigit() for char in value)
            if not 10 <= digit_count <= 15:
                continue
            candidates.append(
                DetectionCandidate(
                    type="PHONE",
                    start=match.start(),
                    end=match.end(),
                    confidence=0.86,
                    source="regex:phone",
                    reason="Matched a phone-number-like pattern with 10 to 15 digits.",
                )
            )
        return candidates

    def _detect_urls(self, text: str) -> list[DetectionCandidate]:
        candidates: list[DetectionCandidate] = []
        for match in self._URL_RE.finditer(text):
            start, end = self._trim_span(text, match.start(), match.end())
            if end <= start:
                continue
            candidates.append(
                DetectionCandidate(
                    type="URL",
                    start=start,
                    end=end,
                    confidence=0.94,
                    source="regex:url",
                    reason="Matched a web URL pattern.",
                )
            )
        return candidates

    def _detect_ip_addresses(self, text: str) -> list[DetectionCandidate]:
        candidates: list[DetectionCandidate] = []
        for regex in (self._IPV4_RE, self._IPV6_RE):
            for match in regex.finditer(text):
                value = match.group(0)
                try:
                    ipaddress.ip_address(value)
                except ValueError:
                    continue
                candidates.append(
                    DetectionCandidate(
                        type="IP_ADDRESS",
                        start=match.start(),
                        end=match.end(),
                        confidence=0.92,
                        source="regex:ip_address",
                        reason="Matched and validated an IP address pattern.",
                    )
                )
        return candidates

    def _detect_local_paths(self, text: str) -> list[DetectionCandidate]:
        candidates: list[DetectionCandidate] = []
        seen_spans: set[tuple[int, int]] = set()
        for regex in (self._LOCAL_PATH_WITH_EXTENSION_RE, self._LOCAL_PATH_RE):
            for match in regex.finditer(text):
                start, end = self._trim_span(text, match.start(), match.end())
                if end <= start or (start, end) in seen_spans:
                    continue
                seen_spans.add((start, end))
                candidates.append(
                    DetectionCandidate(
                        type="LOCAL_PATH",
                        start=start,
                        end=end,
                        confidence=0.9,
                        source="regex:local_path",
                        reason="Matched a local filesystem path, including macOS-style locations.",
                    )
                )
        return candidates

    def _detect_api_keys(self, text: str) -> list[DetectionCandidate]:
        candidates: list[DetectionCandidate] = []
        for match in self._SECRET_ASSIGNMENT_RE.finditer(text):
            secret = match.group("secret")
            if not self._looks_like_secret(secret):
                continue
            candidates.append(
                DetectionCandidate(
                    type="API_KEY",
                    start=match.start("secret"),
                    end=match.end("secret"),
                    confidence=0.9,
                    source="regex:api_key_assignment",
                    reason="Matched a credential-style key, token, password, or secret assignment.",
                )
            )

        for regex, reason in self._KNOWN_SECRET_PATTERNS:
            for match in regex.finditer(text):
                start, end = self._trim_span(text, match.start(), match.end())
                if end <= start:
                    continue
                candidates.append(
                    DetectionCandidate(
                        type="API_KEY",
                        start=start,
                        end=end,
                        confidence=0.96,
                        source="regex:api_key_known_prefix",
                        reason=reason,
                    )
                )
        return candidates

    def _detect_long_ids(self, text: str, mode: RedactionMode) -> list[DetectionCandidate]:
        candidates: list[DetectionCandidate] = []
        for match in self._LONG_ID_RE.finditer(text):
            value = match.group(0)
            previous_text = text[max(0, match.start() - 32) : match.start()]
            has_context = bool(self._ID_CONTEXT_RE.search(previous_text))
            is_strict_match = mode == "strict" and len(value) >= 20
            is_balanced_match = len(value) >= 32 or has_context
            if not (is_strict_match or is_balanced_match):
                continue
            candidates.append(
                DetectionCandidate(
                    type="ID",
                    start=match.start(),
                    end=match.end(),
                    confidence=0.72 if is_strict_match and not is_balanced_match else 0.82,
                    source="regex:long_id",
                    reason="Matched a long mixed alphanumeric identifier-like token.",
                )
            )
        return candidates

    def _looks_like_secret(self, value: str) -> bool:
        normalized = value.lower()
        if any(word in normalized for word in self._PLACEHOLDER_WORDS):
            return False
        if len(set(value)) <= 3:
            return False
        return len(value) >= 16

    def _trim_span(self, text: str, start: int, end: int) -> tuple[int, int]:
        while end > start and text[end - 1] in self._TRAILING_CHARS:
            end -= 1
        return start, end
