from __future__ import annotations

import re
from dataclasses import dataclass
from io import BytesIO
from typing import Any, Iterator

import pypdfium2 as pdfium
from PIL import Image
from pypdf import PdfReader
from reportlab.lib.utils import ImageReader
from reportlab.pdfgen import canvas as reportlab_canvas


@dataclass(frozen=True)
class PDFRect:
    x0: float
    y0: float
    x1: float
    y1: float

    @property
    def width(self) -> float:
        return self.x1 - self.x0

    @property
    def height(self) -> float:
        return self.y1 - self.y0


class PDFPage:
    def __init__(self, document: "PDFDocument", index: int) -> None:
        self._document = document
        self._index = index
        self._page = document._pdfium[index]
        self._reader_page = document._reader.pages[index]
        width, height = self._page.get_size()
        self.rect = PDFRect(0.0, 0.0, float(width), float(height))

    def close(self) -> None:
        self._page.close()

    def get_text(self, mode: str, sort: bool = False) -> Any:
        del sort
        if mode == "text":
            return self._reader_page.extract_text() or ""
        if mode != "words":
            raise ValueError(f"Unsupported text extraction mode: {mode}")

        text_page = self._page.get_textpage()
        try:
            text = text_page.get_text_range()
            words: list[tuple[float, float, float, float, str, int, int]] = []
            line_no = 0
            for match in re.finditer(r"\S+", text):
                token = match.group(0)
                boxes = []
                for index in range(match.start(), match.end()):
                    try:
                        boxes.append(text_page.get_charbox(index))
                    except Exception:
                        continue
                if not boxes:
                    continue
                left = min(box[0] for box in boxes)
                bottom = min(box[1] for box in boxes)
                right = max(box[2] for box in boxes)
                top = max(box[3] for box in boxes)
                words.append((left, self.rect.height - top, right, self.rect.height - bottom, token, 0, line_no))
                line_no += text[match.end():].startswith(("\r", "\n"))
            return words
        finally:
            text_page.close()

    def get_images(self, full: bool = True) -> list[str]:
        del full
        try:
            resources = self._reader_page.get("/Resources") or {}
            xobjects = resources.get("/XObject") or {}
            images = []
            for name, reference in xobjects.items():
                obj = reference.get_object()
                if str(obj.get("/Subtype")) == "/Image":
                    images.append(str(name))
            return images
        except Exception:
            return []

    def has_redaction_annotations(self) -> bool:
        annotations = self._reader_page.get("/Annots") or []
        for reference in annotations:
            try:
                annotation = reference.get_object()
                if str(annotation.get("/Subtype")).lower() == "/redact":
                    return True
            except Exception:
                continue
        return False

    def render_image(self, *, scale: float) -> Image.Image:
        bitmap = self._page.render(scale=scale)
        try:
            return bitmap.to_pil().convert("RGB")
        finally:
            bitmap.close()


class PDFDocument:
    def __init__(self, pdf_bytes: bytes) -> None:
        self._reader = PdfReader(BytesIO(pdf_bytes), strict=False)
        if self._reader.is_encrypted:
            raise ValueError("Password-protected PDFs must be unlocked before redaction.")
        self._pdfium = pdfium.PdfDocument(pdf_bytes)
        self.page_count = len(self._pdfium)
        self.needs_pass = False

    def __len__(self) -> int:
        return self.page_count

    def __getitem__(self, index: int) -> PDFPage:
        return PDFPage(self, index)

    def __iter__(self) -> Iterator[PDFPage]:
        for index in range(self.page_count):
            page = PDFPage(self, index)
            try:
                yield page
            finally:
                page.close()

    def close(self) -> None:
        self._pdfium.close()


def open_pdf(pdf_bytes: bytes) -> PDFDocument:
    return PDFDocument(pdf_bytes)


def create_image_only_pdf(pages: list[tuple[Image.Image, float, float]]) -> bytes:
    output = BytesIO()
    pdf = reportlab_canvas.Canvas(output, pagesize=(1, 1), pageCompression=1, invariant=1)
    pdf.setAuthor("")
    pdf.setCreator("Privacy Preflight")
    pdf.setProducer("Privacy Preflight")
    pdf.setSubject("")
    pdf.setTitle("Redacted image-only PDF")
    for image, width, height in pages:
        pdf.setPageSize((width, height))
        pdf.drawImage(ImageReader(image), 0, 0, width=width, height=height, preserveAspectRatio=False, mask=None)
        pdf.showPage()
    pdf.save()
    return output.getvalue()
