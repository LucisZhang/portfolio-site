from __future__ import annotations

import base64
import json
import os
import platform
import shutil
import subprocess
import tempfile
from collections import Counter
from dataclasses import dataclass
from io import BytesIO
from pathlib import Path
from typing import Any, Protocol

from PIL import Image, ImageDraw, UnidentifiedImageError

from app.redaction.pipeline import TextRedactionPipeline
from app.schemas import (
    ImageOCRBox,
    ImageRectangle,
    ImageRedactedBox,
    ImageRedactionMode,
    ImageRedactionResponse,
)


SUPPORTED_IMAGE_FORMATS = {"PNG", "JPEG"}
SUPPORTED_MEDIA_TYPES = {"image/png", "image/jpeg"}


class ImageRedactionError(Exception):
    """Base class for image redaction failures safe to show to local clients."""


class InvalidImageError(ImageRedactionError):
    pass


class OCRUnavailableError(ImageRedactionError):
    pass


@dataclass(frozen=True)
class OCRTextBox:
    text: str
    x: float
    y: float
    width: float
    height: float
    confidence: float = 1.0
    source: str = "ocr"


class OCRProvider(Protocol):
    name: str

    def extract_text_boxes(
        self,
        image: Image.Image,
        *,
        image_bytes: bytes,
        image_format: str,
    ) -> list[OCRTextBox]:
        ...


class UnavailableOCRProvider:
    name = "unavailable"

    def __init__(self, reason: str) -> None:
        self.reason = reason

    def extract_text_boxes(
        self,
        image: Image.Image,
        *,
        image_bytes: bytes,
        image_format: str,
    ) -> list[OCRTextBox]:
        raise OCRUnavailableError(self.reason)


class PytesseractOCRProvider:
    name = "pytesseract"

    def __init__(self, *, min_confidence: float = 0.30) -> None:
        self.min_confidence = min_confidence

    def extract_text_boxes(
        self,
        image: Image.Image,
        *,
        image_bytes: bytes,
        image_format: str,
    ) -> list[OCRTextBox]:
        try:
            import pytesseract
            from pytesseract import Output
        except ImportError as exc:
            raise OCRUnavailableError(
                "Image OCR is not installed. Install the image OCR extra or use macOS Vision OCR."
            ) from exc

        try:
            data = pytesseract.image_to_data(
                image.convert("RGB"),
                output_type=Output.DICT,
            )
        except Exception as exc:
            raise OCRUnavailableError(
                "Tesseract OCR is unavailable or failed locally."
            ) from exc

        boxes: list[OCRTextBox] = []
        for index, raw_text in enumerate(data.get("text", [])):
            text = str(raw_text).strip()
            if not text:
                continue

            confidence = _parse_confidence(data.get("conf", ["-1"])[index])
            if confidence < self.min_confidence:
                continue

            boxes.append(
                OCRTextBox(
                    text=text,
                    x=float(data.get("left", [0])[index]),
                    y=float(data.get("top", [0])[index]),
                    width=float(data.get("width", [0])[index]),
                    height=float(data.get("height", [0])[index]),
                    confidence=confidence,
                    source=self.name,
                )
            )

        return boxes


class VisionOCRProvider:
    name = "vision"

    def __init__(
        self,
        *,
        executable_path: str | None = None,
        swift_path: str | None = None,
        script_path: str | None = None,
        timeout_seconds: int = 30,
    ) -> None:
        self.executable_path = executable_path or _bundled_vision_executable()
        self.swift_path = swift_path or shutil.which("swift") or "/usr/bin/swift"
        self.script_path = script_path or str(
            Path(__file__).with_name("image_ocr_vision.swift")
        )
        self.timeout_seconds = timeout_seconds

    def extract_text_boxes(
        self,
        image: Image.Image,
        *,
        image_bytes: bytes,
        image_format: str,
    ) -> list[OCRTextBox]:
        if platform.system() != "Darwin":
            raise OCRUnavailableError("macOS Vision OCR is only available on macOS.")
        executable = Path(self.executable_path) if self.executable_path else None
        use_bundled_executable = executable is not None and executable.is_file() and os.access(executable, os.X_OK)
        if not use_bundled_executable:
            if not shutil.which(self.swift_path) and not Path(self.swift_path).exists():
                raise OCRUnavailableError("The bundled macOS Vision OCR helper is missing.")
            if not Path(self.script_path).exists():
                raise OCRUnavailableError("The macOS Vision OCR bridge is missing.")

        suffix = ".png" if image_format == "PNG" else ".jpg"
        temp_path: str | None = None
        try:
            with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as temp_file:
                temp_file.write(image_bytes)
                temp_path = temp_file.name

            command = [str(executable), temp_path] if use_bundled_executable else [self.swift_path, self.script_path, temp_path]
            completed = subprocess.run(
                command,
                check=False,
                capture_output=True,
                text=True,
                timeout=self.timeout_seconds,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise OCRUnavailableError(
                "macOS Vision OCR is unavailable or timed out locally."
            ) from exc
        finally:
            if temp_path:
                Path(temp_path).unlink(missing_ok=True)

        if completed.returncode != 0:
            raise OCRUnavailableError("macOS Vision OCR failed locally.")

        try:
            payload = json.loads(completed.stdout)
        except json.JSONDecodeError as exc:
            raise OCRUnavailableError("macOS Vision OCR returned unreadable metadata.") from exc

        raw_boxes = payload.get("boxes")
        if not isinstance(raw_boxes, list):
            raise OCRUnavailableError("macOS Vision OCR returned unreadable metadata.")

        boxes: list[OCRTextBox] = []
        for item in raw_boxes:
            if not isinstance(item, dict):
                continue
            text = str(item.get("text", "")).strip()
            if not text:
                continue
            boxes.append(
                OCRTextBox(
                    text=text,
                    x=float(item.get("x", 0)),
                    y=float(item.get("y", 0)),
                    width=float(item.get("width", 0)),
                    height=float(item.get("height", 0)),
                    confidence=_clamp(float(item.get("confidence", 0)), 0, 1),
                    source=self.name,
                )
            )
        return boxes


class ImageRedactionService:
    def __init__(
        self,
        *,
        ocr_provider: OCRProvider,
        text_pipeline: TextRedactionPipeline,
    ) -> None:
        self.ocr_provider = ocr_provider
        self.text_pipeline = text_pipeline

    @classmethod
    def from_settings(
        cls,
        settings: Any,
        *,
        text_pipeline: TextRedactionPipeline,
    ) -> "ImageRedactionService":
        provider_name = str(
            getattr(settings, "image_ocr_provider", "auto") or "auto"
        ).lower()
        return cls(
            ocr_provider=build_ocr_provider(provider_name),
            text_pipeline=text_pipeline,
        )

    def redact(
        self,
        image_bytes: bytes,
        *,
        mode: ImageRedactionMode,
        manual_rectangles: list[ImageRectangle] | None = None,
    ) -> ImageRedactionResponse:
        image = _load_image(image_bytes)
        input_format = _image_format(image)
        width, height = image.size

        ocr_text_boxes = self.ocr_provider.extract_text_boxes(
            image,
            image_bytes=image_bytes,
            image_format=input_format,
        )
        ocr_boxes = [
            _schema_ocr_box(index, box, image_width=width, image_height=height)
            for index, box in enumerate(ocr_text_boxes, start=1)
        ]
        ocr_boxes = [box for box in ocr_boxes if box.width > 0 and box.height > 0]

        redacted_boxes = self._select_redaction_boxes(
            ocr_boxes,
            mode=mode,
            manual_rectangles=manual_rectangles or [],
        )
        output_image = _burn_rectangles(image, redacted_boxes)
        output_bytes = _encode_image(output_image, input_format)
        summary = dict(sorted(Counter(box.source for box in redacted_boxes).items()))

        media_type = "image/png" if input_format == "PNG" else "image/jpeg"
        return ImageRedactionResponse(
            mode=mode,
            image_width=width,
            image_height=height,
            input_format=input_format,
            output_format=input_format,
            media_type=media_type,
            ocr_provider=self.ocr_provider.name,
            ocr_boxes=ocr_boxes,
            redacted_boxes=redacted_boxes,
            summary=summary,
            redacted_image_base64=base64.b64encode(output_bytes).decode("ascii"),
        )

    def _select_redaction_boxes(
        self,
        ocr_boxes: list[ImageOCRBox],
        *,
        mode: ImageRedactionMode,
        manual_rectangles: list[ImageRectangle],
    ) -> list[ImageRedactedBox]:
        redacted: list[ImageRedactedBox] = []

        for box in ocr_boxes:
            if mode == "safe_text":
                redacted.append(
                    ImageRedactedBox(
                        id=f"red_{len(redacted) + 1:04d}",
                        x=box.x,
                        y=box.y,
                        width=box.width,
                        height=box.height,
                        source="ocr",
                        reason="safe_text mode masks every OCR text region.",
                        ocr_box_id=box.id,
                        text=box.text,
                        confidence=box.confidence,
                    )
                )
                continue

            result = self.text_pipeline.redact(box.text, mode="balanced")
            if not result.entities:
                continue
            entity_types = sorted({entity.type for entity in result.entities})
            text_sources = sorted({entity.source for entity in result.entities})
            redacted.append(
                ImageRedactedBox(
                    id=f"red_{len(redacted) + 1:04d}",
                    x=box.x,
                    y=box.y,
                    width=box.width,
                    height=box.height,
                    source="text_pipeline",
                    reason=f"Detected sensitive text: {', '.join(entity_types)}.",
                    ocr_box_id=box.id,
                    text=box.text,
                    confidence=box.confidence,
                    entity_types=entity_types,
                    text_sources=text_sources,
                )
            )

        for rectangle in manual_rectangles:
            redacted.append(
                ImageRedactedBox(
                    id=f"red_{len(redacted) + 1:04d}",
                    x=rectangle.x,
                    y=rectangle.y,
                    width=rectangle.width,
                    height=rectangle.height,
                    source="manual",
                    reason="Manual rectangle redaction.",
                )
            )

        return redacted


def build_ocr_provider(provider_name: str) -> OCRProvider:
    if provider_name == "none":
        return UnavailableOCRProvider("Image OCR is disabled.")
    if provider_name == "vision":
        return VisionOCRProvider()
    if provider_name in {"tesseract", "pytesseract"}:
        return PytesseractOCRProvider()
    if provider_name != "auto":
        return UnavailableOCRProvider("Configured image OCR provider is not supported.")

    if platform.system() == "Darwin" and (_bundled_vision_executable() or shutil.which("swift")):
        return VisionOCRProvider()

    try:
        import pytesseract  # noqa: F401
    except ImportError:
        return UnavailableOCRProvider(
            "Image OCR is unavailable. Install Tesseract OCR or use macOS Vision OCR."
        )
    return PytesseractOCRProvider()


def _bundled_vision_executable() -> str | None:
    configured = os.environ.get("PRIVACY_PREFLIGHT_VISION_OCR_EXECUTABLE", "").strip()
    candidates = [configured, str(Path(__file__).with_name("image_ocr_vision"))]
    for candidate in candidates:
        path = Path(candidate) if candidate else None
        if path and path.is_file() and os.access(path, os.X_OK):
            return str(path)
    return None


def _load_image(image_bytes: bytes) -> Image.Image:
    if not image_bytes:
        raise InvalidImageError("Image file is empty.")

    try:
        image = Image.open(BytesIO(image_bytes))
        image.load()
    except (UnidentifiedImageError, OSError) as exc:
        raise InvalidImageError("Image must be a readable PNG or JPEG file.") from exc

    if _image_format(image) not in SUPPORTED_IMAGE_FORMATS:
        raise InvalidImageError("Only PNG and JPEG images are supported.")

    return image


def _image_format(image: Image.Image) -> str:
    image_format = (image.format or "").upper()
    if image_format == "JPG":
        return "JPEG"
    return image_format


def _schema_ocr_box(
    index: int,
    box: OCRTextBox,
    *,
    image_width: int,
    image_height: int,
) -> ImageOCRBox:
    x, y, width, height = _clamped_rectangle(
        box.x,
        box.y,
        box.width,
        box.height,
        image_width=image_width,
        image_height=image_height,
    )
    return ImageOCRBox(
        id=f"ocr_{index:04d}",
        text=box.text,
        x=x,
        y=y,
        width=width,
        height=height,
        confidence=_clamp(box.confidence, 0, 1),
        source=box.source,
    )


def _burn_rectangles(
    image: Image.Image,
    redacted_boxes: list[ImageRedactedBox],
) -> Image.Image:
    output = image.convert("RGBA" if image.mode in {"RGBA", "LA"} else "RGB")
    draw = ImageDraw.Draw(output)
    image_width, image_height = output.size

    fill = (0, 0, 0, 255) if output.mode == "RGBA" else (0, 0, 0)
    for box in redacted_boxes:
        x, y, width, height = _clamped_rectangle(
            box.x,
            box.y,
            box.width,
            box.height,
            image_width=image_width,
            image_height=image_height,
        )
        if width <= 0 or height <= 0:
            continue
        draw.rectangle(
            [int(x), int(y), int(x + width), int(y + height)],
            fill=fill,
        )

    return output


def _encode_image(image: Image.Image, image_format: str) -> bytes:
    buffer = BytesIO()
    clean_image = _metadata_stripped_copy(image)
    if image_format == "PNG":
        clean_image.save(buffer, format="PNG")
    else:
        clean_image.convert("RGB").save(buffer, format="JPEG", quality=95, exif=b"")
    return buffer.getvalue()


def _metadata_stripped_copy(image: Image.Image) -> Image.Image:
    clean_image = Image.new(image.mode, image.size)
    clean_image.paste(image)
    clean_image.info.clear()
    return clean_image


def _clamped_rectangle(
    x: float,
    y: float,
    width: float,
    height: float,
    *,
    image_width: int,
    image_height: int,
) -> tuple[float, float, float, float]:
    left = _clamp(x, 0, image_width)
    top = _clamp(y, 0, image_height)
    right = _clamp(x + width, 0, image_width)
    bottom = _clamp(y + height, 0, image_height)
    return left, top, max(0, right - left), max(0, bottom - top)


def _clamp(value: float, lower: float, upper: float) -> float:
    return max(lower, min(upper, value))


def _parse_confidence(value: object) -> float:
    try:
        confidence = float(value)
    except (TypeError, ValueError):
        return 0.0
    if confidence < 0:
        return 0.0
    if confidence > 1:
        confidence = confidence / 100
    return _clamp(confidence, 0, 1)
