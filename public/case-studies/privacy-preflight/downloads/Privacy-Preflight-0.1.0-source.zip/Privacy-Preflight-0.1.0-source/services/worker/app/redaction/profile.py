from __future__ import annotations

import re
from collections.abc import Callable, Iterable

from app.schemas import ProfileRule

from .detectors import DetectionCandidate, RedactionMode


class ProfileRuleDetector:
    name = "profile_rules"

    def __init__(
        self,
        *,
        rules: Iterable[ProfileRule] | None = None,
        rules_loader: Callable[[], Iterable[ProfileRule]] | None = None,
    ) -> None:
        self._rules = tuple(rules) if rules is not None else None
        self._rules_loader = rules_loader

    def detect(self, text: str, mode: RedactionMode) -> list[DetectionCandidate]:
        candidates: list[DetectionCandidate] = []
        seen_spans: set[tuple[int, int, str, str]] = set()

        for rule in self._load_rules():
            if not rule.enabled or rule.scope not in {"global", "text"}:
                continue

            for term in self._terms(rule):
                for start, end in self._find_term_spans(text, term):
                    span_key = (start, end, rule.entity_type, rule.id)
                    if span_key in seen_spans:
                        continue
                    seen_spans.add(span_key)
                    candidates.append(
                        DetectionCandidate(
                            type=rule.entity_type,
                            start=start,
                            end=end,
                            confidence=0.99,
                            source="profile",
                            reason=(
                                f"Matched profile rule {rule.id} for "
                                f"{rule.entity_type}."
                            ),
                            replacement=rule.replacement,
                            action=rule.action,
                            profile_rule_id=rule.id,
                        )
                    )

        return candidates

    def _load_rules(self) -> tuple[ProfileRule, ...]:
        if self._rules_loader is not None:
            return tuple(self._rules_loader())
        return self._rules or ()

    def _terms(self, rule: ProfileRule) -> tuple[str, ...]:
        terms: list[str] = []
        seen: set[str] = set()
        for value in (*rule.patterns, *rule.aliases):
            term = value.strip()
            if not term:
                continue
            dedupe_key = term.casefold()
            if dedupe_key in seen:
                continue
            seen.add(dedupe_key)
            terms.append(term)
        return tuple(terms)

    def _find_term_spans(self, text: str, term: str) -> list[tuple[int, int]]:
        spans: list[tuple[int, int]] = []
        is_latin_term = bool(re.search(r"[A-Za-z]", term))
        haystack = text.casefold() if is_latin_term else text
        needle = term.casefold() if is_latin_term else term

        search_start = 0
        while True:
            start = haystack.find(needle, search_start)
            if start == -1:
                break

            end = start + len(term)
            if not is_latin_term or self._has_latin_boundaries(text, start, end):
                spans.append((start, end))
            search_start = start + 1

        return spans

    def _has_latin_boundaries(self, text: str, start: int, end: int) -> bool:
        before = text[start - 1] if start > 0 else ""
        after = text[end] if end < len(text) else ""
        return not self._is_latin_word_char(before) and not self._is_latin_word_char(
            after
        )

    def _is_latin_word_char(self, value: str) -> bool:
        return bool(value and re.match(r"[A-Za-z0-9_]", value))
