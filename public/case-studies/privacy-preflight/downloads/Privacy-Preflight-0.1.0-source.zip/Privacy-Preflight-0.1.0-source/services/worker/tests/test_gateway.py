from __future__ import annotations

from fastapi.testclient import TestClient

from app.config import WorkerSettings
from app.main import create_app
from app.model_clients import ProviderTestResult
from app.model_provider_store import InMemorySecretStore, ModelProviderStore
from app.profile_store import ProfileStore


class FakeGatewayClient:
    def __init__(self) -> None:
        self.chat_calls = []
        self.review_calls = []
        self.test_calls = []

    async def complete_json(self, provider, messages, *, json_schema):
        self.review_calls.append(
            {"provider": provider, "messages": messages, "json_schema": json_schema}
        )
        return "{}"

    async def test_provider(self, provider):
        self.test_calls.append(provider)
        return ProviderTestResult(ok=True, message="ok")

    async def chat_completion(self, provider, payload):
        self.chat_calls.append({"provider": provider, "payload": payload})
        return {
            "id": "chatcmpl-test",
            "object": "chat.completion",
            "created": 0,
            "model": provider.model,
            "choices": [
                {
                    "index": 0,
                    "message": {"role": "assistant", "content": "ok"},
                    "finish_reason": "stop",
                }
            ],
        }


class FailingPipeline:
    def redact(self, text: str, mode: str = "balanced", **_kwargs):
        raise RuntimeError(f"redaction failed for {text}")


def test_gateway_settings_default_to_loopback_disabled(tmp_path) -> None:
    client, _fake = _client(tmp_path)

    response = client.get("/gateway/settings")

    assert response.status_code == 200
    payload = response.json()
    assert payload["enabled"] is False
    assert payload["bind_host"] == "127.0.0.1"
    assert payload["redact_request_messages"] is True
    assert payload["allow_raw_text_to_upstream"] is False


def test_gateway_redacts_request_before_forwarding(tmp_path) -> None:
    client, fake = _client(tmp_path)
    provider_id = _configure_gateway(client)

    response = client.post(
        "/v1/chat/completions",
        json={
            "model": "client-model",
            "messages": [{"role": "user", "content": "Email ada@example.com."}],
            "temperature": 0.2,
            "stream": False,
        },
    )

    assert response.status_code == 200
    assert fake.chat_calls
    call = fake.chat_calls[0]
    assert call["provider"].id == provider_id
    assert call["payload"]["model"] == "test-model"
    assert call["payload"]["messages"] == [
        {"role": "user", "content": "Email [EMAIL]."}
    ]
    assert "ada@example.com" not in str(call["payload"])


def test_gateway_redacts_basic_multipart_text_parts(tmp_path) -> None:
    client, fake = _client(tmp_path)
    _configure_gateway(client)

    response = client.post(
        "/v1/chat/completions",
        json={
            "model": "client-model",
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": "Email ada@example.com."},
                        {"type": "text", "text": "Phone 555-123-4567."},
                    ],
                }
            ],
        },
    )

    assert response.status_code == 200
    forwarded = fake.chat_calls[0]["payload"]
    assert forwarded["messages"][0]["content"] == [
        {"type": "text", "text": "Email [EMAIL]."},
        {"type": "text", "text": "Phone [PHONE]."},
    ]
    assert "ada@example.com" not in str(forwarded)
    assert "555-123-4567" not in str(forwarded)


def test_gateway_blocks_external_raw_forwarding_by_default(tmp_path) -> None:
    client, fake = _client(tmp_path)
    provider_id = _create_provider(client, is_local=False)
    response = client.put(
        "/gateway/settings",
        json={
            "enabled": True,
            "bind_host": "127.0.0.1",
            "port": 8765,
            "upstream_provider_id": provider_id,
            "allow_raw_text_to_upstream": False,
            "redact_request_messages": False,
        },
    )
    assert response.status_code == 200

    response = client.post(
        "/v1/chat/completions",
        json={
            "model": "client-model",
            "messages": [{"role": "user", "content": "Email ada@example.com."}],
        },
    )

    assert response.status_code == 403
    assert not fake.chat_calls
    assert "ada@example.com" not in response.text


def test_gateway_rejects_non_openai_compatible_upstream(tmp_path) -> None:
    client, _fake = _client(tmp_path)
    provider_id = _create_provider(
        client,
        provider_type="ollama",
        is_local=True,
        base_url="http://127.0.0.1:11434",
        api_key=None,
    )

    response = client.put(
        "/gateway/settings",
        json={
            "enabled": True,
            "bind_host": "127.0.0.1",
            "port": 8765,
            "upstream_provider_id": provider_id,
            "allow_raw_text_to_upstream": False,
            "redact_request_messages": True,
        },
    )

    assert response.status_code == 400
    assert "OpenAI-compatible" in response.text


def test_gateway_logs_do_not_contain_raw_prompt(tmp_path, caplog) -> None:
    client, fake = _client(tmp_path)
    _configure_gateway(client)

    response = client.post(
        "/v1/chat/completions",
        json={
            "model": "client-model",
            "messages": [{"role": "user", "content": "Email ada@example.com."}],
        },
    )

    assert response.status_code == 200
    assert fake.chat_calls
    assert "ada@example.com" not in caplog.text


def test_gateway_preview_redacts_without_forwarding(tmp_path) -> None:
    client, fake = _client(tmp_path)
    _configure_gateway(client)

    response = client.post(
        "/gateway/preview",
        json={
            "model": "client-model",
            "messages": [{"role": "user", "content": "Email ada@example.com."}],
        },
    )

    assert response.status_code == 200
    payload = response.json()
    assert not fake.chat_calls
    assert payload["forwarded_request"]["messages"] == [
        {"role": "user", "content": "Email [EMAIL]."}
    ]
    assert payload["messages"][0]["summary"] == {"EMAIL": 1}
    assert "ada@example.com" not in response.text


def test_gateway_redaction_failure_fails_closed(tmp_path) -> None:
    client, fake = _client(tmp_path, redaction_pipeline=FailingPipeline())
    _configure_gateway(client)

    response = client.post(
        "/v1/chat/completions",
        json={
            "model": "client-model",
            "messages": [{"role": "user", "content": "Email ada@example.com."}],
        },
    )

    assert response.status_code == 500
    assert not fake.chat_calls
    assert "ada@example.com" not in response.text


def test_gateway_rejects_unsupported_multipart_content(tmp_path) -> None:
    client, fake = _client(tmp_path)
    _configure_gateway(client)

    response = client.post(
        "/v1/chat/completions",
        json={
            "model": "client-model",
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image_url",
                            "image_url": {"url": "data:image/png;base64,abc"},
                        }
                    ],
                }
            ],
        },
    )

    assert response.status_code == 400
    assert not fake.chat_calls
    assert "data:image" not in response.text


def _client(tmp_path, redaction_pipeline=None) -> tuple[TestClient, FakeGatewayClient]:
    fake = FakeGatewayClient()
    store = ModelProviderStore(
        tmp_path / "models.json",
        secret_store=InMemorySecretStore(),
    )
    app = create_app(
        settings=WorkerSettings(),
        profile_store=ProfileStore(tmp_path / "profile.json"),
        model_provider_store=store,
        model_client=fake,
        redaction_pipeline=redaction_pipeline,
    )
    return TestClient(app), fake


def _configure_gateway(client: TestClient) -> str:
    provider_id = _create_provider(client)
    response = client.put(
        "/gateway/settings",
        json={
            "enabled": True,
            "bind_host": "127.0.0.1",
            "port": 8765,
            "upstream_provider_id": provider_id,
            "allow_raw_text_to_upstream": False,
            "redact_request_messages": True,
        },
    )
    assert response.status_code == 200
    return provider_id


def _create_provider(
    client: TestClient,
    *,
    provider_type: str = "openai_compatible",
    is_local: bool = True,
    base_url: str = "http://127.0.0.1:1234/v1",
    api_key: str | None = "sk-test-123",
) -> str:
    response = client.post(
        "/models/providers",
        json={
            "name": "Gateway Provider",
            "provider_type": provider_type,
            "base_url": base_url,
            "api_key": api_key,
            "model": "test-model",
            "is_local": is_local,
            "supports_json_mode": True,
            "timeout": 10,
            "max_tokens": 300,
        },
    )
    assert response.status_code == 200
    return response.json()["id"]
