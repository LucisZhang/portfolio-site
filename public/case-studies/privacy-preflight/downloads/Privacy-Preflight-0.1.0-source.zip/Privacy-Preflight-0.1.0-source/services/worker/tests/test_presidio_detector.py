from __future__ import annotations

from dataclasses import dataclass

from app.config import WorkerSettings, load_settings
from app.redaction import TextRedactionPipeline
from app.redaction.detectors import DetectionCandidate, RedactionMode
from app.redaction.presidio import PresidioDetector


@dataclass(frozen=True)
class FakePresidioResult:
    entity_type: str
    start: int
    end: int
    score: float
    recognition_metadata: dict[str, str] | None = None


class FakeAnalyzer:
    def __init__(self, results: list[FakePresidioResult]) -> None:
        self.results = results
        self.calls: list[dict[str, object]] = []

    def analyze(
        self,
        *,
        text: str,
        language: str,
        entities: list[str] | None,
        score_threshold: float,
    ) -> list[FakePresidioResult]:
        self.calls.append(
            {
                "text": text,
                "language": language,
                "entities": entities,
                "score_threshold": score_threshold,
            }
        )
        return self.results


class StaticDetector:
    name = "static"

    def __init__(self, candidates: list[DetectionCandidate]) -> None:
        self.candidates = candidates

    def detect(self, text: str, mode: RedactionMode) -> list[DetectionCandidate]:
        return self.candidates


def test_presidio_detector_maps_analyzer_results_to_entities() -> None:
    text = "Email Ada Lovelace tomorrow."
    start = text.index("Ada Lovelace")
    fake_analyzer = FakeAnalyzer(
        [
            FakePresidioResult(
                entity_type="PERSON",
                start=start,
                end=start + len("Ada Lovelace"),
                score=0.87,
                recognition_metadata={"recognizer_name": "SpacyRecognizer"},
            )
        ]
    )

    detector = PresidioDetector(analyzer=fake_analyzer)
    result = TextRedactionPipeline(detectors=[detector]).redact(text)

    assert result.redacted_text == "Email [PERSON] tomorrow."
    assert result.summary == {"PERSON": 1}
    assert len(result.entities) == 1

    entity = result.entities[0]
    assert entity.type == "PERSON"
    assert entity.source == "presidio"
    assert entity.start == start
    assert entity.end == start + len("Ada Lovelace")
    assert entity.confidence == 0.87
    assert "SpacyRecognizer" in entity.reason
    assert fake_analyzer.calls[0]["language"] == "en"


def test_regex_and_presidio_overlap_resolves_to_higher_confidence_entity() -> None:
    text = "Email ada@example.com now."
    start = text.index("ada@example.com")
    fake_analyzer = FakeAnalyzer(
        [
            FakePresidioResult(
                entity_type="EMAIL_ADDRESS",
                start=start,
                end=start + len("ada@example.com"),
                score=0.8,
            )
        ]
    )

    result = TextRedactionPipeline(
        enable_presidio=True,
        presidio_detector=PresidioDetector(analyzer=fake_analyzer),
    ).redact(text)

    assert result.redacted_text == "Email [EMAIL] now."
    assert result.summary == {"EMAIL": 1}
    assert len(result.entities) == 1
    assert result.entities[0].type == "EMAIL"
    assert result.entities[0].source == "regex:email"


def test_presidio_can_be_disabled_by_settings() -> None:
    text = "Email Ada Lovelace tomorrow."
    start = text.index("Ada Lovelace")
    fake_analyzer = FakeAnalyzer(
        [
            FakePresidioResult(
                entity_type="PERSON",
                start=start,
                end=start + len("Ada Lovelace"),
                score=0.9,
            )
        ]
    )

    pipeline = TextRedactionPipeline.from_settings(
        WorkerSettings(enable_presidio=False),
        presidio_detector=PresidioDetector(analyzer=fake_analyzer),
    )
    result = pipeline.redact(text)

    assert result.redacted_text == text
    assert result.entities == []
    assert fake_analyzer.calls == []


def test_presidio_settings_are_loaded_from_environment(monkeypatch) -> None:
    monkeypatch.setenv("PRIVACY_PREFLIGHT_ENABLE_PRESIDIO", "true")
    monkeypatch.setenv("PRIVACY_PREFLIGHT_PRESIDIO_LANGUAGE", "en")
    monkeypatch.setenv("PRIVACY_PREFLIGHT_PRESIDIO_SCORE_THRESHOLD", "0.42")

    settings = load_settings()

    assert settings.enable_presidio is True
    assert settings.presidio_language == "en"
    assert settings.presidio_score_threshold == 0.42


def test_presidio_overlap_does_not_replace_regex_api_key_detection() -> None:
    text = "OPENAI_API_KEY=fixture-key-0000000000000000"
    fake_analyzer = FakeAnalyzer(
        [
            FakePresidioResult(
                entity_type="PERSON",
                start=0,
                end=len(text),
                score=0.99,
            )
        ]
    )

    result = TextRedactionPipeline(
        enable_presidio=True,
        presidio_detector=PresidioDetector(analyzer=fake_analyzer),
    ).redact(text)

    assert result.redacted_text == "OPENAI_API_KEY=[API_KEY]"
    assert result.summary == {"API_KEY": 1}
    assert len(result.entities) == 1
    assert result.entities[0].type == "API_KEY"
    assert result.entities[0].source.startswith("regex:")


def test_allowlist_candidate_suppresses_overlapping_redaction_candidate() -> None:
    text = "Email ada@example.com now."
    start = text.index("ada@example.com")
    end = start + len("ada@example.com")
    pipeline = TextRedactionPipeline(
        detectors=[
            StaticDetector(
                [
                    DetectionCandidate(
                        type="EMAIL",
                        start=start,
                        end=end,
                        confidence=0.99,
                        source="presidio",
                        reason="Presidio analyzer detected EMAIL_ADDRESS.",
                    ),
                    DetectionCandidate(
                        type="ALLOW",
                        start=start,
                        end=end,
                        confidence=1.0,
                        source="allowlist:test",
                        reason="Matched a future allowlist entry.",
                    ),
                ]
            )
        ]
    )

    result = pipeline.redact(text)

    assert result.redacted_text == text
    assert result.entities == []
