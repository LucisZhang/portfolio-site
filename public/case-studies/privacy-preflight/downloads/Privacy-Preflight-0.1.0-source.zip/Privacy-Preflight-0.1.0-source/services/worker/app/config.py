from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class WorkerSettings:
    enable_presidio: bool = False
    presidio_language: str = "en"
    presidio_score_threshold: float = 0.35
    enable_privacy_filter: bool = False
    privacy_filter_model_path: str | None = None
    privacy_filter_model_id: str | None = None
    privacy_filter_runtime: str = "opf"
    privacy_filter_device: str = "cpu"
    enable_chinese_ner: bool = True
    chinese_ner_provider: str = "dictionary_only"
    chinese_ner_model_path: str | None = None
    dictionary_path: str | None = None
    image_ocr_provider: str = "auto"
    max_image_bytes: int = 15 * 1024 * 1024
    max_pdf_bytes: int = 50 * 1024 * 1024
    app_data_dir: str | None = None
    profile_path: str | None = None
    model_provider_path: str | None = None


def load_settings() -> WorkerSettings:
    return WorkerSettings(
        enable_presidio=_read_bool("PRIVACY_PREFLIGHT_ENABLE_PRESIDIO", default=False),
        presidio_language=os.getenv("PRIVACY_PREFLIGHT_PRESIDIO_LANGUAGE", "en"),
        presidio_score_threshold=_read_float(
            "PRIVACY_PREFLIGHT_PRESIDIO_SCORE_THRESHOLD",
            default=0.35,
        ),
        enable_privacy_filter=_read_bool(
            "PRIVACY_PREFLIGHT_ENABLE_PRIVACY_FILTER",
            default=False,
        ),
        privacy_filter_model_path=os.getenv("PRIVACY_PREFLIGHT_PRIVACY_FILTER_MODEL_PATH"),
        privacy_filter_model_id=os.getenv("PRIVACY_PREFLIGHT_PRIVACY_FILTER_MODEL_ID"),
        privacy_filter_runtime=_read_provider(
            "PRIVACY_PREFLIGHT_PRIVACY_FILTER_RUNTIME",
            default="opf",
            allowed={"opf"},
        ),
        privacy_filter_device=_read_provider(
            "PRIVACY_PREFLIGHT_PRIVACY_FILTER_DEVICE",
            default="cpu",
            allowed={"cpu", "cuda"},
        ),
        enable_chinese_ner=_read_bool(
            "PRIVACY_PREFLIGHT_ENABLE_CHINESE_NER",
            default=True,
        ),
        chinese_ner_provider=_read_provider(
            "PRIVACY_PREFLIGHT_CHINESE_NER_PROVIDER",
            default="dictionary_only",
            allowed={"hanlp", "lac", "ltp", "dictionary_only"},
        ),
        chinese_ner_model_path=os.getenv(
            "PRIVACY_PREFLIGHT_CHINESE_NER_MODEL_PATH"
        ),
        dictionary_path=os.getenv("PRIVACY_PREFLIGHT_DICTIONARY_PATH"),
        image_ocr_provider=_read_provider(
            "PRIVACY_PREFLIGHT_IMAGE_OCR_PROVIDER",
            default="auto",
            allowed={"auto", "vision", "tesseract", "pytesseract", "none"},
        ),
        max_image_bytes=_read_int(
            "PRIVACY_PREFLIGHT_MAX_IMAGE_BYTES",
            default=15 * 1024 * 1024,
        ),
        max_pdf_bytes=_read_int(
            "PRIVACY_PREFLIGHT_MAX_PDF_BYTES",
            default=50 * 1024 * 1024,
        ),
        app_data_dir=os.getenv("PRIVACY_PREFLIGHT_APP_DATA_DIR"),
        profile_path=os.getenv("PRIVACY_PREFLIGHT_PROFILE_PATH"),
        model_provider_path=os.getenv("PRIVACY_PREFLIGHT_MODEL_PROVIDER_PATH"),
    )


def _read_bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _read_float(name: str, default: float) -> float:
    value = os.getenv(name)
    if value is None:
        return default
    try:
        return float(value)
    except ValueError:
        return default


def _read_int(name: str, default: int) -> int:
    value = os.getenv(name)
    if value is None:
        return default
    try:
        parsed = int(value)
    except ValueError:
        return default
    return parsed if parsed > 0 else default


def _read_provider(name: str, default: str, allowed: set[str]) -> str:
    value = os.getenv(name)
    if value is None:
        return default
    normalized = value.strip().lower()
    if normalized not in allowed:
        return default
    return normalized
