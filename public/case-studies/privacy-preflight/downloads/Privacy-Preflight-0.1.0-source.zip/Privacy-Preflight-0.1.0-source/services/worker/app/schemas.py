import re
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


ProfileRuleAction = Literal["mask", "ask", "allow"]
ProfileRuleScope = Literal["global", "text"]
ModelProviderType = Literal["ollama", "openai_compatible", "lm_studio"]
ReviewRiskLevel = Literal["low", "medium", "high"]
RevisionIntent = Literal[
    "mask",
    "allow",
    "ask",
    "change_replacement",
    "add_to_profile",
]
RevisionScope = Literal["current_document", "profile"]
ImageRedactionMode = Literal["safe_text", "precise"]
PDFDocumentType = Literal["text", "scanned", "mixed"]
PDFValidationStatus = Literal["passed", "warning", "failed"]


_ENTITY_TYPE_RE = re.compile(r"^[A-Z][A-Z0-9_]{1,63}$")
_PLACEHOLDER_RE = re.compile(r"^\[[A-Z][A-Z0-9_]{1,63}\]$")


def _is_entity_type(value: str) -> bool:
    return bool(_ENTITY_TYPE_RE.match(value))


def _normalize_placeholder(value: str) -> str | None:
    stripped = value.strip()
    if _PLACEHOLDER_RE.match(stripped):
        return stripped

    normalized = re.sub(r"[^A-Za-z0-9]+", "_", stripped).strip("_").upper()
    if _is_entity_type(normalized):
        return f"[{normalized}]"
    return None


class HealthResponse(BaseModel):
    status: str = Field(description="Worker health status.")


class LocalDataPath(BaseModel):
    label: str
    path: str
    exists: bool
    contains_raw_content_by_design: bool = False


class LocalDataSummaryResponse(BaseModel):
    app_data_dir: str
    profile_path: str
    model_provider_path: str
    worker_log_dir: str
    temp_dir: str
    history_enabled: bool = False
    paths: list[LocalDataPath]


class PrivacyDiagnosticsResponse(BaseModel):
    status: str = "ok"
    app_data_dir: str
    profile_rule_count: int
    model_provider_count: int
    llm_review_enabled: bool
    external_raw_text_enabled: bool
    gateway_enabled: bool
    gateway_bind_host: str
    gateway_redacts_requests: bool
    history_enabled: bool = False
    paths: list[LocalDataPath]
    notes: list[str] = Field(default_factory=list)


class ClearLocalDataRequest(BaseModel):
    clear_profile: bool = True
    clear_model_provider_settings: bool = True
    clear_keychain_api_keys: bool = False


class ClearLocalDataResponse(BaseModel):
    cleared_paths: list[str] = Field(default_factory=list)
    skipped_paths: list[str] = Field(default_factory=list)
    keychain_entries_cleared: int = 0
    message: str


class TextRedactionRequest(BaseModel):
    text: str = Field(description="Raw text to redact locally.")
    mode: Literal["balanced", "strict"] = Field(
        default="balanced",
        description="Balanced favors high-confidence matches; strict adds broader ID-like matches.",
    )


class TextReviewRequest(TextRedactionRequest):
    provider_id: str | None = Field(
        default=None,
        description="Optional review provider id. Defaults to the configured review provider.",
    )
    enable_llm_review: bool | None = Field(
        default=None,
        description="Optional per-request override for model review.",
    )
    allow_raw_text_for_external_models: bool | None = Field(
        default=None,
        description=(
            "Explicit opt-in override for sending original text to non-local providers."
        ),
    )


class RedactionEntity(BaseModel):
    id: str
    text: str
    type: str
    start: int
    end: int
    confidence: float = Field(ge=0, le=1)
    source: str
    action: Literal["replace", "mask", "ask", "allow"] = "replace"
    replacement: str
    reason: str
    profile_rule_id: str | None = None


class TextRedactionResponse(BaseModel):
    redacted_text: str
    entities: list[RedactionEntity]
    summary: dict[str, int]


class ImageRectangle(BaseModel):
    x: float = Field(ge=0)
    y: float = Field(ge=0)
    width: float = Field(gt=0)
    height: float = Field(gt=0)


class ImageOCRBox(ImageRectangle):
    id: str
    text: str
    confidence: float = Field(ge=0, le=1)
    source: str


class ImageRedactedBox(ImageRectangle):
    id: str
    source: str
    reason: str
    ocr_box_id: str | None = None
    text: str | None = None
    confidence: float | None = Field(default=None, ge=0, le=1)
    entity_types: list[str] = Field(default_factory=list)
    text_sources: list[str] = Field(default_factory=list)


class ImageRedactionResponse(BaseModel):
    mode: ImageRedactionMode
    image_width: int
    image_height: int
    input_format: str
    output_format: str
    media_type: str
    ocr_provider: str
    ocr_boxes: list[ImageOCRBox]
    redacted_boxes: list[ImageRedactedBox]
    summary: dict[str, int]
    redacted_image_base64: str


class PDFManualRectangle(ImageRectangle):
    page_index: int = Field(ge=0)


class PDFPagePreview(BaseModel):
    page_index: int = Field(ge=0)
    width: float = Field(gt=0)
    height: float = Field(gt=0)
    image_width: int = Field(gt=0)
    image_height: int = Field(gt=0)
    media_type: str = "image/png"
    preview_image_base64: str


class PDFRedactionRegion(ImageRectangle):
    id: str
    page_index: int = Field(ge=0)
    source: str
    reason: str
    text: str | None = None
    confidence: float | None = Field(default=None, ge=0, le=1)
    entity_types: list[str] = Field(default_factory=list)
    text_sources: list[str] = Field(default_factory=list)


class PDFValidationResult(BaseModel):
    status: PDFValidationStatus
    safe: bool
    message: str
    redacted_text_absent: bool
    unapplied_redaction_annotations: bool
    checked_terms_count: int
    warnings: list[str] = Field(default_factory=list)


class PDFRedactionAnalysisResponse(BaseModel):
    document_type: PDFDocumentType
    page_count: int = Field(ge=0)
    pages: list[PDFPagePreview]
    redaction_regions: list[PDFRedactionRegion]
    summary: dict[str, int]
    warnings: list[str] = Field(default_factory=list)


class PDFRedactionExportResponse(PDFRedactionAnalysisResponse):
    validation: PDFValidationResult
    media_type: str = "application/pdf"
    redacted_pdf_base64: str


class ModelReviewMissedItem(BaseModel):
    model_config = ConfigDict(extra="forbid")

    text: str = Field(min_length=1, max_length=512)
    entity_type: str = Field(min_length=1, max_length=64)
    replacement: str | None = None
    reason: str | None = None

    @field_validator("text", "entity_type", "replacement", "reason", mode="before")
    @classmethod
    def _strip_strings(cls, value: object) -> object:
        if isinstance(value, str):
            stripped = value.strip()
            return stripped or None
        return value

    @model_validator(mode="after")
    def _normalize_entity(self) -> "ModelReviewMissedItem":
        self.entity_type = self.entity_type.strip().upper()
        return self


class ModelReviewFalsePositive(BaseModel):
    model_config = ConfigDict(extra="forbid")

    entity_id: str | None = None
    text: str | None = None
    entity_type: str | None = None
    reason: str | None = None

    @field_validator("entity_id", "text", "entity_type", "reason", mode="before")
    @classmethod
    def _strip_optional_strings(cls, value: object) -> object:
        if isinstance(value, str):
            stripped = value.strip()
            return stripped or None
        return value


class ModelSuggestedPolicyUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    entity_type: str | None = None
    pattern: str | None = None
    replacement: str | None = None
    action: ProfileRuleAction | None = None
    reason: str | None = None

    @field_validator(
        "entity_type",
        "pattern",
        "replacement",
        "reason",
        mode="before",
    )
    @classmethod
    def _strip_optional_strings(cls, value: object) -> object:
        if isinstance(value, str):
            stripped = value.strip()
            return stripped or None
        return value

    @field_validator("entity_type", mode="after")
    @classmethod
    def _uppercase_entity_type(cls, value: str | None) -> str | None:
        return value.upper() if value else value


class ModelReviewSuggestion(BaseModel):
    model_config = ConfigDict(extra="forbid")

    pass_: bool = Field(alias="pass")
    risk_level: ReviewRiskLevel
    missed_items: list[ModelReviewMissedItem] = Field(default_factory=list)
    false_positives: list[ModelReviewFalsePositive] = Field(default_factory=list)
    suggested_policy_updates: list[ModelSuggestedPolicyUpdate] = Field(
        default_factory=list
    )


class AppliedReviewSuggestion(BaseModel):
    text: str
    entity_type: str
    replacement: str
    occurrence_count: int


class ModelReviewResult(BaseModel):
    provider_id: str | None = None
    provider_name: str | None = None
    provider_is_local: bool = True
    raw_text_sent: bool = False
    raw_text_blocked: bool = False
    warning: str | None = None
    parsed: bool = True
    parse_error: str | None = None
    suggestion: ModelReviewSuggestion | None = None
    applied_missed_items: list[AppliedReviewSuggestion] = Field(default_factory=list)
    invalid_suggestions: list[str] = Field(default_factory=list)


class TextReviewResponse(BaseModel):
    initial_result: TextRedactionResponse
    review_result: ModelReviewResult | None
    final_result: TextRedactionResponse


class RevisionCommand(BaseModel):
    model_config = ConfigDict(extra="forbid")

    intent: RevisionIntent
    target_text: str | None = Field(default=None, max_length=512)
    target_entity_id: str | None = Field(default=None, max_length=64)
    entity_type: str | None = Field(default=None, min_length=1, max_length=64)
    replacement: str | None = Field(default=None, max_length=80)
    action: ProfileRuleAction | None = None
    scope: RevisionScope = "current_document"
    reason: str | None = Field(default=None, max_length=500)

    @field_validator(
        "target_text",
        "target_entity_id",
        "entity_type",
        "replacement",
        "reason",
        mode="before",
    )
    @classmethod
    def _strip_optional_command_string(cls, value: object) -> object:
        if isinstance(value, str):
            stripped = value.strip()
            return stripped or None
        return value

    @field_validator("entity_type", mode="after")
    @classmethod
    def _normalize_entity_type(cls, value: str | None) -> str | None:
        if value is None:
            return None
        normalized = "_".join(value.upper().split())
        if not _is_entity_type(normalized):
            raise ValueError("entity_type must be an uppercase-style identifier.")
        return normalized

    @field_validator("replacement", mode="after")
    @classmethod
    def _normalize_replacement(cls, value: str | None) -> str | None:
        if value is None:
            return None
        normalized = _normalize_placeholder(value)
        if normalized is None:
            raise ValueError("replacement must be a bracket placeholder.")
        return normalized

    @model_validator(mode="after")
    def _validate_command_target(self) -> "RevisionCommand":
        has_target = bool(self.target_text or self.target_entity_id or self.entity_type)
        if not has_target:
            raise ValueError(
                "Revision command requires target_text, target_entity_id, or entity_type."
            )
        if self.intent == "change_replacement" and not self.replacement:
            raise ValueError("change_replacement requires replacement.")
        return self


class RevisionParseRequest(TextRedactionRequest):
    instruction: str = Field(min_length=1, max_length=2000)
    scope: RevisionScope = "current_document"
    selected_entity_id: str | None = Field(default=None, max_length=64)
    provider_id: str | None = Field(default=None, max_length=128)
    enable_model_parsing: bool | None = None
    allow_raw_text_for_external_models: bool | None = Field(default=None)


class RevisionParseResult(BaseModel):
    parser: Literal["deterministic", "model"]
    provider_id: str | None = None
    provider_name: str | None = None
    provider_is_local: bool = True
    raw_text_sent: bool = False
    raw_text_blocked: bool = False
    warning: str | None = None
    parsed: bool = True
    parse_error: str | None = None
    commands: list[RevisionCommand] = Field(default_factory=list)
    invalid_commands: list[str] = Field(default_factory=list)


class RevisionParseResponse(BaseModel):
    initial_result: TextRedactionResponse
    parse_result: RevisionParseResult


class TextRevisionRequest(RevisionParseRequest):
    commands: list[RevisionCommand] | None = None


class AppliedRevisionCommand(BaseModel):
    command: RevisionCommand
    occurrence_count: int = 0
    profile_rule_ids: list[str] = Field(default_factory=list)
    updated_profile_rule_ids: list[str] = Field(default_factory=list)
    skipped_reason: str | None = None


class ModelProviderPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1)
    provider_type: ModelProviderType
    base_url: str = Field(min_length=1)
    api_key: str | None = Field(default=None, repr=False)
    model: str = Field(min_length=1)
    is_local: bool
    supports_json_mode: bool = True
    timeout: float = Field(default=30, gt=0, le=300)
    max_tokens: int = Field(default=800, gt=0, le=8192)

    @field_validator("name", "provider_type", "base_url", "api_key", "model", mode="before")
    @classmethod
    def _strip_provider_strings(cls, value: object) -> object:
        if isinstance(value, str):
            stripped = value.strip()
            return stripped or None
        return value

    @field_validator("base_url", mode="after")
    @classmethod
    def _validate_http_url(cls, value: str) -> str:
        if not (value.startswith("http://") or value.startswith("https://")):
            raise ValueError("base_url must start with http:// or https://.")
        return value.rstrip("/")


class ModelProvider(ModelProviderPayload):
    id: str = Field(min_length=1)
    api_key: str | None = Field(default=None, exclude=True, repr=False)
    api_key_configured: bool = False
    created_at: str
    updated_at: str


class ModelProviderListResponse(BaseModel):
    providers: list[ModelProvider]


class ModelProviderTestResponse(BaseModel):
    provider_id: str
    ok: bool
    message: str


class ModelReviewSettings(BaseModel):
    model_config = ConfigDict(extra="forbid")

    enable_llm_review: bool = False
    selected_review_provider_id: str | None = None
    allow_raw_text_for_external_models: bool = False


class GatewaySettings(BaseModel):
    model_config = ConfigDict(extra="forbid")

    enabled: bool = False
    bind_host: str = Field(default="127.0.0.1", min_length=1, max_length=255)
    port: int = Field(default=8765, ge=1, le=65535)
    upstream_provider_id: str | None = None
    allow_raw_text_to_upstream: bool = False
    redact_request_messages: bool = True

    @field_validator("bind_host", "upstream_provider_id", mode="before")
    @classmethod
    def _strip_gateway_strings(cls, value: object) -> object:
        if isinstance(value, str):
            stripped = value.strip()
            return stripped or None
        return value


class GatewayRedactionEntity(BaseModel):
    id: str
    type: str
    start: int
    end: int
    confidence: float = Field(ge=0, le=1)
    source: str
    action: Literal["replace", "mask", "ask", "allow"] = "replace"
    replacement: str
    profile_rule_id: str | None = None


class GatewayMessageRedactionSummary(BaseModel):
    index: int
    role: str | None = None
    text_part_count: int
    entities: list[GatewayRedactionEntity] = Field(default_factory=list)
    summary: dict[str, int] = Field(default_factory=dict)


class GatewayPreviewResponse(BaseModel):
    gateway_enabled: bool
    endpoint_url: str
    upstream_provider_id: str | None = None
    upstream_provider_name: str | None = None
    upstream_provider_is_local: bool | None = None
    raw_text_sent: bool = False
    raw_text_blocked: bool = False
    warning: str | None = None
    forwarded_request: dict[str, Any]
    messages: list[GatewayMessageRedactionSummary] = Field(default_factory=list)


class ProfileLearningRequest(BaseModel):
    text: str = Field(description="Raw sample text to inspect locally.")
    mode: Literal["balanced", "strict"] = Field(
        default="balanced",
        description="Balanced favors high-confidence matches; strict adds broader ID-like matches.",
    )


class ProfileLearningCandidate(BaseModel):
    id: str
    suggested_entity_type: str = Field(min_length=1)
    pattern: str = Field(min_length=1)
    aliases: list[str] = Field(default_factory=list)
    replacement: str = Field(min_length=1)
    suggested_action: ProfileRuleAction = "mask"
    source_detector: str = Field(min_length=1)
    confidence: float = Field(ge=0, le=1)
    reason: str = Field(min_length=1)


class ProfileLearningResponse(BaseModel):
    candidates: list[ProfileLearningCandidate]


class ProfileRulePayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    label: str = Field(min_length=1)
    entity_type: str = Field(min_length=1)
    patterns: list[str] = Field(default_factory=list)
    aliases: list[str] = Field(default_factory=list)
    replacement: str | None = None
    action: ProfileRuleAction = "mask"
    enabled: bool = True
    scope: ProfileRuleScope = "global"

    @field_validator("label", "entity_type", mode="before")
    @classmethod
    def _strip_required_string(cls, value: object) -> object:
        if isinstance(value, str):
            return value.strip()
        return value

    @field_validator("replacement", mode="before")
    @classmethod
    def _strip_optional_string(cls, value: object) -> object:
        if value is None:
            return None
        if isinstance(value, str):
            stripped = value.strip()
            return stripped or None
        return value

    @field_validator("patterns", "aliases", mode="after")
    @classmethod
    def _strip_and_dedupe_terms(cls, values: list[str]) -> list[str]:
        normalized: list[str] = []
        seen: set[str] = set()
        for value in values:
            if not isinstance(value, str):
                continue
            term = value.strip()
            if not term:
                continue
            dedupe_key = term.casefold()
            if dedupe_key in seen:
                continue
            seen.add(dedupe_key)
            normalized.append(term)
        return normalized

    @model_validator(mode="after")
    def _require_match_terms(self) -> "ProfileRulePayload":
        if not self.patterns and not self.aliases:
            raise ValueError("Profile rule requires at least one pattern or alias.")
        return self


class ProfileRule(ProfileRulePayload):
    id: str = Field(min_length=1)
    replacement: str = Field(min_length=1)
    created_at: str
    updated_at: str


class Profile(BaseModel):
    model_config = ConfigDict(extra="forbid")

    version: Literal[1] = 1
    rules: list[ProfileRule] = Field(default_factory=list)


class TextRevisionResponse(BaseModel):
    initial_result: TextRedactionResponse
    parse_result: RevisionParseResult
    final_result: TextRedactionResponse
    applied_commands: list[AppliedRevisionCommand] = Field(default_factory=list)
    profile_rules: list[ProfileRule] = Field(default_factory=list)
