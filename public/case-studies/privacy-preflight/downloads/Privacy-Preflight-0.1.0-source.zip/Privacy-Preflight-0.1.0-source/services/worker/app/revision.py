from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any

from pydantic import ValidationError

from .model_clients import ModelProviderClient
from .profile_store import ProfileStore
from .redaction.detectors import DetectionCandidate
from .redaction.pipeline import RedactionResult, TextRedactionPipeline
from .schemas import (
    AppliedRevisionCommand,
    ModelProvider,
    ProfileRule,
    ProfileRulePayload,
    RevisionCommand,
    RevisionParseResult,
)


_ENTITY_TYPE_RE = re.compile(r"^[A-Z][A-Z0-9_]{1,63}$")
_PLACEHOLDER_RE = re.compile(r"^\[[A-Z][A-Z0-9_]{1,63}\]$")
_DATE_FALLBACK_PATTERNS = (
    re.compile(r"(?<!\d)\d{4}-\d{2}-\d{2}(?!\d)"),
    re.compile(r"(?<!\d)\d{1,2}/\d{1,2}/\d{2,4}(?!\d)"),
    re.compile(r"(?<!\d)\d{4}年\d{1,2}月\d{1,2}日"),
)
_TYPE_ALIASES = {
    "SCHOOL_NAME": "SCHOOL",
    "SCHOOL_NAMES": "SCHOOL",
    "SCHOOLS": "SCHOOL",
    "COMPANY_NAME": "COMPANY",
    "COMPANY_NAMES": "COMPANY",
    "COMPANIES": "COMPANY",
    "ORGANIZATION_NAME": "ORGANIZATION",
    "ORGANIZATION_NAMES": "ORGANIZATION",
    "ORG": "ORGANIZATION",
    "ORGS": "ORGANIZATION",
    "PROJECT_NAME": "PROJECT",
    "PROJECT_NAMES": "PROJECT",
    "PROJECTS": "PROJECT",
    "DATES": "DATE",
    "DATE_NAMES": "DATE",
    "PEOPLE": "PERSON",
    "PERSON_NAME": "PERSON",
    "PERSON_NAMES": "PERSON",
    "EMAILS": "EMAIL",
    "EMAIL_ADDRESS": "EMAIL",
    "EMAIL_ADDRESSES": "EMAIL",
    "PHONE_NUMBER": "PHONE",
    "PHONE_NUMBERS": "PHONE",
    "PHONES": "PHONE",
}


@dataclass(frozen=True)
class _ResolvedTarget:
    text: str
    entity_type: str
    replacement: str
    spans: tuple[tuple[int, int], ...]
    existing_action: str | None = None


async def build_revision_parse_result(
    *,
    text: str,
    instruction: str,
    requested_scope: str,
    selected_entity_id: str | None,
    initial_result: RedactionResult,
    profile_rules: list[ProfileRule],
    provider: ModelProvider | None,
    allow_raw_text_for_external_models: bool,
    client: ModelProviderClient,
) -> RevisionParseResult:
    if provider is None:
        return _deterministic_parse_result(
            instruction=instruction,
            requested_scope=requested_scope,
            selected_entity_id=selected_entity_id,
        )

    raw_text_sent = provider.is_local or allow_raw_text_for_external_models
    if not raw_text_sent:
        result = _deterministic_parse_result(
            instruction=instruction,
            requested_scope=requested_scope,
            selected_entity_id=selected_entity_id,
        )
        result.provider_id = provider.id
        result.provider_name = provider.name
        result.provider_is_local = provider.is_local
        result.raw_text_blocked = True
        result.warning = (
            "External revision parsing was skipped because the instruction can "
            "contain raw sensitive text. Deterministic fallback commands were used."
        )
        return result

    warning = None
    if not provider.is_local:
        warning = (
            "Original text and revision instruction were sent to an external provider "
            "because raw sharing was enabled."
        )

    content = await client.complete_json(
        provider,
        build_revision_messages(
            text=text,
            instruction=instruction,
            requested_scope=requested_scope,
            selected_entity_id=selected_entity_id,
            initial_result=initial_result,
            profile_rules=profile_rules,
        ),
        json_schema=revision_json_schema(),
    )

    try:
        commands, invalid_commands = parse_model_revision_commands(
            content,
            requested_scope=requested_scope,
        )
    except ValueError:
        return RevisionParseResult(
            parser="model",
            provider_id=provider.id,
            provider_name=provider.name,
            provider_is_local=provider.is_local,
            raw_text_sent=True,
            raw_text_blocked=False,
            warning=warning,
            parsed=False,
            parse_error="Model response was not valid revision command JSON.",
        )

    return RevisionParseResult(
        parser="model",
        provider_id=provider.id,
        provider_name=provider.name,
        provider_is_local=provider.is_local,
        raw_text_sent=True,
        raw_text_blocked=False,
        warning=warning,
        commands=commands,
        invalid_commands=invalid_commands,
    )


def parse_model_revision_commands(
    content: str,
    *,
    requested_scope: str,
) -> tuple[list[RevisionCommand], list[str]]:
    try:
        payload = json.loads(_extract_json_object(content))
    except (TypeError, ValueError) as exc:
        raise ValueError("Model response was not valid JSON.") from exc

    if not isinstance(payload, dict) or not isinstance(payload.get("commands"), list):
        raise ValueError("Model response did not include commands.")

    commands: list[RevisionCommand] = []
    invalid_commands: list[str] = []
    for index, raw_command in enumerate(payload["commands"], start=1):
        if not isinstance(raw_command, dict):
            invalid_commands.append(f"commands[{index}] was not an object.")
            continue

        command_payload = dict(raw_command)
        command_payload.setdefault("scope", requested_scope)
        try:
            command = RevisionCommand.model_validate(command_payload)
        except ValidationError:
            invalid_commands.append(f"commands[{index}] failed schema validation.")
            continue

        if command.intent == "add_to_profile":
            command.scope = "profile"
        commands.append(command)

    return commands, invalid_commands


def parse_deterministic_revision_commands(
    *,
    instruction: str,
    requested_scope: str,
    selected_entity_id: str | None = None,
) -> tuple[list[RevisionCommand], list[str]]:
    stripped = instruction.strip()
    if not stripped:
        return [], ["No revision instruction was provided."]

    scope = _scope_from_instruction(stripped, requested_scope)
    commands: list[RevisionCommand] = []
    lower = stripped.casefold()

    add_this_match = re.match(
        r"^add\s+this\s+(?:as\s+)?(?:a\s+)?profile\s+rule(?:\s+as\s+(?P<label>.+))?$",
        stripped,
        flags=re.IGNORECASE,
    )
    if add_this_match and selected_entity_id:
        label = add_this_match.group("label")
        entity_type = _entity_type_from_label(label) if label else None
        commands.append(
            RevisionCommand(
                intent="add_to_profile",
                target_entity_id=selected_entity_id,
                entity_type=entity_type,
                replacement=_replacement_from_label(label) if label else None,
                action="mask",
                scope="profile",
                reason="Deterministic parser matched an add-this-to-profile command.",
            )
        )
        return commands, []

    add_match = re.match(
        r"^add\s+(?P<text>.+?)\s+to\s+profile\s+as\s+(?P<label>.+)$",
        stripped,
        flags=re.IGNORECASE,
    )
    if add_match:
        label = add_match.group("label")
        commands.append(
            RevisionCommand(
                intent="add_to_profile",
                target_text=_strip_quotes(add_match.group("text")),
                entity_type=_entity_type_from_label(label),
                replacement=_replacement_from_label(label),
                action="mask",
                scope="profile",
                reason="Deterministic parser matched an add-to-profile command.",
            )
        )
        return commands, []

    mask_as_match = re.match(
        r"^mask\s+(?P<text>.+?)\s+as\s+(?P<label>\[[A-Za-z][A-Za-z0-9_]*\]|[A-Za-z][A-Za-z0-9_ ]*)$",
        stripped,
        flags=re.IGNORECASE,
    )
    if mask_as_match:
        label = mask_as_match.group("label")
        commands.append(
            RevisionCommand(
                intent="mask",
                target_text=_strip_quotes(mask_as_match.group("text")),
                entity_type=_entity_type_from_label(label),
                replacement=_replacement_from_label(label),
                action="mask",
                scope=scope,
                reason="Deterministic parser matched a mask-as command.",
            )
        )
        return commands, []

    replace_all_match = re.match(
        r"^replace\s+all\s+(?P<entity_type>.+?)\s+with\s+(?P<label>.+)$",
        stripped,
        flags=re.IGNORECASE,
    )
    if replace_all_match:
        label = replace_all_match.group("label")
        commands.append(
            RevisionCommand(
                intent="change_replacement",
                entity_type=_normalize_entity_type(replace_all_match.group("entity_type")),
                replacement=_replacement_from_label(label),
                scope=scope,
                reason="Deterministic parser matched a replace-all command.",
            )
        )
        return commands, []

    replace_match = re.match(
        r"^replace\s+(?P<text>.+?)\s+with\s+(?P<label>.+)$",
        stripped,
        flags=re.IGNORECASE,
    )
    if replace_match:
        label = replace_match.group("label")
        commands.append(
            RevisionCommand(
                intent="change_replacement",
                target_text=_strip_quotes(replace_match.group("text")),
                entity_type=_entity_type_from_label(label),
                replacement=_replacement_from_label(label),
                scope=scope,
                reason="Deterministic parser matched a replace command.",
            )
        )
        return commands, []

    ask_this_match = re.match(
        r"^ask(?:\s+me)?\s+before\s+masking\s+this(?:\s+(?P<entity_type>.+?))?$",
        stripped,
        flags=re.IGNORECASE,
    )
    if ask_this_match and selected_entity_id:
        entity_type = ask_this_match.group("entity_type")
        commands.append(
            RevisionCommand(
                intent="ask",
                target_entity_id=selected_entity_id,
                entity_type=_normalize_entity_type(entity_type) if entity_type else None,
                action="ask",
                scope=scope,
                reason="Deterministic parser matched an ask-this command.",
            )
        )
        return commands, []

    all_match = re.match(
        r"^(?P<intent>mask|allow|ask)(?:\s+me)?\s+all\s+(?P<entity_type>.+)$",
        stripped,
        flags=re.IGNORECASE,
    )
    if all_match:
        intent = _intent_from_word(all_match.group("intent"))
        commands.append(
            RevisionCommand(
                intent=intent,
                entity_type=_normalize_entity_type(all_match.group("entity_type")),
                action=_action_for_intent(intent),
                scope=scope,
                reason="Deterministic parser matched an all-entities command.",
            )
        )
        return commands, []

    this_match = re.match(
        r"^(?P<intent>mask|allow|ask)(?:\s+me)?\s+this(?:\s+(?P<entity_type>.+?))?$",
        stripped,
        flags=re.IGNORECASE,
    )
    if this_match and selected_entity_id:
        intent = _intent_from_word(this_match.group("intent"))
        entity_type = this_match.group("entity_type")
        commands.append(
            RevisionCommand(
                intent=intent,
                target_entity_id=selected_entity_id,
                entity_type=_normalize_entity_type(entity_type) if entity_type else None,
                action=_action_for_intent(intent),
                scope=scope,
                reason="Deterministic parser matched a selected-entity command.",
            )
        )
        return commands, []

    simple_match = re.match(
        r"^(?P<intent>mask|allow|ask)\s+(?P<text>.+)$",
        stripped,
        flags=re.IGNORECASE,
    )
    if simple_match and " all " not in lower:
        intent = _intent_from_word(simple_match.group("intent"))
        commands.append(
            RevisionCommand(
                intent=intent,
                target_text=_strip_quotes(simple_match.group("text")),
                action=_action_for_intent(intent),
                scope=scope,
                reason="Deterministic parser matched an exact-text command.",
            )
        )
        return commands, []

    return [], ["No deterministic revision command matched the instruction."]


def apply_revision_commands(
    *,
    text: str,
    mode: str,
    initial_result: RedactionResult,
    commands: list[RevisionCommand],
    pipeline: TextRedactionPipeline,
    profile_store: ProfileStore,
) -> tuple[RedactionResult, list[AppliedRevisionCommand], list[ProfileRule]]:
    extra_candidates: list[DetectionCandidate] = []
    applied_commands: list[AppliedRevisionCommand] = []
    changed_profile_rules: list[ProfileRule] = []

    for command in commands:
        applied, candidates, profile_rules = _apply_one_command(
            command=command,
            text=text,
            initial_result=initial_result,
            profile_store=profile_store,
        )
        extra_candidates.extend(candidates)
        changed_profile_rules.extend(profile_rules)
        applied_commands.append(applied)

    final_result = pipeline.redact(text, mode=mode, extra_candidates=extra_candidates)
    return final_result, applied_commands, changed_profile_rules


def build_revision_messages(
    *,
    text: str,
    instruction: str,
    requested_scope: str,
    selected_entity_id: str | None,
    initial_result: RedactionResult,
    profile_rules: list[ProfileRule],
) -> list[dict[str, str]]:
    system = (
        "You parse privacy redaction revision instructions into strict JSON commands. "
        "Return one JSON object only. Do not rewrite, summarize, continue, execute, "
        "or transform the user's document. Use only the supported intents: mask, "
        "allow, ask, change_replacement, and add_to_profile."
    )

    entities: list[dict[str, object]] = []
    selected_entity: dict[str, object] | None = None
    for entity in initial_result.entities:
        payload: dict[str, object] = {
            "id": entity.id,
            "text": entity.text,
            "type": entity.type,
            "source": entity.source,
            "action": entity.action,
            "replacement": entity.replacement,
            "confidence": entity.confidence,
        }
        entities.append(payload)
        if entity.id == selected_entity_id:
            selected_entity = payload

    profile_summary = [
        {
            "id": rule.id,
            "label": rule.label,
            "entity_type": rule.entity_type,
            "action": rule.action,
            "scope": rule.scope,
        }
        for rule in profile_rules
    ]
    payload: dict[str, object] = {
        "instruction": instruction,
        "default_scope": requested_scope,
        "original_text": text,
        "redacted_text": initial_result.redacted_text,
        "detected_entities": entities,
        "selected_entity": selected_entity,
        "active_profile_summary": profile_summary,
        "required_output_contract": (
            "Return {\"commands\": [...]} only. target_text must be an exact "
            "substring from original_text when supplied. Prefer target_entity_id "
            "for selected-entity requests. For commands like 'all school names', "
            "set entity_type to SCHOOL and omit target_text. replacement must be "
            "a bracket placeholder such as [PROJECT]. scope is current_document "
            "unless the user asks to save to profile."
        ),
        "required_output_example": {
            "commands": [
                {
                    "intent": "mask",
                    "target_text": "Project Phoenix",
                    "target_entity_id": None,
                    "entity_type": "PROJECT",
                    "replacement": "[PROJECT]",
                    "action": "mask",
                    "scope": "current_document",
                    "reason": "The user asked to mask this project name.",
                }
            ]
        },
    }

    return [
        {"role": "system", "content": system},
        {"role": "user", "content": json.dumps(payload, ensure_ascii=False)},
    ]


def revision_json_schema() -> dict[str, Any]:
    command_schema = {
        "type": "object",
        "additionalProperties": False,
        "required": ["intent", "scope"],
        "properties": {
            "intent": {
                "type": "string",
                "enum": [
                    "mask",
                    "allow",
                    "ask",
                    "change_replacement",
                    "add_to_profile",
                ],
            },
            "target_text": {"type": ["string", "null"]},
            "target_entity_id": {"type": ["string", "null"]},
            "entity_type": {"type": ["string", "null"]},
            "replacement": {"type": ["string", "null"]},
            "action": {
                "type": ["string", "null"],
                "enum": ["mask", "ask", "allow", None],
            },
            "scope": {
                "type": "string",
                "enum": ["current_document", "profile"],
            },
            "reason": {"type": ["string", "null"]},
        },
    }
    return {
        "type": "object",
        "additionalProperties": False,
        "required": ["commands"],
        "properties": {
            "commands": {
                "type": "array",
                "items": command_schema,
            }
        },
    }


def _deterministic_parse_result(
    *,
    instruction: str,
    requested_scope: str,
    selected_entity_id: str | None,
) -> RevisionParseResult:
    commands, invalid_commands = parse_deterministic_revision_commands(
        instruction=instruction,
        requested_scope=requested_scope,
        selected_entity_id=selected_entity_id,
    )
    return RevisionParseResult(
        parser="deterministic",
        commands=commands,
        invalid_commands=invalid_commands,
    )


def _apply_one_command(
    *,
    command: RevisionCommand,
    text: str,
    initial_result: RedactionResult,
    profile_store: ProfileStore,
) -> tuple[AppliedRevisionCommand, list[DetectionCandidate], list[ProfileRule]]:
    targets = _resolve_targets(command, text=text, initial_result=initial_result)
    if not targets:
        return (
            AppliedRevisionCommand(
                command=command,
                skipped_reason="No matching revision target was found in the current text.",
            ),
            [],
            [],
        )

    if command.scope == "profile" or command.intent == "add_to_profile":
        applied, changed_rules = _apply_profile_command(
            command=command,
            targets=targets,
            profile_store=profile_store,
        )
        return applied, [], changed_rules

    candidates: list[DetectionCandidate] = []
    for target in targets:
        action = _current_document_action(command, target)
        for start, end in target.spans:
            candidates.append(
                DetectionCandidate(
                    type=target.entity_type,
                    start=start,
                    end=end,
                    confidence=0.995,
                    source="revision",
                    reason=_candidate_reason(command),
                    replacement=None if action == "allow" else target.replacement,
                    action=action,
                )
            )

    if not candidates:
        return (
            AppliedRevisionCommand(
                command=command,
                skipped_reason="The target text was not present in the current document.",
            ),
            [],
            [],
        )

    return (
        AppliedRevisionCommand(
            command=command,
            occurrence_count=len(candidates),
        ),
        candidates,
        [],
    )


def _apply_profile_command(
    *,
    command: RevisionCommand,
    targets: list[_ResolvedTarget],
    profile_store: ProfileStore,
) -> tuple[AppliedRevisionCommand, list[ProfileRule]]:
    profile_rule_ids: list[str] = []
    updated_profile_rule_ids: list[str] = []
    changed_rules: list[ProfileRule] = []

    for target in targets:
        if command.intent == "change_replacement":
            updated_rules = _update_matching_profile_rules(
                command=command,
                target=target,
                profile_store=profile_store,
            )
            if updated_rules:
                for rule in updated_rules:
                    updated_profile_rule_ids.append(rule.id)
                    changed_rules.append(rule)
                continue

        if not target.text:
            continue

        existing_rule = _find_existing_profile_rule(
            profile_store.get_profile().rules,
            target=target,
            action=_profile_action(command),
        )
        if existing_rule is not None:
            profile_rule_ids.append(existing_rule.id)
            changed_rules.append(existing_rule)
            continue

        created = profile_store.add_rule(
            ProfileRulePayload(
                label=f"Revision {target.entity_type} {_profile_action(command)}",
                entity_type=target.entity_type,
                patterns=[target.text],
                aliases=[],
                replacement=None if _profile_action(command) == "allow" else target.replacement,
                action=_profile_action(command),
                enabled=True,
                scope="global",
            )
        )
        profile_rule_ids.append(created.id)
        changed_rules.append(created)

    occurrence_count = sum(len(target.spans) for target in targets)
    if not profile_rule_ids and not updated_profile_rule_ids:
        return (
            AppliedRevisionCommand(
                command=command,
                occurrence_count=occurrence_count,
                skipped_reason="No profile rule target could be saved.",
            ),
            [],
        )

    return (
        AppliedRevisionCommand(
            command=command,
            occurrence_count=occurrence_count,
            profile_rule_ids=profile_rule_ids,
            updated_profile_rule_ids=updated_profile_rule_ids,
        ),
        changed_rules,
    )


def _resolve_targets(
    command: RevisionCommand,
    *,
    text: str,
    initial_result: RedactionResult,
) -> list[_ResolvedTarget]:
    if command.target_entity_id:
        entity = next(
            (
                entity
                for entity in initial_result.entities
                if entity.id == command.target_entity_id
            ),
            None,
        )
        if entity is None or not entity.text:
            return []
        spans = ()
        if entity.start is not None and entity.end is not None:
            spans = ((entity.start, entity.end),)
        entity_type = command.entity_type or entity.type
        return [
            _ResolvedTarget(
                text=entity.text,
                entity_type=entity_type,
                replacement=_command_replacement(command, entity_type, entity.replacement),
                spans=spans,
                existing_action=entity.action,
            )
        ]

    if command.target_text:
        target_text = command.target_text
        spans = tuple(_find_exact_spans(text, target_text))
        matching_entity = _matching_entity_for_text(
            target_text,
            initial_result=initial_result,
        )
        entity_type = (
            command.entity_type
            or (matching_entity.type if matching_entity else None)
            or _entity_type_from_replacement(command.replacement)
            or "CUSTOM"
        )
        return [
            _ResolvedTarget(
                text=target_text,
                entity_type=entity_type,
                replacement=_command_replacement(
                    command,
                    entity_type,
                    matching_entity.replacement if matching_entity else None,
                ),
                spans=spans,
                existing_action=matching_entity.action if matching_entity else None,
            )
        ]

    if command.entity_type:
        targets_by_text: dict[str, _ResolvedTarget] = {}
        existing_spans: set[tuple[int, int]] = set()
        for entity in initial_result.entities:
            if entity.type != command.entity_type or not entity.text:
                continue
            current = targets_by_text.get(entity.text)
            spans = tuple()
            if entity.start is not None and entity.end is not None:
                spans = ((entity.start, entity.end),)
                existing_spans.add((entity.start, entity.end))
            if current is None:
                targets_by_text[entity.text] = _ResolvedTarget(
                    text=entity.text,
                    entity_type=entity.type,
                    replacement=_command_replacement(
                        command,
                        entity.type,
                        entity.replacement,
                    ),
                    spans=spans,
                    existing_action=entity.action,
                )
            else:
                targets_by_text[entity.text] = _ResolvedTarget(
                    text=current.text,
                    entity_type=current.entity_type,
                    replacement=current.replacement,
                    spans=(*current.spans, *spans),
                    existing_action=current.existing_action,
                )
        for start, end in _fallback_spans_for_entity_type(command.entity_type, text):
            if (start, end) in existing_spans:
                continue
            value = text[start:end]
            current = targets_by_text.get(value)
            spans = ((start, end),)
            if current is None:
                targets_by_text[value] = _ResolvedTarget(
                    text=value,
                    entity_type=command.entity_type,
                    replacement=_command_replacement(
                        command,
                        command.entity_type,
                        None,
                    ),
                    spans=spans,
                    existing_action=None,
                )
            else:
                targets_by_text[value] = _ResolvedTarget(
                    text=current.text,
                    entity_type=current.entity_type,
                    replacement=current.replacement,
                    spans=(*current.spans, *spans),
                    existing_action=current.existing_action,
                )
        return list(targets_by_text.values())

    return []


def _update_matching_profile_rules(
    *,
    command: RevisionCommand,
    target: _ResolvedTarget,
    profile_store: ProfileStore,
) -> list[ProfileRule]:
    if command.replacement is None:
        return []

    updated_rules: list[ProfileRule] = []
    for rule in profile_store.get_profile().rules:
        if rule.entity_type != target.entity_type:
            continue
        if target.text and not _rule_matches_text(rule, target.text):
            continue

        updated = profile_store.update_rule(
            rule.id,
            ProfileRulePayload(
                label=rule.label,
                entity_type=rule.entity_type,
                patterns=rule.patterns,
                aliases=rule.aliases,
                replacement=command.replacement,
                action=rule.action,
                enabled=rule.enabled,
                scope=rule.scope,
            ),
        )
        updated_rules.append(updated)

    return updated_rules


def _find_existing_profile_rule(
    rules: list[ProfileRule],
    *,
    target: _ResolvedTarget,
    action: str,
) -> ProfileRule | None:
    for rule in rules:
        if (
            rule.entity_type == target.entity_type
            and rule.action == action
            and _rule_matches_text(rule, target.text)
        ):
            return rule
    return None


def _rule_matches_text(rule: ProfileRule, text: str) -> bool:
    wanted = text.casefold()
    return any(term.casefold() == wanted for term in (*rule.patterns, *rule.aliases))


def _matching_entity_for_text(
    target_text: str,
    *,
    initial_result: RedactionResult,
) -> Any | None:
    wanted = target_text.casefold()
    for entity in initial_result.entities:
        if entity.text and entity.text.casefold() == wanted:
            return entity
    return None


def _current_document_action(command: RevisionCommand, target: _ResolvedTarget) -> str:
    if command.intent in {"mask", "ask", "allow"}:
        return command.intent
    if command.intent == "add_to_profile":
        return command.action or "mask"
    if target.existing_action in {"ask", "mask"}:
        return target.existing_action
    return "replace"


def _profile_action(command: RevisionCommand) -> str:
    if command.intent in {"mask", "ask", "allow"}:
        return command.intent
    return command.action or "mask"


def _candidate_reason(command: RevisionCommand) -> str:
    if command.reason:
        return f"Applied validated revision command: {command.reason}"
    return "Applied a validated natural-language revision command."


def _command_replacement(
    command: RevisionCommand,
    entity_type: str,
    existing_replacement: str | None,
) -> str:
    return command.replacement or existing_replacement or _default_replacement(entity_type)


def _default_replacement(entity_type: str) -> str:
    return TextRedactionPipeline._REPLACEMENTS.get(entity_type, f"[{entity_type}]")


def _entity_type_from_replacement(replacement: str | None) -> str | None:
    if replacement and _PLACEHOLDER_RE.match(replacement):
        candidate = replacement[1:-1]
        if _ENTITY_TYPE_RE.match(candidate):
            return candidate
    return None


def _entity_type_from_label(label: str | None) -> str:
    normalized = _normalize_entity_type(label or "CUSTOM")
    return normalized or "CUSTOM"


def _replacement_from_label(label: str | None) -> str:
    entity_type = _entity_type_from_label(label)
    return f"[{entity_type}]"


def _normalize_entity_type(value: str | None) -> str:
    if not value:
        return "CUSTOM"
    stripped = _strip_quotes(value)
    normalized = re.sub(r"[^A-Za-z0-9]+", "_", stripped).strip("_").upper()
    if normalized.endswith("_NAMES"):
        normalized = normalized[: -len("_NAMES")]
    elif normalized.endswith("_NAME"):
        normalized = normalized[: -len("_NAME")]
    elif normalized.endswith("S") and not normalized.endswith("SS"):
        normalized = normalized[:-1]
    normalized = _TYPE_ALIASES.get(normalized, normalized)
    if not _ENTITY_TYPE_RE.match(normalized):
        return "CUSTOM"
    return normalized


def _intent_from_word(value: str) -> str:
    lowered = value.strip().casefold()
    if lowered == "allow":
        return "allow"
    if lowered == "ask":
        return "ask"
    return "mask"


def _action_for_intent(intent: str) -> str | None:
    if intent in {"mask", "ask", "allow"}:
        return intent
    return None


def _scope_from_instruction(instruction: str, requested_scope: str) -> str:
    lowered = instruction.casefold()
    if "profile" in lowered:
        return "profile"
    return requested_scope


def _strip_quotes(value: str) -> str:
    stripped = value.strip()
    if len(stripped) >= 2 and stripped[0] == stripped[-1] and stripped[0] in {"'", '"'}:
        return stripped[1:-1].strip()
    return stripped


def _find_exact_spans(text: str, value: str) -> list[tuple[int, int]]:
    spans: list[tuple[int, int]] = []
    start = 0
    while True:
        index = text.find(value, start)
        if index < 0:
            break
        end = index + len(value)
        spans.append((index, end))
        start = end
    return spans


def _fallback_spans_for_entity_type(entity_type: str, text: str) -> list[tuple[int, int]]:
    if entity_type != "DATE":
        return []

    spans: list[tuple[int, int]] = []
    seen: set[tuple[int, int]] = set()
    for pattern in _DATE_FALLBACK_PATTERNS:
        for match in pattern.finditer(text):
            span = (match.start(), match.end())
            if span in seen:
                continue
            seen.add(span)
            spans.append(span)
    return spans


def _extract_json_object(content: str) -> str:
    stripped = content.strip()
    if stripped.startswith("```"):
        stripped = re.sub(r"^```(?:json)?", "", stripped, count=1).strip()
        stripped = re.sub(r"```$", "", stripped, count=1).strip()

    start = stripped.find("{")
    end = stripped.rfind("}")
    if start < 0 or end <= start:
        raise ValueError("No JSON object found.")
    return stripped[start : end + 1]
