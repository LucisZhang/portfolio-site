from app.redaction import TextRedactionPipeline


def test_phone_number_is_redacted() -> None:
    text = "Call +1 (415) 555-2671 today."
    result = TextRedactionPipeline().redact(text)

    assert result.redacted_text == "Call [PHONE] today."
    assert result.summary == {"PHONE": 1}
    assert result.entities[0].text == "+1 (415) 555-2671"
    assert result.entities[0].start == text.index("+1 (415) 555-2671")
    assert result.entities[0].end == result.entities[0].start + len("+1 (415) 555-2671")


def test_mainland_chinese_mobile_number_is_redacted() -> None:
    result = TextRedactionPipeline().redact("电话 138-0013-8000", mode="balanced")

    assert result.redacted_text == "电话 [PHONE]"
    assert result.summary == {"PHONE": 1}
    assert result.entities[0].text == "138-0013-8000"


def test_local_macos_path_is_redacted() -> None:
    text = "Attach /Users/ada/Documents/report.pdf before sharing."
    result = TextRedactionPipeline().redact(text)

    assert result.redacted_text == "Attach [LOCAL_PATH] before sharing."
    assert result.summary == {"LOCAL_PATH": 1}
    assert result.entities[0].text == "/Users/ada/Documents/report.pdf"
    assert result.entities[0].type == "LOCAL_PATH"


def test_ip_address_is_redacted() -> None:
    text = "Server 192.168.1.44 handled the request."
    result = TextRedactionPipeline().redact(text)

    assert result.redacted_text == "Server [IP_ADDRESS] handled the request."
    assert result.summary == {"IP_ADDRESS": 1}
    assert result.entities[0].text == "192.168.1.44"
    assert result.entities[0].type == "IP_ADDRESS"


def test_api_key_assignment_redacts_secret_value_only() -> None:
    text = "OPENAI_API_KEY=fixture-key-0000000000000000"
    result = TextRedactionPipeline().redact(text)

    assert result.redacted_text == "OPENAI_API_KEY=[API_KEY]"
    assert result.summary == {"API_KEY": 1}
    assert result.entities[0].text == "fixture-key-0000000000000000"
    assert result.entities[0].type == "API_KEY"


def test_overlapping_email_inside_url_prefers_outer_url_span() -> None:
    text = "See https://example.com/users/ada@example.com now."
    result = TextRedactionPipeline().redact(text)

    assert result.redacted_text == "See [URL] now."
    assert result.summary == {"URL": 1}
    assert len(result.entities) == 1
    assert result.entities[0].type == "URL"
    assert result.entities[0].text == "https://example.com/users/ada@example.com"


def test_strict_mode_redacts_shorter_id_like_token() -> None:
    text = "Value 9f8e7d6c5b4a3f2e1d0c9b8a should not leave the Mac."
    balanced = TextRedactionPipeline().redact(text, mode="balanced")
    strict = TextRedactionPipeline().redact(text, mode="strict")

    assert balanced.redacted_text == text
    assert balanced.summary == {}
    assert strict.redacted_text == "Value [ID] should not leave the Mac."
    assert strict.summary == {"ID": 1}
    assert strict.entities[0].type == "ID"
