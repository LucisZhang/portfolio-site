from __future__ import annotations

import json
import re
from collections.abc import Iterable
from typing import Any

from .model_clients import ModelProviderClient
from .redaction.detectors import DetectionCandidate
from .redaction.pipeline import RedactionResult, TextRedactionPipeline
from .schemas import (
    AppliedReviewSuggestion,
    ModelProvider,
    ModelReviewResult,
    ModelReviewSuggestion,
    ProfileRule,
)


_ENTITY_TYPE_RE = re.compile(r"^[A-Z][A-Z0-9_]{1,63}$")
_PLACEHOLDER_RE = re.compile(r"^\[[A-Z][A-Z0-9_]{1,63}\]$")


async def run_model_review(
    *,
    text: str,
    mode: str,
    initial_result: RedactionResult,
    provider: ModelProvider,
    allow_raw_text_for_external_models: bool,
    profile_rules: Iterable[ProfileRule],
    pipeline: TextRedactionPipeline,
    client: ModelProviderClient,
) -> tuple[ModelReviewResult, RedactionResult]:
    raw_text_sent = provider.is_local or allow_raw_text_for_external_models
    raw_text_blocked = not provider.is_local and not allow_raw_text_for_external_models
    warning = None
    if raw_text_blocked:
        warning = (
            "External provider review used redacted-only input. Original text was not sent."
        )
    elif not provider.is_local and raw_text_sent:
        warning = (
            "Original text was sent to an external provider because raw sharing was enabled."
        )

    messages = build_review_messages(
        text=text,
        initial_result=initial_result,
        profile_rules=profile_rules,
        include_raw_text=raw_text_sent,
    )
    content = await client.complete_json(
        provider,
        messages,
        json_schema=review_json_schema(),
    )

    try:
        suggestion = parse_review_suggestion(content)
    except ValueError:
        review_result = ModelReviewResult(
            provider_id=provider.id,
            provider_name=provider.name,
            provider_is_local=provider.is_local,
            raw_text_sent=raw_text_sent,
            raw_text_blocked=raw_text_blocked,
            warning=warning,
            parsed=False,
            parse_error="Model response was not valid review JSON.",
        )
        return review_result, initial_result

    extra_candidates, applied, invalid = build_review_candidates(
        text=text,
        existing_entities=initial_result.entities,
        suggestion=suggestion,
    )
    final_result = pipeline.redact(text, mode=mode, extra_candidates=extra_candidates)
    review_result = ModelReviewResult(
        provider_id=provider.id,
        provider_name=provider.name,
        provider_is_local=provider.is_local,
        raw_text_sent=raw_text_sent,
        raw_text_blocked=raw_text_blocked,
        warning=warning,
        suggestion=suggestion,
        applied_missed_items=applied,
        invalid_suggestions=invalid,
    )
    return review_result, final_result


def parse_review_suggestion(content: str) -> ModelReviewSuggestion:
    json_text = _extract_json_object(content)
    try:
        return ModelReviewSuggestion.model_validate_json(json_text)
    except ValueError as exc:
        raise ValueError("Model response was not valid review JSON.") from exc


def build_review_candidates(
    *,
    text: str,
    existing_entities: list[Any],
    suggestion: ModelReviewSuggestion,
) -> tuple[list[DetectionCandidate], list[AppliedReviewSuggestion], list[str]]:
    covered_spans = [
        (entity.start, entity.end)
        for entity in existing_entities
        if entity.start is not None and entity.end is not None
    ]
    candidates: list[DetectionCandidate] = []
    applied: list[AppliedReviewSuggestion] = []
    invalid: list[str] = []

    for index, missed_item in enumerate(suggestion.missed_items, start=1):
        if not _ENTITY_TYPE_RE.match(missed_item.entity_type):
            invalid.append(f"missed_items[{index}] has an invalid entity_type.")
            continue

        replacement = _safe_replacement(
            missed_item.replacement,
            entity_type=missed_item.entity_type,
        )
        spans = _uncovered_exact_spans(text, missed_item.text, covered_spans)
        if not spans:
            invalid.append(
                f"missed_items[{index}] did not match an uncovered exact span."
            )
            continue

        for start, end in spans:
            candidates.append(
                DetectionCandidate(
                    type=missed_item.entity_type,
                    start=start,
                    end=end,
                    confidence=0.62,
                    source="llm_review",
                    reason=(
                        "Model review suggested an exact missed item; "
                        "the worker applied it by local exact match."
                    ),
                    replacement=replacement,
                    action="replace",
                )
            )
            covered_spans.append((start, end))

        applied.append(
            AppliedReviewSuggestion(
                text=missed_item.text,
                entity_type=missed_item.entity_type,
                replacement=replacement,
                occurrence_count=len(spans),
            )
        )

    return candidates, applied, invalid


def build_review_messages(
    *,
    text: str,
    initial_result: RedactionResult,
    profile_rules: Iterable[ProfileRule],
    include_raw_text: bool,
) -> list[dict[str, str]]:
    system = (
        "You are a privacy redaction reviewer. Return only one JSON object. "
        "Do not rewrite, summarize, continue, or transform the user's text. "
        "Only suggest exact missed items that appear verbatim in the supplied "
        "review text. Do not suggest removing API_KEY detections. Include every "
        "required top-level key: pass, risk_level, missed_items, false_positives, "
        "and suggested_policy_updates."
    )
    entities: list[dict[str, object]] = []
    for entity in initial_result.entities:
        payload: dict[str, object] = {
            "id": entity.id,
            "type": entity.type,
            "source": entity.source,
            "action": entity.action,
            "replacement": entity.replacement,
            "confidence": entity.confidence,
        }
        if include_raw_text and entity.text is not None:
            payload["text"] = entity.text
        entities.append(payload)

    profile_summary: list[dict[str, str]] = []
    for rule in profile_rules:
        payload = {
            "id": rule.id,
            "entity_type": rule.entity_type,
            "action": rule.action,
            "scope": rule.scope,
        }
        if include_raw_text:
            payload["label"] = rule.label
        profile_summary.append(payload)
    review_payload: dict[str, object] = {
        "review_text_kind": "original" if include_raw_text else "redacted",
        "redacted_text": initial_result.redacted_text,
        "detected_entities": entities,
        "active_profile_summary": profile_summary,
        "required_output_contract": (
            "Return one JSON object only. pass is false when missed_items is non-empty. "
            "risk_level must be low, medium, or high. missed_items[].text must be an "
            "exact substring from the review text. missed_items[].entity_type must be "
            "a real uppercase label such as CUSTOM, PROJECT, PERSON, COMPANY, SCHOOL, "
            "ADDRESS, EMAIL, PHONE, URL, LOCAL_PATH, ID, or API_KEY; do not output "
            "placeholder words like UPPERCASE_ENTITY_TYPE. replacement should be a "
            "matching bracket placeholder such as [PROJECT] or [CUSTOM]."
        ),
        "required_output_example": {
            "pass": False,
            "risk_level": "medium",
            "missed_items": [
                {
                    "text": "Project Phoenix",
                    "entity_type": "PROJECT",
                    "replacement": "[PROJECT]",
                    "reason": "Client codename remains visible.",
                }
            ],
            "false_positives": [],
            "suggested_policy_updates": [],
        },
    }
    if include_raw_text:
        review_payload["original_text"] = text

    return [
        {"role": "system", "content": system},
        {"role": "user", "content": json.dumps(review_payload, ensure_ascii=False)},
    ]


def review_json_schema() -> dict[str, Any]:
    item_schema = {
        "type": "object",
        "additionalProperties": False,
        "required": ["text", "entity_type"],
        "properties": {
            "text": {"type": "string"},
            "entity_type": {"type": "string"},
            "replacement": {"type": ["string", "null"]},
            "reason": {"type": ["string", "null"]},
        },
    }
    return {
        "type": "object",
        "additionalProperties": False,
        "required": [
            "pass",
            "risk_level",
            "missed_items",
            "false_positives",
            "suggested_policy_updates",
        ],
        "properties": {
            "pass": {"type": "boolean"},
            "risk_level": {"type": "string", "enum": ["low", "medium", "high"]},
            "missed_items": {"type": "array", "items": item_schema},
            "false_positives": {
                "type": "array",
                "items": {
                    "type": "object",
                    "additionalProperties": False,
                    "properties": {
                        "entity_id": {"type": ["string", "null"]},
                        "text": {"type": ["string", "null"]},
                        "entity_type": {"type": ["string", "null"]},
                        "reason": {"type": ["string", "null"]},
                    },
                },
            },
            "suggested_policy_updates": {
                "type": "array",
                "items": {
                    "type": "object",
                    "additionalProperties": False,
                    "properties": {
                        "entity_type": {"type": ["string", "null"]},
                        "pattern": {"type": ["string", "null"]},
                        "replacement": {"type": ["string", "null"]},
                        "action": {
                            "type": ["string", "null"],
                            "enum": ["mask", "ask", "allow", None],
                        },
                        "reason": {"type": ["string", "null"]},
                    },
                },
            },
        },
    }


def _extract_json_object(content: str) -> str:
    stripped = content.strip()
    if stripped.startswith("```"):
        stripped = re.sub(r"^```(?:json)?", "", stripped, count=1).strip()
        stripped = re.sub(r"```$", "", stripped, count=1).strip()

    start = stripped.find("{")
    end = stripped.rfind("}")
    if start < 0 or end <= start:
        raise ValueError("No JSON object found.")
    return stripped[start : end + 1]


def _uncovered_exact_spans(
    text: str,
    value: str,
    covered_spans: list[tuple[int, int]],
) -> list[tuple[int, int]]:
    spans: list[tuple[int, int]] = []
    start = 0
    while True:
        index = text.find(value, start)
        if index < 0:
            break
        end = index + len(value)
        if not any(index < covered_end and covered_start < end for covered_start, covered_end in covered_spans):
            spans.append((index, end))
        start = end
    return spans


def _safe_replacement(replacement: str | None, *, entity_type: str) -> str:
    if replacement and _PLACEHOLDER_RE.match(replacement):
        return replacement
    return f"[{entity_type}]"
