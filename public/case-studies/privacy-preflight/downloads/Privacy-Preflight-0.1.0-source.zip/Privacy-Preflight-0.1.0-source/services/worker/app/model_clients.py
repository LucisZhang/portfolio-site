from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol

import httpx

from .schemas import ModelProvider


class ModelProviderClientError(RuntimeError):
    """Raised when a model provider call fails."""


@dataclass(frozen=True)
class ProviderTestResult:
    ok: bool
    message: str


class ModelProviderClient(Protocol):
    async def complete_json(
        self,
        provider: ModelProvider,
        messages: list[dict[str, str]],
        *,
        json_schema: dict[str, Any],
    ) -> str:
        """Return the assistant content from a non-streaming chat request."""

    async def test_provider(self, provider: ModelProvider) -> ProviderTestResult:
        """Check that a provider endpoint is reachable."""

    async def chat_completion(
        self,
        provider: ModelProvider,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        """Forward a non-streaming OpenAI-compatible chat completion request."""


class HTTPModelProviderClient:
    async def complete_json(
        self,
        provider: ModelProvider,
        messages: list[dict[str, str]],
        *,
        json_schema: dict[str, Any],
    ) -> str:
        if provider.provider_type == "ollama":
            return await self._ollama_complete(provider, messages, json_schema=json_schema)
        return await self._openai_compatible_complete(
            provider,
            messages,
            json_schema=json_schema,
        )

    async def test_provider(self, provider: ModelProvider) -> ProviderTestResult:
        try:
            if provider.provider_type == "ollama":
                await self._get_json(
                    _ollama_url(provider.base_url, "/api/tags"),
                    provider=provider,
                )
            else:
                await self._get_json(
                    _openai_models_url(provider.base_url),
                    provider=provider,
                )
        except ModelProviderClientError as exc:
            return ProviderTestResult(ok=False, message=str(exc))

        return ProviderTestResult(ok=True, message="Provider endpoint is reachable.")

    async def chat_completion(
        self,
        provider: ModelProvider,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        if provider.provider_type == "ollama":
            raise ModelProviderClientError(
                "Gateway upstream must expose OpenAI-compatible chat completions."
            )

        return await self._post_json(
            _openai_chat_url(provider.base_url),
            provider=provider,
            payload=payload,
        )

    async def _ollama_complete(
        self,
        provider: ModelProvider,
        messages: list[dict[str, str]],
        *,
        json_schema: dict[str, Any],
    ) -> str:
        payload: dict[str, Any] = {
            "model": provider.model,
            "messages": messages,
            "stream": False,
            "options": {
                "temperature": 0,
                "num_predict": provider.max_tokens,
            },
        }
        if provider.supports_json_mode:
            payload["format"] = "json"

        try:
            response_json = await self._post_json(
                _ollama_url(provider.base_url, "/api/chat"),
                provider=provider,
                payload=payload,
            )
            content = response_json.get("message", {}).get("content")
            if isinstance(content, str) and content.strip():
                return content
        except ModelProviderClientError as exc:
            if "HTTP 404" not in str(exc):
                raise

        prompt = _messages_to_prompt(messages)
        generate_payload: dict[str, Any] = {
            "model": provider.model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": 0,
                "num_predict": provider.max_tokens,
            },
        }
        if provider.supports_json_mode:
            generate_payload["format"] = "json"

        response_json = await self._post_json(
            _ollama_url(provider.base_url, "/api/generate"),
            provider=provider,
            payload=generate_payload,
        )
        content = response_json.get("response")
        if not isinstance(content, str) or not content.strip():
            raise ModelProviderClientError("Provider returned an empty response.")
        return content

    async def _openai_compatible_complete(
        self,
        provider: ModelProvider,
        messages: list[dict[str, str]],
        *,
        json_schema: dict[str, Any],
    ) -> str:
        payload: dict[str, Any] = {
            "model": provider.model,
            "messages": messages,
            "temperature": 0,
            "max_tokens": provider.max_tokens,
            "stream": False,
        }
        if provider.supports_json_mode:
            payload["response_format"] = {
                "type": "json_schema",
                "json_schema": {
                    "name": "redaction_review",
                    "strict": True,
                    "schema": json_schema,
                },
            }

        response_json = await self._post_json(
            _openai_chat_url(provider.base_url),
            provider=provider,
            payload=payload,
        )
        try:
            content = response_json["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise ModelProviderClientError(
                "Provider returned an unreadable chat response."
            ) from exc

        if isinstance(content, str) and content.strip():
            return content
        if isinstance(content, list):
            joined = "".join(
                part.get("text", "") for part in content if isinstance(part, dict)
            ).strip()
            if joined:
                return joined

        raise ModelProviderClientError("Provider returned an empty response.")

    async def _get_json(self, url: str, *, provider: ModelProvider) -> dict[str, Any]:
        headers = _provider_headers(provider)
        timeout = httpx.Timeout(provider.timeout)
        try:
            async with httpx.AsyncClient(timeout=timeout, trust_env=False) as client:
                response = await client.get(url, headers=headers)
            response.raise_for_status()
            return response.json()
        except httpx.HTTPStatusError as exc:
            raise ModelProviderClientError(
                f"Provider returned HTTP {exc.response.status_code}."
            ) from exc
        except (httpx.HTTPError, ValueError) as exc:
            raise ModelProviderClientError("Provider endpoint could not be reached.") from exc

    async def _post_json(
        self,
        url: str,
        *,
        provider: ModelProvider,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        headers = _provider_headers(provider)
        timeout = httpx.Timeout(provider.timeout)
        try:
            async with httpx.AsyncClient(timeout=timeout, trust_env=False) as client:
                response = await client.post(url, headers=headers, json=payload)
            response.raise_for_status()
            return response.json()
        except httpx.HTTPStatusError as exc:
            raise ModelProviderClientError(
                f"Provider returned HTTP {exc.response.status_code}."
            ) from exc
        except (httpx.HTTPError, ValueError) as exc:
            raise ModelProviderClientError("Provider endpoint could not be reached.") from exc


def _provider_headers(provider: ModelProvider) -> dict[str, str]:
    headers = {"Content-Type": "application/json"}
    if provider.api_key:
        headers["Authorization"] = f"Bearer {provider.api_key}"
    return headers


def _ollama_url(base_url: str, path: str) -> str:
    base = base_url.rstrip("/")
    if base.endswith("/api"):
        return f"{base}{path.removeprefix('/api')}"
    return f"{base}{path}"


def _openai_chat_url(base_url: str) -> str:
    base = base_url.rstrip("/")
    if base.endswith("/chat/completions"):
        return base
    return f"{base}/chat/completions"


def _openai_models_url(base_url: str) -> str:
    base = base_url.rstrip("/")
    if base.endswith("/chat/completions"):
        base = base[: -len("/chat/completions")]
    return f"{base}/models"


def _messages_to_prompt(messages: list[dict[str, str]]) -> str:
    return "\n\n".join(
        f"{message.get('role', 'user').upper()}:\n{message.get('content', '')}"
        for message in messages
    )
