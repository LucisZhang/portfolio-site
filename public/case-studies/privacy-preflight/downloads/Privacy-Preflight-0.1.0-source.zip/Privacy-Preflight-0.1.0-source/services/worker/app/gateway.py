from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from typing import Any

from .redaction.pipeline import RedactionResult, TextRedactionPipeline
from .schemas import (
    GatewayMessageRedactionSummary,
    GatewayRedactionEntity,
    GatewaySettings,
    ModelProvider,
)


class GatewayRequestError(ValueError):
    def __init__(self, detail: str, *, status_code: int = 400) -> None:
        super().__init__(detail)
        self.detail = detail
        self.status_code = status_code


@dataclass(frozen=True)
class GatewayPreparedRequest:
    forwarded_request: dict[str, Any]
    messages: list[GatewayMessageRedactionSummary]
    raw_text_sent: bool
    raw_text_blocked: bool
    warning: str | None


def prepare_gateway_request(
    payload: object,
    *,
    settings: GatewaySettings,
    provider: ModelProvider,
    pipeline: TextRedactionPipeline,
    mode: str = "balanced",
) -> GatewayPreparedRequest:
    if not isinstance(payload, dict):
        raise GatewayRequestError("Gateway request body must be a JSON object.")

    if payload.get("stream") is True:
        raise GatewayRequestError(
            "Gateway streaming is not supported yet; send stream=false.",
        )

    messages = payload.get("messages")
    if not isinstance(messages, list) or not messages:
        raise GatewayRequestError("Gateway request requires a non-empty messages array.")

    forwarded = deepcopy(payload)
    forwarded.pop("privacy_preflight_debug", None)
    forwarded["model"] = provider.model
    if "stream" in forwarded:
        forwarded["stream"] = False

    raw_text_sent = False
    raw_text_blocked = False
    warning = None
    message_summaries: list[GatewayMessageRedactionSummary] = []

    if not settings.redact_request_messages:
        if not settings.allow_raw_text_to_upstream:
            raise GatewayRequestError(
                "Gateway raw forwarding is disabled. Enable redaction or explicitly allow raw forwarding.",
                status_code=403,
            )
        raw_text_sent = True
        warning = (
            "Gateway forwarded original request messages because raw upstream sharing is enabled."
        )
        return GatewayPreparedRequest(
            forwarded_request=forwarded,
            messages=message_summaries,
            raw_text_sent=raw_text_sent,
            raw_text_blocked=raw_text_blocked,
            warning=warning,
        )

    forwarded_messages: list[object] = []
    for index, message in enumerate(messages):
        redacted_message, summary = _redact_message(
            message,
            index=index,
            pipeline=pipeline,
            mode=mode,
        )
        forwarded_messages.append(redacted_message)
        message_summaries.append(summary)

    forwarded["messages"] = forwarded_messages
    if not provider.is_local:
        raw_text_blocked = True
        warning = (
            "Gateway sent redacted-only messages to the non-local upstream provider."
        )

    return GatewayPreparedRequest(
        forwarded_request=forwarded,
        messages=message_summaries,
        raw_text_sent=raw_text_sent,
        raw_text_blocked=raw_text_blocked,
        warning=warning,
    )


def gateway_endpoint_url(settings: GatewaySettings) -> str:
    host = settings.bind_host
    if ":" in host and not host.startswith("["):
        host = f"[{host}]"
    return f"http://{host}:{settings.port}/v1"


def _redact_message(
    message: object,
    *,
    index: int,
    pipeline: TextRedactionPipeline,
    mode: str,
) -> tuple[dict[str, Any], GatewayMessageRedactionSummary]:
    if not isinstance(message, dict):
        raise GatewayRequestError("Each gateway message must be a JSON object.")

    redacted_message = deepcopy(message)
    role = message.get("role") if isinstance(message.get("role"), str) else None
    content = message.get("content")
    redaction_results: list[RedactionResult] = []
    text_part_count = 0

    if content is None:
        return redacted_message, _message_summary(
            index=index,
            role=role,
            text_part_count=text_part_count,
            redaction_results=redaction_results,
        )

    if isinstance(content, str):
        result = pipeline.redact(content, mode=mode)
        redacted_message["content"] = result.redacted_text
        redaction_results.append(result)
        text_part_count = 1
        return redacted_message, _message_summary(
            index=index,
            role=role,
            text_part_count=text_part_count,
            redaction_results=redaction_results,
        )

    if isinstance(content, list):
        redacted_parts: list[object] = []
        for part in content:
            if not isinstance(part, dict):
                raise GatewayRequestError(
                    "Gateway multipart content must contain JSON object parts."
                )

            if part.get("type") == "text" and isinstance(part.get("text"), str):
                redacted_part = deepcopy(part)
                result = pipeline.redact(part["text"], mode=mode)
                redacted_part["text"] = result.redacted_text
                redacted_parts.append(redacted_part)
                redaction_results.append(result)
                text_part_count += 1
                continue

            raise GatewayRequestError(
                "Gateway can only redact plain text message content and text multipart parts."
            )

        redacted_message["content"] = redacted_parts
        return redacted_message, _message_summary(
            index=index,
            role=role,
            text_part_count=text_part_count,
            redaction_results=redaction_results,
        )

    raise GatewayRequestError(
        "Gateway can only redact string message content or text multipart content."
    )


def _message_summary(
    *,
    index: int,
    role: str | None,
    text_part_count: int,
    redaction_results: list[RedactionResult],
) -> GatewayMessageRedactionSummary:
    entities: list[GatewayRedactionEntity] = []
    summary: dict[str, int] = {}
    for result in redaction_results:
        for entity in result.entities:
            entities.append(
                GatewayRedactionEntity(
                    id=entity.id,
                    type=entity.type,
                    start=entity.start,
                    end=entity.end,
                    confidence=entity.confidence,
                    source=entity.source,
                    action=entity.action,
                    replacement=entity.replacement,
                    profile_rule_id=entity.profile_rule_id,
                )
            )
        for entity_type, count in result.summary.items():
            summary[entity_type] = summary.get(entity_type, 0) + count

    return GatewayMessageRedactionSummary(
        index=index,
        role=role,
        text_part_count=text_part_count,
        entities=entities,
        summary=dict(sorted(summary.items())),
    )
