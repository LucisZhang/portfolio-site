from __future__ import annotations

import json
from pathlib import Path

from app.config import WorkerSettings, load_settings
from app.redaction import TextRedactionPipeline
from app.redaction.chinese import (
    ChineseDictionaryValidationError,
    HanLPChineseNERDetector,
    validate_chinese_dictionary,
)


def test_chinese_school_name_is_redacted() -> None:
    text = "我的学校是北京理工大学"
    result = TextRedactionPipeline().redact(text)

    assert result.redacted_text == "我的学校是[SCHOOL]"
    assert result.summary == {"SCHOOL": 1}
    assert result.entities[0].text == "北京理工大学"
    assert result.entities[0].type == "SCHOOL"
    assert result.entities[0].source == "chinese_dictionary"


def test_chinese_and_english_university_aliases_are_redacted() -> None:
    text = "我在澳门大学交换，也就是 University of Macau"
    result = TextRedactionPipeline().redact(text)

    assert result.redacted_text == "我在[SCHOOL]交换，也就是 [SCHOOL]"
    assert result.summary == {"SCHOOL": 2}
    assert [entity.text for entity in result.entities] == [
        "澳门大学",
        "University of Macau",
    ]


def test_english_university_name_is_redacted() -> None:
    text = "我毕业于 Beijing Institute of Technology"
    result = TextRedactionPipeline().redact(text)

    assert result.redacted_text == "我毕业于 [SCHOOL]"
    assert result.summary == {"SCHOOL": 1}
    assert result.entities[0].text == "Beijing Institute of Technology"


def test_chinese_address_marker_pattern_is_redacted() -> None:
    text = "地址：北京市海淀区中关村南大街5号"
    result = TextRedactionPipeline().redact(text)

    assert result.redacted_text == "地址：[ADDRESS]"
    assert result.summary == {"ADDRESS": 1}
    assert result.entities[0].text == "北京市海淀区中关村南大街5号"
    assert result.entities[0].source == "chinese_address_pattern"


def test_macos_path_with_chinese_and_spaces_is_redacted() -> None:
    text = "路径：/Users/张三/Privacy Preflight/report.pdf"
    result = TextRedactionPipeline().redact(text)

    assert result.redacted_text == "路径：[LOCAL_PATH]"
    assert result.summary == {"LOCAL_PATH": 1}
    assert result.entities[0].text == "/Users/张三/Privacy Preflight/report.pdf"
    assert result.entities[0].type == "LOCAL_PATH"


def test_mixed_text_redacts_email_api_key_and_chinese_school() -> None:
    text = (
        "我的学校是北京理工大学，邮箱 ada@example.com，"
        "OPENAI_API_KEY=fixture-key-0000000000000000，"
        "也申请了 University of Macau"
    )
    result = TextRedactionPipeline().redact(text)

    assert result.redacted_text == (
        "我的学校是[SCHOOL]，邮箱 [EMAIL]，"
        "OPENAI_API_KEY=[API_KEY]，"
        "也申请了 [SCHOOL]"
    )
    assert result.summary == {"API_KEY": 1, "EMAIL": 1, "SCHOOL": 2}
    assert [(entity.type, entity.source) for entity in result.entities] == [
        ("SCHOOL", "chinese_dictionary"),
        ("EMAIL", "regex:email"),
        ("API_KEY", "regex:api_key_assignment"),
        ("SCHOOL", "chinese_dictionary"),
    ]


def test_chinese_ner_can_be_disabled_by_settings() -> None:
    result = TextRedactionPipeline.from_settings(
        WorkerSettings(enable_chinese_ner=False)
    ).redact("我的学校是北京理工大学")

    assert result.redacted_text == "我的学校是北京理工大学"
    assert result.entities == []


def test_chinese_ner_settings_are_loaded_from_environment(monkeypatch) -> None:
    monkeypatch.setenv("PRIVACY_PREFLIGHT_ENABLE_CHINESE_NER", "false")
    monkeypatch.setenv("PRIVACY_PREFLIGHT_CHINESE_NER_PROVIDER", "hanlp")
    monkeypatch.setenv("PRIVACY_PREFLIGHT_CHINESE_NER_MODEL_PATH", "/tmp/hanlp-model")
    monkeypatch.setenv(
        "PRIVACY_PREFLIGHT_DICTIONARY_PATH",
        "/tmp/privacy-preflight-dictionary.json",
    )

    settings = load_settings()

    assert settings.enable_chinese_ner is False
    assert settings.chinese_ner_provider == "hanlp"
    assert settings.chinese_ner_model_path == "/tmp/hanlp-model"
    assert settings.dictionary_path == "/tmp/privacy-preflight-dictionary.json"


def test_hanlp_adapter_maps_mocked_ner_spans() -> None:
    def fake_pipeline(text: str) -> dict[str, list[tuple[str, str, int, int]]]:
        start = text.index("张三")
        return {"ner": [("张三", "PER", start, start + len("张三"))]}

    result = TextRedactionPipeline(
        detectors=[HanLPChineseNERDetector(pipeline=fake_pipeline)]
    ).redact("我是张三")

    assert result.redacted_text == "我是[PERSON]"
    assert result.summary == {"PERSON": 1}
    assert result.entities[0].source == "hanlp"


def test_local_dictionary_detects_custom_school_company_and_project(
    tmp_path: Path,
) -> None:
    dictionary_path = _write_dictionary(
        tmp_path,
        [
            {
                "id": "rule_school_tsinghua",
                "label": "Tsinghua",
                "entity_type": "SCHOOL",
                "patterns": ["清华大学"],
                "replacement": "[SCHOOL]",
                "enabled": True,
                "source": "user_dictionary",
            },
            {
                "id": "rule_company_acme_china",
                "label": "Acme China",
                "entity_type": "COMPANY",
                "patterns": ["晨星科技"],
                "replacement": "[COMPANY]",
                "enabled": True,
                "source": "user_dictionary",
            },
            {
                "id": "rule_project_phoenix",
                "label": "Project Phoenix",
                "entity_type": "CUSTOM",
                "patterns": ["Project Phoenix"],
                "replacement": "[PROJECT]",
                "enabled": True,
                "source": "user_dictionary",
            },
        ],
    )

    result = TextRedactionPipeline.from_settings(
        WorkerSettings(dictionary_path=str(dictionary_path))
    ).redact("我在清华大学与晨星科技合作 Project Phoenix")

    assert result.redacted_text == "我在[SCHOOL]与[COMPANY]合作 [PROJECT]"
    assert [(entity.type, entity.source) for entity in result.entities] == [
        ("SCHOOL", "user_dictionary"),
        ("COMPANY", "user_dictionary"),
        ("CUSTOM", "user_dictionary"),
    ]


def test_disabled_dictionary_rule_does_not_apply(tmp_path: Path) -> None:
    dictionary_path = _write_dictionary(
        tmp_path,
        [
            {
                "id": "rule_disabled_school",
                "label": "Disabled",
                "entity_type": "SCHOOL",
                "patterns": ["不存在大学"],
                "replacement": "[SCHOOL]",
                "enabled": False,
                "source": "user_dictionary",
            }
        ],
    )

    result = TextRedactionPipeline.from_settings(
        WorkerSettings(dictionary_path=str(dictionary_path))
    ).redact("我的学校是不存在大学")

    assert result.redacted_text == "我的学校是不存在大学"
    assert result.entities == []


def test_missing_dictionary_path_falls_back_to_builtins(tmp_path: Path) -> None:
    missing_path = tmp_path / "missing-dictionary.json"

    result = TextRedactionPipeline.from_settings(
        WorkerSettings(dictionary_path=str(missing_path))
    ).redact("我的学校是北京理工大学")

    assert result.redacted_text == "我的学校是[SCHOOL]"
    assert result.summary == {"SCHOOL": 1}
    assert result.entities[0].source == "chinese_dictionary"


def test_invalid_dictionary_json_falls_back_without_document_text(
    tmp_path: Path,
) -> None:
    dictionary_path = tmp_path / "invalid-dictionary.json"
    dictionary_path.write_text("{not valid json", encoding="utf-8")
    raw_document_text = "我的学校是北京理工大学，敏感正文不应出现在错误中"

    result = TextRedactionPipeline.from_settings(
        WorkerSettings(dictionary_path=str(dictionary_path))
    ).redact(raw_document_text)

    assert result.redacted_text == "我的学校是[SCHOOL]，敏感正文不应出现在错误中"
    assert result.summary == {"SCHOOL": 1}


def test_dictionary_aliases_share_entity_type_and_replacement(
    tmp_path: Path,
) -> None:
    dictionary_path = _write_dictionary(
        tmp_path,
        [
            {
                "id": "rule_school_tsinghua_aliases",
                "label": "THU",
                "entity_type": "SCHOOL",
                "patterns": ["清华大学", "Tsinghua University", "THU"],
                "replacement": "[SCHOOL]",
                "enabled": True,
                "source": "user_dictionary",
            }
        ],
    )

    result = TextRedactionPipeline.from_settings(
        WorkerSettings(dictionary_path=str(dictionary_path))
    ).redact("清华大学 / Tsinghua University / THU")

    assert result.redacted_text == "[SCHOOL] / [SCHOOL] / [SCHOOL]"
    assert [entity.type for entity in result.entities] == [
        "SCHOOL",
        "SCHOOL",
        "SCHOOL",
    ]
    assert {entity.replacement for entity in result.entities} == {"[SCHOOL]"}


def test_dictionary_cannot_weaken_regex_api_key_detection(tmp_path: Path) -> None:
    secret_assignment = "OPENAI_API_KEY=fixture-key-0000000000000000"
    dictionary_path = _write_dictionary(
        tmp_path,
        [
            {
                "id": "rule_overbroad_secret_context",
                "label": "Secret Context",
                "entity_type": "CUSTOM",
                "patterns": [secret_assignment],
                "replacement": "[CUSTOM]",
                "enabled": True,
                "source": "user_dictionary",
            }
        ],
    )

    result = TextRedactionPipeline.from_settings(
        WorkerSettings(dictionary_path=str(dictionary_path))
    ).redact(secret_assignment)

    assert result.redacted_text == "OPENAI_API_KEY=[API_KEY]"
    assert result.summary == {"API_KEY": 1}
    assert result.entities[0].type == "API_KEY"
    assert result.entities[0].source.startswith("regex:")


def test_dictionary_validation_errors_do_not_include_pattern_values() -> None:
    raw_pattern = "敏感客户项目"

    try:
        validate_chinese_dictionary(
            {
                "version": 1,
                "rules": [
                    {
                        "id": "rule_bad_type",
                        "entity_type": "UNSUPPORTED",
                        "patterns": [raw_pattern],
                    }
                ],
            }
        )
    except ChineseDictionaryValidationError as exc:
        message = str(exc)
    else:
        raise AssertionError("Expected dictionary validation to fail")

    assert "rule_bad_type" in message
    assert "unsupported entity_type" in message
    assert raw_pattern not in message


def test_dictionary_source_cannot_impersonate_internal_sources() -> None:
    try:
        validate_chinese_dictionary(
            {
                "version": 1,
                "rules": [
                    {
                        "id": "rule_bad_source",
                        "entity_type": "SCHOOL",
                        "patterns": ["示例大学"],
                        "source": "allowlist:profile",
                    }
                ],
            }
        )
    except ChineseDictionaryValidationError as exc:
        message = str(exc)
    else:
        raise AssertionError("Expected dictionary validation to fail")

    assert "rule_bad_source" in message
    assert '"source" must be "user_dictionary"' in message
    assert "示例大学" not in message


def test_chinese_evaluation_fixtures(tmp_path: Path) -> None:
    fixture_path = Path(__file__).parent / "fixtures" / "chinese_redaction_cases.json"
    fixture = json.loads(fixture_path.read_text(encoding="utf-8"))
    dictionary_path = tmp_path / "fixture_dictionary.json"
    dictionary_path.write_text(
        json.dumps(fixture["dictionary"], ensure_ascii=False),
        encoding="utf-8",
    )
    pipeline = TextRedactionPipeline.from_settings(
        WorkerSettings(dictionary_path=str(dictionary_path))
    )

    passed = 0
    for case in fixture["cases"]:
        result = pipeline.redact(case["text"], mode=case.get("mode", "balanced"))

        assert result.redacted_text == case["expected_redacted_text"], case["id"]
        assert [entity.type for entity in result.entities] == case[
            "expected_entity_types"
        ], case["id"]
        passed += 1

    assert passed == len(fixture["cases"])


def _write_dictionary(tmp_path: Path, rules: list[dict[str, object]]) -> Path:
    dictionary_path = tmp_path / "dictionary.json"
    dictionary_path.write_text(
        json.dumps({"version": 1, "rules": rules}, ensure_ascii=False),
        encoding="utf-8",
    )
    return dictionary_path
