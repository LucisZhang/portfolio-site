from __future__ import annotations

import json

from fastapi.testclient import TestClient

from app.config import WorkerSettings
from app.main import create_app
from app.model_clients import ProviderTestResult
from app.model_provider_store import InMemorySecretStore, ModelProviderStore
from app.profile_store import ProfileStore
from app.schemas import ProfileRulePayload


class FakeRevisionModelClient:
    def __init__(self, response: str) -> None:
        self.response = response
        self.review_calls = []
        self.test_calls = []

    async def complete_json(self, provider, messages, *, json_schema):
        self.review_calls.append(
            {"provider": provider, "messages": messages, "json_schema": json_schema}
        )
        return self.response

    async def test_provider(self, provider):
        self.test_calls.append(provider)
        return ProviderTestResult(ok=True, message="ok")


def test_revision_parse_uses_mocked_local_model(tmp_path) -> None:
    fake = FakeRevisionModelClient(
        json.dumps(
            {
                "commands": [
                    {
                        "intent": "mask",
                        "target_text": "Project Phoenix",
                        "entity_type": "PROJECT",
                        "replacement": "[PROJECT]",
                        "action": "mask",
                        "scope": "current_document",
                        "reason": "Project codename.",
                    }
                ]
            }
        )
    )
    client, _store = _client(tmp_path, fake)
    provider_id = _create_provider(
        client,
        provider_type="ollama",
        is_local=True,
        base_url="http://127.0.0.1:11434",
        api_key=None,
    )

    response = client.post(
        "/revision/parse",
        json={
            "text": "Ship Project Phoenix.",
            "mode": "balanced",
            "instruction": "mask the project name",
            "scope": "current_document",
            "enable_model_parsing": True,
            "provider_id": provider_id,
        },
    )

    assert response.status_code == 200
    parse_result = response.json()["parse_result"]
    assert parse_result["parser"] == "model"
    assert parse_result["commands"][0]["target_text"] == "Project Phoenix"
    assert parse_result["commands"][0]["replacement"] == "[PROJECT]"
    assert fake.review_calls


def test_revision_parse_falls_back_without_model(tmp_path) -> None:
    client, _store = _client(tmp_path, FakeRevisionModelClient("{}"))

    response = client.post(
        "/revision/parse",
        json={
            "text": "Ship Project Phoenix.",
            "instruction": "mask Project Phoenix",
        },
    )

    assert response.status_code == 200
    parse_result = response.json()["parse_result"]
    assert parse_result["parser"] == "deterministic"
    assert parse_result["commands"][0]["intent"] == "mask"
    assert parse_result["commands"][0]["target_text"] == "Project Phoenix"


def test_revision_invalid_model_json_fails_gracefully(tmp_path) -> None:
    fake = FakeRevisionModelClient("not json")
    client, _store = _client(tmp_path, fake)
    provider_id = _create_provider(
        client,
        provider_type="ollama",
        is_local=True,
        base_url="http://127.0.0.1:11434",
        api_key=None,
    )

    response = client.post(
        "/redact/text/revise",
        json={
            "text": "Ship Project Phoenix.",
            "instruction": "mask the project name",
            "enable_model_parsing": True,
            "provider_id": provider_id,
        },
    )

    assert response.status_code == 200
    payload = response.json()
    assert payload["parse_result"]["parsed"] is False
    assert payload["final_result"]["redacted_text"] == "Ship Project Phoenix."
    assert payload["applied_commands"] == []


def test_revision_mask_exact_text_in_current_document(tmp_path) -> None:
    client, _store = _client(tmp_path, FakeRevisionModelClient("{}"))

    response = client.post(
        "/redact/text/revise",
        json={
            "text": "Ship Project Phoenix notes.",
            "instruction": "mask Project Phoenix",
            "scope": "current_document",
        },
    )

    assert response.status_code == 200
    payload = response.json()
    assert payload["final_result"]["redacted_text"] == "Ship [CUSTOM] notes."
    assert payload["final_result"]["entities"][0]["source"] == "revision"
    assert payload["applied_commands"][0]["occurrence_count"] == 1


def test_revision_mask_as_placeholder_in_current_document(tmp_path) -> None:
    client, _store = _client(tmp_path, FakeRevisionModelClient("{}"))

    response = client.post(
        "/redact/text/revise",
        json={
            "text": "Ship Project Phoenix notes.",
            "instruction": "mask Project Phoenix as [PROJECT]",
            "scope": "current_document",
        },
    )

    assert response.status_code == 200
    payload = response.json()
    command = payload["parse_result"]["commands"][0]
    assert command["target_text"] == "Project Phoenix"
    assert command["entity_type"] == "PROJECT"
    assert command["replacement"] == "[PROJECT]"
    assert payload["final_result"]["redacted_text"] == "Ship [PROJECT] notes."


def test_revision_allow_exact_text_suppresses_existing_match(tmp_path) -> None:
    client, _store = _client(tmp_path, FakeRevisionModelClient("{}"))

    response = client.post(
        "/redact/text/revise",
        json={
            "text": "Contact support@example.com.",
            "instruction": "allow support@example.com",
            "scope": "current_document",
        },
    )

    assert response.status_code == 200
    payload = response.json()
    assert payload["initial_result"]["redacted_text"] == "Contact [EMAIL]."
    assert payload["final_result"]["redacted_text"] == "Contact support@example.com."
    assert payload["final_result"]["entities"] == []


def test_revision_replace_all_dates_uses_deterministic_date_fallback(tmp_path) -> None:
    client, _store = _client(tmp_path, FakeRevisionModelClient("{}"))

    response = client.post(
        "/redact/text/revise",
        json={
            "text": "Meet on 2026-05-27 and 6/1/2026.",
            "instruction": "replace all dates with [DATE]",
            "scope": "current_document",
        },
    )

    assert response.status_code == 200
    payload = response.json()
    assert payload["final_result"]["redacted_text"] == "Meet on [DATE] and [DATE]."
    assert payload["final_result"]["summary"] == {"DATE": 2}


def test_revision_profile_update_saves_rule_and_applies_it(tmp_path) -> None:
    profile_path = tmp_path / "profile.json"
    client, _store = _client(tmp_path, FakeRevisionModelClient("{}"))

    response = client.post(
        "/redact/text/revise",
        json={
            "text": "Ship Project Phoenix notes.",
            "instruction": "add Project Phoenix to profile as PROJECT",
            "scope": "profile",
        },
    )

    assert response.status_code == 200
    payload = response.json()
    assert payload["final_result"]["redacted_text"] == "Ship [PROJECT] notes."
    assert payload["profile_rules"][0]["patterns"] == ["Project Phoenix"]
    assert payload["profile_rules"][0]["replacement"] == "[PROJECT]"
    saved_profile = profile_path.read_text(encoding="utf-8")
    assert "Project Phoenix" in saved_profile


def test_revision_allowlist_priority_over_current_document_mask(tmp_path) -> None:
    store = ProfileStore(tmp_path / "profile.json")
    store.add_rule(
        ProfileRulePayload(
            label="Allowed support",
            entity_type="EMAIL",
            patterns=["support@example.com"],
            action="allow",
        )
    )
    client = TestClient(
        create_app(
            settings=WorkerSettings(),
            profile_store=store,
            model_client=FakeRevisionModelClient("{}"),
        )
    )

    response = client.post(
        "/redact/text/revise",
        json={
            "text": "Contact support@example.com.",
            "instruction": "mask support@example.com",
            "scope": "current_document",
        },
    )

    assert response.status_code == 200
    payload = response.json()
    assert payload["initial_result"]["redacted_text"] == "Contact support@example.com."
    assert payload["final_result"]["redacted_text"] == "Contact support@example.com."
    assert payload["final_result"]["entities"] == []


def test_external_revision_parsing_skips_model_without_raw_opt_in(tmp_path) -> None:
    fake = FakeRevisionModelClient(
        json.dumps(
            {
                "commands": [
                    {
                        "intent": "mask",
                        "target_text": "Project Phoenix",
                        "scope": "current_document",
                    }
                ]
            }
        )
    )
    client, _store = _client(tmp_path, fake)
    provider_id = _create_provider(client, provider_type="openai_compatible", is_local=False)

    response = client.post(
        "/revision/parse",
        json={
            "text": "Ship Project Phoenix.",
            "instruction": "mask Project Phoenix",
            "enable_model_parsing": True,
            "provider_id": provider_id,
            "allow_raw_text_for_external_models": False,
        },
    )

    assert response.status_code == 200
    parse_result = response.json()["parse_result"]
    assert parse_result["parser"] == "deterministic"
    assert parse_result["raw_text_blocked"] is True
    assert fake.review_calls == []


def _client(tmp_path, fake_client: FakeRevisionModelClient):
    store = ModelProviderStore(
        tmp_path / "models.json",
        secret_store=InMemorySecretStore(),
    )
    app = create_app(
        settings=WorkerSettings(),
        profile_store=ProfileStore(tmp_path / "profile.json"),
        model_provider_store=store,
        model_client=fake_client,
    )
    return TestClient(app), store


def _provider_payload(**overrides):
    payload = {
        "name": "Test Provider",
        "provider_type": "openai_compatible",
        "base_url": "http://127.0.0.1:1234/v1",
        "api_key": "sk-test-123",
        "model": "test-model",
        "is_local": False,
        "supports_json_mode": True,
        "timeout": 10,
        "max_tokens": 300,
    }
    payload.update(overrides)
    return payload


def _create_provider(client: TestClient, **overrides) -> str:
    response = client.post("/models/providers", json=_provider_payload(**overrides))
    assert response.status_code == 200
    return response.json()["id"]
