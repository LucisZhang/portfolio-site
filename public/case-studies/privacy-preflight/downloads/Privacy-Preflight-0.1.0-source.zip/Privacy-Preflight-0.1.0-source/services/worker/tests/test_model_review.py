from __future__ import annotations

import json

from fastapi.testclient import TestClient

from app.config import WorkerSettings
from app.main import create_app
from app.model_clients import ModelProviderClientError, ProviderTestResult
from app.model_provider_store import InMemorySecretStore, ModelProviderStore
from app.model_review import parse_review_suggestion
from app.profile_store import ProfileStore


class FakeModelClient:
    def __init__(
        self,
        response: str | None = None,
        *,
        test_result: ProviderTestResult | None = None,
    ) -> None:
        self.response = response or _review_response()
        self.test_result = test_result or ProviderTestResult(ok=True, message="ok")
        self.review_calls = []
        self.test_calls = []

    async def complete_json(self, provider, messages, *, json_schema):
        self.review_calls.append(
            {"provider": provider, "messages": messages, "json_schema": json_schema}
        )
        return self.response

    async def test_provider(self, provider):
        self.test_calls.append(provider)
        return self.test_result


class FailingModelClient(FakeModelClient):
    async def complete_json(self, provider, messages, *, json_schema):
        self.review_calls.append(
            {"provider": provider, "messages": messages, "json_schema": json_schema}
        )
        raise ModelProviderClientError("secret leak sk-test-should-not-appear")


def test_model_provider_crud_keeps_api_key_out_of_json(tmp_path) -> None:
    fake = FakeModelClient()
    client, _store = _client(tmp_path, fake)

    response = client.post("/models/providers", json=_provider_payload())

    assert response.status_code == 200
    provider = response.json()
    provider_id = provider["id"]
    assert "api_key" not in provider
    assert provider["api_key_configured"] is True
    assert "sk-test-123" not in (tmp_path / "models.json").read_text(encoding="utf-8")

    list_response = client.get("/models/providers")

    assert list_response.status_code == 200
    assert '"api_key"' not in list_response.text
    assert "sk-test-123" not in list_response.text

    delete_response = client.delete(f"/models/providers/{provider_id}")

    assert delete_response.status_code == 204


def test_model_provider_test_uses_keychain_secret_without_echoing_it(tmp_path) -> None:
    fake = FakeModelClient()
    client, _store = _client(tmp_path, fake)
    provider_id = client.post("/models/providers", json=_provider_payload()).json()["id"]

    response = client.post(f"/models/providers/{provider_id}/test")

    assert response.status_code == 200
    assert response.json()["ok"] is True
    assert fake.test_calls[0].api_key == "sk-test-123"
    assert "sk-test-123" not in response.text


def test_review_json_parser_accepts_fenced_json() -> None:
    suggestion = parse_review_suggestion(
        """```json
        {
          "pass": false,
          "risk_level": "medium",
          "missed_items": [{"text": "Project Phoenix", "entity_type": "custom"}],
          "false_positives": [],
          "suggested_policy_updates": []
        }
        ```"""
    )

    assert suggestion.pass_ is False
    assert suggestion.risk_level == "medium"
    assert suggestion.missed_items[0].entity_type == "CUSTOM"


def test_local_review_provider_receives_original_text(tmp_path) -> None:
    fake = FakeModelClient()
    client, _store = _client(tmp_path, fake)
    provider_id = _create_provider(
        client,
        provider_type="ollama",
        is_local=True,
        base_url="http://127.0.0.1:11434",
        api_key=None,
    )
    _enable_review(client, provider_id)

    response = client.post(
        "/redact/text/review",
        json={"text": "Email ada@example.com.", "mode": "balanced"},
    )

    assert response.status_code == 200
    review_payload = _review_payload(fake)
    assert review_payload["review_text_kind"] == "original"
    assert review_payload["original_text"] == "Email ada@example.com."
    assert response.json()["review_result"]["raw_text_sent"] is True


def test_external_review_blocks_original_text_by_default(tmp_path) -> None:
    fake = FakeModelClient()
    client, _store = _client(tmp_path, fake)
    provider_id = _create_provider(client, provider_type="openai_compatible", is_local=False)
    _enable_review(client, provider_id)

    response = client.post(
        "/redact/text/review",
        json={"text": "Email ada@example.com.", "mode": "balanced"},
    )

    assert response.status_code == 200
    review_payload = _review_payload(fake)
    assert review_payload["review_text_kind"] == "redacted"
    assert "original_text" not in review_payload
    assert "ada@example.com" not in fake.review_calls[0]["messages"][1]["content"]
    review_result = response.json()["review_result"]
    assert review_result["raw_text_sent"] is False
    assert review_result["raw_text_blocked"] is True


def test_external_review_can_use_redacted_text_and_apply_missed_item(tmp_path) -> None:
    fake = FakeModelClient(
        response=_review_response(
            missed_items=[
                {
                    "text": "Project Phoenix",
                    "entity_type": "CUSTOM",
                    "replacement": "[PROJECT]",
                    "reason": "Project name remains visible.",
                }
            ]
        )
    )
    client, _store = _client(tmp_path, fake)
    provider_id = _create_provider(client, provider_type="openai_compatible", is_local=False)
    _enable_review(client, provider_id)

    response = client.post(
        "/redact/text/review",
        json={
            "text": "Client Project Phoenix email ada@example.com.",
            "mode": "balanced",
        },
    )

    assert response.status_code == 200
    payload = response.json()
    assert payload["initial_result"]["redacted_text"] == (
        "Client Project Phoenix email [EMAIL]."
    )
    assert payload["final_result"]["redacted_text"] == "Client [PROJECT] email [EMAIL]."
    assert any(
        entity["source"] == "llm_review"
        for entity in payload["final_result"]["entities"]
    )
    assert payload["review_result"]["applied_missed_items"][0]["text"] == (
        "Project Phoenix"
    )
    assert "original_text" not in _review_payload(fake)


def test_external_raw_review_requires_explicit_opt_in(tmp_path) -> None:
    fake = FakeModelClient()
    client, _store = _client(tmp_path, fake)
    provider_id = _create_provider(client, provider_type="openai_compatible", is_local=False)
    _enable_review(client, provider_id, allow_raw_external=True)

    response = client.post(
        "/redact/text/review",
        json={"text": "Email ada@example.com.", "mode": "balanced"},
    )

    assert response.status_code == 200
    review_payload = _review_payload(fake)
    assert review_payload["review_text_kind"] == "original"
    assert review_payload["original_text"] == "Email ada@example.com."
    warning = response.json()["review_result"]["warning"]
    assert "external provider" in warning


def test_review_provider_error_does_not_expose_api_key(tmp_path) -> None:
    fake = FailingModelClient()
    client, _store = _client(tmp_path, fake)
    provider_id = _create_provider(client, provider_type="openai_compatible", is_local=False)
    _enable_review(client, provider_id)

    response = client.post(
        "/redact/text/review",
        json={"text": "Email ada@example.com.", "mode": "balanced"},
    )

    assert response.status_code == 502
    assert "sk-test-should-not-appear" not in response.text
    assert "sk-test-123" not in response.text


def _client(tmp_path, fake_client: FakeModelClient):
    store = ModelProviderStore(
        tmp_path / "models.json",
        secret_store=InMemorySecretStore(),
    )
    app = create_app(
        settings=WorkerSettings(),
        profile_store=ProfileStore(tmp_path / "profile.json"),
        model_provider_store=store,
        model_client=fake_client,
    )
    return TestClient(app), store


def _provider_payload(**overrides):
    payload = {
        "name": "Test Provider",
        "provider_type": "openai_compatible",
        "base_url": "http://127.0.0.1:1234/v1",
        "api_key": "sk-test-123",
        "model": "test-model",
        "is_local": False,
        "supports_json_mode": True,
        "timeout": 10,
        "max_tokens": 300,
    }
    payload.update(overrides)
    return payload


def _create_provider(client: TestClient, **overrides) -> str:
    response = client.post("/models/providers", json=_provider_payload(**overrides))
    assert response.status_code == 200
    return response.json()["id"]


def _enable_review(
    client: TestClient,
    provider_id: str,
    *,
    allow_raw_external: bool = False,
) -> None:
    response = client.put(
        "/models/settings",
        json={
            "enable_llm_review": True,
            "selected_review_provider_id": provider_id,
            "allow_raw_text_for_external_models": allow_raw_external,
        },
    )
    assert response.status_code == 200


def _review_response(missed_items=None) -> str:
    return json.dumps(
        {
            "pass": not missed_items,
            "risk_level": "medium" if missed_items else "low",
            "missed_items": missed_items or [],
            "false_positives": [],
            "suggested_policy_updates": [],
        }
    )


def _review_payload(fake: FakeModelClient) -> dict:
    assert fake.review_calls
    return json.loads(fake.review_calls[-1]["messages"][1]["content"])
