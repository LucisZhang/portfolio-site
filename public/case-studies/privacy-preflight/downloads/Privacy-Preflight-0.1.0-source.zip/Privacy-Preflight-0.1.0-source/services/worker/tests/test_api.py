from fastapi.testclient import TestClient

from app.config import WorkerSettings
from app.main import create_app
from app.profile_store import ProfileStore


def _client(tmp_path) -> TestClient:
    return TestClient(
        create_app(
            settings=WorkerSettings(),
            profile_store=ProfileStore(tmp_path / "profile.json"),
        )
    )


def test_health_returns_ok(tmp_path) -> None:
    client = _client(tmp_path)
    response = client.get("/health")

    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_redact_text_redacts_email_with_summary(tmp_path) -> None:
    client = _client(tmp_path)
    text = "Email ada@example.com."
    response = client.post(
        "/redact/text",
        json={"text": text},
    )

    assert response.status_code == 200
    payload = response.json()
    assert payload["redacted_text"] == "Email [EMAIL]."
    assert payload["summary"] == {"EMAIL": 1}
    assert len(payload["entities"]) == 1

    entity = payload["entities"][0]
    assert entity["id"] == "ent_0001"
    assert entity["text"] == "ada@example.com"
    assert entity["type"] == "EMAIL"
    assert entity["start"] == text.index("ada@example.com")
    assert entity["end"] == entity["start"] + len("ada@example.com")
    assert entity["replacement"] == "[EMAIL]"
