from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol

from .detectors import DetectionCandidate, RedactionMode


class ChineseNERDetector(Protocol):
    name: str

    def detect(self, text: str, mode: RedactionMode) -> list[DetectionCandidate]:
        """Return Chinese or mixed-language sensitive spans in original text offsets."""


class ChineseNERUnavailableError(RuntimeError):
    """Raised when an optional Chinese NER provider cannot run locally."""


class ChineseDictionaryValidationError(ValueError):
    """Raised when a local Chinese dictionary file is invalid."""


SUPPORTED_DICTIONARY_ENTITY_TYPES = {
    "PERSON",
    "SCHOOL",
    "COMPANY",
    "ORGANIZATION",
    "LOCATION",
    "ADDRESS",
    "CUSTOM",
}
_USER_DICTIONARY_SOURCE = "user_dictionary"


@dataclass(frozen=True)
class ChineseDictionaryEntry:
    canonical: str
    type: str
    aliases: tuple[str, ...] = ()
    replacement: str | None = None
    source: str = "chinese_dictionary"
    confidence: float = 0.96
    rule_id: str | None = None

    @property
    def terms(self) -> tuple[str, ...]:
        return (self.canonical, *self.aliases)


def load_chinese_dictionary(
    path: str | Path | None,
    *,
    strict: bool = True,
) -> tuple[ChineseDictionaryEntry, ...]:
    if path is None or not str(path).strip():
        return ()

    dictionary_path = Path(path).expanduser()
    try:
        raw_json = dictionary_path.read_text(encoding="utf-8")
    except FileNotFoundError as exc:
        if not strict:
            return ()
        raise ChineseDictionaryValidationError(
            "Chinese dictionary file does not exist."
        ) from exc
    except OSError as exc:
        if not strict:
            return ()
        raise ChineseDictionaryValidationError(
            "Chinese dictionary file could not be read."
        ) from exc

    try:
        data = json.loads(raw_json)
    except json.JSONDecodeError as exc:
        if not strict:
            return ()
        raise ChineseDictionaryValidationError(
            f"Chinese dictionary file is not valid JSON at line {exc.lineno}, column {exc.colno}."
        ) from exc

    try:
        return validate_chinese_dictionary(data)
    except ChineseDictionaryValidationError:
        if not strict:
            return ()
        raise


def validate_chinese_dictionary(data: Any) -> tuple[ChineseDictionaryEntry, ...]:
    if not isinstance(data, dict):
        raise ChineseDictionaryValidationError(
            "Chinese dictionary must be a JSON object."
        )

    if data.get("version") != 1:
        raise ChineseDictionaryValidationError("Chinese dictionary version must be 1.")

    rules = data.get("rules")
    if not isinstance(rules, list):
        raise ChineseDictionaryValidationError(
            'Chinese dictionary field "rules" must be a list.'
        )

    entries: list[ChineseDictionaryEntry] = []
    for index, rule in enumerate(rules, start=1):
        if not isinstance(rule, dict):
            raise ChineseDictionaryValidationError(
                f"Chinese dictionary rule #{index} must be an object."
            )

        rule_id = _rule_id(rule, index)
        rule_label = f"rule {rule_id}" if rule_id else f"rule #{index}"
        enabled = rule.get("enabled", True)
        if not isinstance(enabled, bool):
            raise ChineseDictionaryValidationError(
                f"Chinese dictionary {rule_label} field \"enabled\" must be a boolean."
            )
        if not enabled:
            continue

        entity_type = _required_string(rule, "entity_type", rule_label).upper()
        if entity_type not in SUPPORTED_DICTIONARY_ENTITY_TYPES:
            raise ChineseDictionaryValidationError(
                f"Chinese dictionary {rule_label} has unsupported entity_type."
            )

        patterns = _patterns(rule, rule_label)
        replacement = _optional_string(
            rule,
            "replacement",
            rule_label,
            default=f"[{entity_type}]",
        )
        source = _optional_string(
            rule,
            "source",
            rule_label,
            default=_USER_DICTIONARY_SOURCE,
        )
        if source != _USER_DICTIONARY_SOURCE:
            raise ChineseDictionaryValidationError(
                f"Chinese dictionary {rule_label} field \"source\" must be \"user_dictionary\"."
            )

        entries.append(
            ChineseDictionaryEntry(
                canonical=patterns[0],
                type=entity_type,
                aliases=tuple(patterns[1:]),
                replacement=replacement,
                source=source,
                confidence=0.97,
                rule_id=rule_id,
            )
        )

    return tuple(entries)


def _rule_id(rule: dict[str, Any], index: int) -> str | None:
    value = rule.get("id")
    if value is None:
        return None
    if not isinstance(value, str) or not value.strip():
        raise ChineseDictionaryValidationError(
            f"Chinese dictionary rule #{index} field \"id\" must be a non-empty string."
        )
    normalized = value.strip()
    if not re.match(r"^[A-Za-z0-9:_-]+$", normalized):
        raise ChineseDictionaryValidationError(
            f"Chinese dictionary rule #{index} field \"id\" must be an identifier."
        )
    return normalized


def _required_string(rule: dict[str, Any], field: str, rule_label: str) -> str:
    value = rule.get(field)
    if not isinstance(value, str) or not value.strip():
        raise ChineseDictionaryValidationError(
            f"Chinese dictionary {rule_label} field \"{field}\" must be a non-empty string."
        )
    return value.strip()


def _optional_string(
    rule: dict[str, Any],
    field: str,
    rule_label: str,
    *,
    default: str,
) -> str:
    value = rule.get(field, default)
    if not isinstance(value, str) or not value.strip():
        raise ChineseDictionaryValidationError(
            f"Chinese dictionary {rule_label} field \"{field}\" must be a non-empty string."
        )
    return value.strip()


def _patterns(rule: dict[str, Any], rule_label: str) -> tuple[str, ...]:
    values = rule.get("patterns")
    if not isinstance(values, list):
        raise ChineseDictionaryValidationError(
            f"Chinese dictionary {rule_label} field \"patterns\" must be a list."
        )

    patterns: list[str] = []
    seen: set[str] = set()
    for value in values:
        if not isinstance(value, str) or not value.strip():
            raise ChineseDictionaryValidationError(
                f"Chinese dictionary {rule_label} field \"patterns\" must contain non-empty strings."
            )
        pattern = value.strip()
        dedupe_key = pattern.casefold()
        if dedupe_key in seen:
            continue
        seen.add(dedupe_key)
        patterns.append(pattern)

    if not patterns:
        raise ChineseDictionaryValidationError(
            f"Chinese dictionary {rule_label} field \"patterns\" must contain at least one pattern."
        )
    return tuple(patterns)


class ChineseDictionaryDetector:
    name = "chinese_dictionary"

    _DEFAULT_ENTRIES: tuple[ChineseDictionaryEntry, ...] = (
        ChineseDictionaryEntry(
            canonical="北京理工大学",
            type="SCHOOL",
            aliases=("Beijing Institute of Technology",),
        ),
        ChineseDictionaryEntry(
            canonical="澳门大学",
            type="SCHOOL",
            aliases=("University of Macau",),
        ),
    )

    def __init__(
        self,
        entries: tuple[ChineseDictionaryEntry, ...] | None = None,
        *,
        dictionary_path: str | Path | None = None,
    ) -> None:
        base_entries = entries if entries is not None else self._DEFAULT_ENTRIES
        self.entries = tuple(base_entries) + load_chinese_dictionary(
            dictionary_path,
            strict=False,
        )

    def detect(self, text: str, mode: RedactionMode) -> list[DetectionCandidate]:
        candidates: list[DetectionCandidate] = []
        seen_spans: set[tuple[int, int, str, str, str | None]] = set()
        for entry in self.entries:
            for term in entry.terms:
                for start, end in self._find_term_spans(text, term):
                    span_key = (
                        start,
                        end,
                        entry.type,
                        entry.source,
                        entry.replacement,
                    )
                    if span_key in seen_spans:
                        continue
                    seen_spans.add(span_key)
                    candidates.append(
                        DetectionCandidate(
                            type=entry.type,
                            start=start,
                            end=end,
                            confidence=entry.confidence,
                            source=entry.source,
                            reason=self._reason(entry),
                            replacement=entry.replacement,
                        )
                    )
        return candidates

    def _reason(self, entry: ChineseDictionaryEntry) -> str:
        if entry.source == "chinese_dictionary":
            return (
                "Matched a built-in public Chinese/mixed-language dictionary "
                f"entry for {entry.type}."
            )
        rule_reference = f" {entry.rule_id}" if entry.rule_id else ""
        return f"Matched local dictionary rule{rule_reference} for {entry.type}."

    def _find_term_spans(self, text: str, term: str) -> list[tuple[int, int]]:
        spans: list[tuple[int, int]] = []
        if not term:
            return spans

        is_latin_term = bool(re.search(r"[A-Za-z]", term))
        haystack = text.casefold() if is_latin_term else text
        needle = term.casefold() if is_latin_term else term
        search_start = 0
        while True:
            start = haystack.find(needle, search_start)
            if start == -1:
                break
            end = start + len(term)
            if not is_latin_term or self._has_latin_boundaries(text, start, end):
                spans.append((start, end))
            search_start = start + 1
        return spans

    def _has_latin_boundaries(self, text: str, start: int, end: int) -> bool:
        before = text[start - 1] if start > 0 else ""
        after = text[end] if end < len(text) else ""
        return not self._is_latin_word_char(before) and not self._is_latin_word_char(
            after
        )

    def _is_latin_word_char(self, value: str) -> bool:
        return bool(value and re.match(r"[A-Za-z0-9_]", value))


class ChineseAddressPatternDetector:
    name = "chinese_address_pattern"

    _ADDRESS_RE = re.compile(
        r"""
        (?<![\u4e00-\u9fffA-Za-z0-9])
        (?P<address>
            (?:
                [\u4e00-\u9fff]{2,}
                (?:省|市|区|县|镇|乡|村|街道|街|路|大道|大街|巷)
            ){2,}
            [\u4e00-\u9fffA-Za-z0-9０-９\-]*?
            (?:号|栋|幢|楼|室|单元)
            [\u4e00-\u9fffA-Za-z0-9０-９\-]*
        )
        """,
        re.VERBOSE,
    )
    _MIN_MARKERS = 3

    def detect(self, text: str, mode: RedactionMode) -> list[DetectionCandidate]:
        candidates: list[DetectionCandidate] = []
        for match in self._ADDRESS_RE.finditer(text):
            start = match.start("address")
            end = match.end("address")
            value = text[start:end]
            if self._marker_count(value) < self._MIN_MARKERS:
                continue
            candidates.append(
                DetectionCandidate(
                    type="ADDRESS",
                    start=start,
                    end=end,
                    confidence=0.88,
                    source="chinese_address_pattern",
                    reason="Matched a conservative Chinese address marker pattern.",
                )
            )
        return candidates

    def _marker_count(self, value: str) -> int:
        return sum(
            value.count(marker)
            for marker in (
                "省",
                "市",
                "区",
                "县",
                "镇",
                "乡",
                "村",
                "街",
                "路",
                "号",
                "栋",
                "幢",
                "楼",
                "室",
                "单元",
            )
        )


class HanLPChineseNERDetector:
    name = "hanlp_chinese_ner"

    _TYPE_ALIASES = {
        "PERSON": "PERSON",
        "PER": "PERSON",
        "NAME": "PERSON",
        "NR": "PERSON",
        "SCHOOL": "SCHOOL",
        "COMPANY": "COMPANY",
        "CORP": "COMPANY",
        "ORG": "ORGANIZATION",
        "ORGANIZATION": "ORGANIZATION",
        "NT": "ORGANIZATION",
        "LOC": "LOCATION",
        "LOCATION": "LOCATION",
        "GPE": "LOCATION",
        "NS": "LOCATION",
        "ADDRESS": "ADDRESS",
        "ADDR": "ADDRESS",
    }

    def __init__(
        self,
        *,
        pipeline: Any | None = None,
        model_path: str | None = None,
        confidence: float = 0.82,
    ) -> None:
        self._pipeline = pipeline
        self.model_path = model_path
        self.confidence = confidence

    def detect(self, text: str, mode: RedactionMode) -> list[DetectionCandidate]:
        pipeline = self._get_pipeline()
        output = pipeline(text)
        return self._map_output(text, output)

    def _get_pipeline(self) -> Any:
        if self._pipeline is not None:
            return self._pipeline
        if not self.model_path:
            raise ChineseNERUnavailableError(
                "HanLP Chinese NER requires a local model path. "
                "Set PRIVACY_PREFLIGHT_CHINESE_NER_MODEL_PATH."
            )
        if not Path(self.model_path).exists():
            raise ChineseNERUnavailableError(
                f"HanLP Chinese NER model path does not exist: {self.model_path}"
            )
        try:
            import hanlp
        except ImportError as exc:
            raise ChineseNERUnavailableError(
                'HanLP Chinese NER requires installing the "chinese-ner-hanlp" extra.'
            ) from exc

        self._pipeline = hanlp.load(self.model_path)
        return self._pipeline

    def _map_output(self, text: str, output: Any) -> list[DetectionCandidate]:
        spans = self._extract_ner_items(output)
        candidates: list[DetectionCandidate] = []
        for item in spans:
            mapped = self._map_item(text, item)
            if mapped is not None:
                candidates.append(mapped)
        return candidates

    def _extract_ner_items(self, output: Any) -> list[Any]:
        if isinstance(output, dict):
            items: list[Any] = []
            for key, value in output.items():
                if "ner" in str(key).lower():
                    items.extend(value if isinstance(value, list) else [value])
            return items
        if isinstance(output, list):
            return output
        if hasattr(output, "to_dict"):
            return self._extract_ner_items(output.to_dict())
        return []

    def _map_item(self, text: str, item: Any) -> DetectionCandidate | None:
        if isinstance(item, dict):
            entity_text = str(item.get("text") or item.get("span") or "")
            entity_type = str(item.get("type") or item.get("label") or item.get("tag") or "")
            start = item.get("start")
            end = item.get("end")
        elif isinstance(item, (list, tuple)) and len(item) >= 4:
            entity_text = str(item[0])
            entity_type = str(item[1])
            start = item[2]
            end = item[3]
        else:
            return None

        start_int, end_int = self._resolve_offsets(text, entity_text, start, end)
        if start_int is None or end_int is None or end_int <= start_int:
            return None

        source_type = entity_type.upper()
        mapped_type = self._TYPE_ALIASES.get(source_type, "CUSTOM")
        return DetectionCandidate(
            type=mapped_type,
            start=start_int,
            end=end_int,
            confidence=self.confidence,
            source="hanlp",
            reason=f"HanLP local Chinese NER detected {entity_type or 'entity'}.",
        )

    def _resolve_offsets(
        self,
        text: str,
        entity_text: str,
        start: Any,
        end: Any,
    ) -> tuple[int | None, int | None]:
        try:
            start_int = int(start)
            end_int = int(end)
        except (TypeError, ValueError):
            start_int = -1
            end_int = -1

        if 0 <= start_int < end_int <= len(text):
            if not entity_text or text[start_int:end_int] == entity_text:
                return start_int, end_int

        if entity_text:
            found = text.find(entity_text)
            if found != -1:
                return found, found + len(entity_text)
        return None, None


def build_chinese_detectors(
    *,
    provider: str = "dictionary_only",
    model_path: str | None = None,
    dictionary_path: str | Path | None = None,
) -> list[ChineseNERDetector]:
    detectors: list[ChineseNERDetector] = []
    normalized_provider = provider.strip().lower()
    if normalized_provider == "hanlp":
        detectors.append(HanLPChineseNERDetector(model_path=model_path))

    detectors.extend(
        [
            ChineseDictionaryDetector(dictionary_path=dictionary_path),
            ChineseAddressPatternDetector(),
        ]
    )
    return detectors
