from __future__ import annotations

from dataclasses import dataclass

from app.config import WorkerSettings, load_settings
from app.profile_store import ProfileStore
from app.redaction import PrivacyFilterDetector, TextRedactionPipeline
from app.schemas import ProfileRulePayload


@dataclass(frozen=True)
class FakePrivacySpan:
    label: str
    start: int
    end: int
    text: str
    confidence: float | None = None


class FakePrivacyFilterRedactor:
    def __init__(self, spans: list[FakePrivacySpan] | None = None) -> None:
        self.spans = spans or []
        self.calls: list[str] = []

    def redact(self, text: str) -> dict[str, object]:
        self.calls.append(text)
        return {
            "schema_version": 1,
            "text": text,
            "detected_spans": self.spans,
            "redacted_text": text,
        }


def test_privacy_filter_detector_maps_spans_to_entities() -> None:
    text = "Ada emailed ada@example.com on 2026-05-27."
    person_start = text.index("Ada")
    email_start = text.index("ada@example.com")
    date_start = text.index("2026-05-27")
    detector = PrivacyFilterDetector(
        redactor=FakePrivacyFilterRedactor(
            [
                FakePrivacySpan(
                    "private_person",
                    person_start,
                    person_start + len("Ada"),
                    "Ada",
                    0.91,
                ),
                FakePrivacySpan(
                    "private_email",
                    email_start,
                    email_start + len("ada@example.com"),
                    "ada@example.com",
                    0.94,
                ),
                FakePrivacySpan(
                    "private_date",
                    date_start,
                    date_start + len("2026-05-27"),
                    "2026-05-27",
                    0.83,
                ),
            ]
        )
    )

    result = TextRedactionPipeline(detectors=[detector]).redact(text)

    assert result.redacted_text == "[PERSON] emailed [EMAIL] on [DATE]."
    assert result.summary == {"DATE": 1, "EMAIL": 1, "PERSON": 1}
    assert [entity.source for entity in result.entities] == [
        "privacy_filter",
        "privacy_filter",
        "privacy_filter",
    ]
    assert result.entities[0].confidence == 0.91


def test_privacy_filter_integrates_with_pipeline_from_settings() -> None:
    text = "Ada met Bob."
    start = text.index("Bob")
    fake_redactor = FakePrivacyFilterRedactor(
        [FakePrivacySpan("private_person", start, start + len("Bob"), "Bob")]
    )
    detector = PrivacyFilterDetector(redactor=fake_redactor)

    pipeline = TextRedactionPipeline.from_settings(
        WorkerSettings(enable_privacy_filter=True, enable_chinese_ner=False),
        privacy_filter_detector=detector,
    )
    result = pipeline.redact(text)

    assert result.redacted_text == "Ada met [PERSON]."
    assert result.entities[0].source == "privacy_filter"
    assert fake_redactor.calls == [text]


def test_privacy_filter_overlap_does_not_replace_regex_api_key_detection() -> None:
    text = "OPENAI_API_KEY=fixture-key-0000000000000000"
    fake_redactor = FakePrivacyFilterRedactor(
        [
            FakePrivacySpan(
                "private_person",
                0,
                len(text),
                text,
                0.99,
            )
        ]
    )

    result = TextRedactionPipeline(
        enable_privacy_filter=True,
        privacy_filter_detector=PrivacyFilterDetector(redactor=fake_redactor),
        enable_chinese_ner=False,
    ).redact(text)

    assert result.redacted_text == "OPENAI_API_KEY=[API_KEY]"
    assert result.summary == {"API_KEY": 1}
    assert len(result.entities) == 1
    assert result.entities[0].source.startswith("regex:")


def test_profile_allow_rule_suppresses_privacy_filter_match(tmp_path) -> None:
    text = "Contact support@example.com."
    start = text.index("support@example.com")
    store = ProfileStore(tmp_path / "profile.json")
    store.add_rule(
        ProfileRulePayload(
            label="Public support email",
            entity_type="EMAIL",
            patterns=["support@example.com"],
            action="allow",
        )
    )
    fake_redactor = FakePrivacyFilterRedactor(
        [
            FakePrivacySpan(
                "private_email",
                start,
                start + len("support@example.com"),
                "support@example.com",
                0.92,
            )
        ]
    )

    result = TextRedactionPipeline(
        enable_privacy_filter=True,
        privacy_filter_detector=PrivacyFilterDetector(redactor=fake_redactor),
        enable_chinese_ner=False,
        profile_rules_loader=store.load_enabled_rules,
    ).redact(text)

    assert result.redacted_text == text
    assert result.entities == []


def test_privacy_filter_disabled_by_settings_skips_detector() -> None:
    text = "Ada met Bob."
    fake_redactor = FakePrivacyFilterRedactor(
        [FakePrivacySpan("private_person", 0, 3, "Ada")]
    )
    detector = PrivacyFilterDetector(redactor=fake_redactor)

    pipeline = TextRedactionPipeline.from_settings(
        WorkerSettings(enable_privacy_filter=False, enable_chinese_ner=False),
        privacy_filter_detector=detector,
    )
    result = pipeline.redact(text)

    assert result.redacted_text == text
    assert result.entities == []
    assert fake_redactor.calls == []


def test_privacy_filter_settings_are_loaded_from_environment(monkeypatch) -> None:
    monkeypatch.setenv("PRIVACY_PREFLIGHT_ENABLE_PRIVACY_FILTER", "true")
    monkeypatch.setenv("PRIVACY_PREFLIGHT_PRIVACY_FILTER_MODEL_PATH", "/models/opf")
    monkeypatch.setenv("PRIVACY_PREFLIGHT_PRIVACY_FILTER_MODEL_ID", "openai/privacy-filter")
    monkeypatch.setenv("PRIVACY_PREFLIGHT_PRIVACY_FILTER_RUNTIME", "opf")
    monkeypatch.setenv("PRIVACY_PREFLIGHT_PRIVACY_FILTER_DEVICE", "cpu")

    settings = load_settings()

    assert settings.enable_privacy_filter is True
    assert settings.privacy_filter_model_path == "/models/opf"
    assert settings.privacy_filter_model_id == "openai/privacy-filter"
    assert settings.privacy_filter_runtime == "opf"
    assert settings.privacy_filter_device == "cpu"
