from __future__ import annotations

import base64
from collections import Counter
from dataclasses import dataclass
from io import BytesIO
from typing import Any

from PIL import Image, ImageDraw

from app.image_redaction import OCRProvider, OCRTextBox, OCRUnavailableError, build_ocr_provider
from app.pdf_backend import create_image_only_pdf, open_pdf
from app.redaction.pipeline import TextRedactionPipeline
from app.schemas import (
    PDFManualRectangle,
    PDFPagePreview,
    PDFRedactionAnalysisResponse,
    PDFRedactionExportResponse,
    PDFRedactionRegion,
    PDFValidationResult,
)


class PDFRedactionError(Exception):
    """Base class for PDF failures safe to show to local clients."""


class PDFDependencyError(PDFRedactionError):
    pass


class InvalidPDFError(PDFRedactionError):
    pass


class PDFOCRUnavailableError(PDFRedactionError):
    pass


class PDFValidationFailedError(PDFRedactionError):
    pass


@dataclass(frozen=True)
class PDFWord:
    text: str
    start: int
    end: int
    x0: float
    y0: float
    x1: float
    y1: float
    block_no: int
    line_no: int


@dataclass(frozen=True)
class PDFAnalysisInternal:
    response: PDFRedactionAnalysisResponse
    validation_terms: list[str]


class PDFRedactionService:
    def __init__(
        self,
        *,
        ocr_provider: OCRProvider,
        text_pipeline: TextRedactionPipeline,
        preview_scale: float = 1.0,
        ocr_scale: float = 2.0,
        export_scale: float = 2.0,
        redaction_padding: float = 1.5,
    ) -> None:
        self.ocr_provider = ocr_provider
        self.text_pipeline = text_pipeline
        self.preview_scale = preview_scale
        self.ocr_scale = ocr_scale
        self.export_scale = export_scale
        self.redaction_padding = redaction_padding

    @classmethod
    def from_settings(
        cls,
        settings: Any,
        *,
        text_pipeline: TextRedactionPipeline,
    ) -> "PDFRedactionService":
        provider_name = str(
            getattr(settings, "image_ocr_provider", "auto") or "auto"
        ).lower()
        return cls(
            ocr_provider=build_ocr_provider(provider_name),
            text_pipeline=text_pipeline,
        )

    def analyze(
        self,
        pdf_bytes: bytes,
        *,
        mode: str = "balanced",
    ) -> PDFRedactionAnalysisResponse:
        return self._analyze(pdf_bytes, mode=mode, manual_rectangles=[]).response

    def export(
        self,
        pdf_bytes: bytes,
        *,
        mode: str = "balanced",
        manual_rectangles: list[PDFManualRectangle] | None = None,
    ) -> PDFRedactionExportResponse:
        analysis = self._analyze(
            pdf_bytes,
            mode=mode,
            manual_rectangles=manual_rectangles or [],
        )
        output_bytes, export_warnings = self._create_raster_redacted_pdf(
            pdf_bytes,
            analysis.response.redaction_regions,
        )
        validation = self.validate_output(output_bytes, analysis.validation_terms)
        if not validation.safe:
            raise PDFValidationFailedError(validation.message)

        warnings = [
            *analysis.response.warnings,
            *export_warnings,
            *validation.warnings,
        ]
        return PDFRedactionExportResponse(
            document_type=analysis.response.document_type,
            page_count=analysis.response.page_count,
            pages=analysis.response.pages,
            redaction_regions=analysis.response.redaction_regions,
            summary=analysis.response.summary,
            warnings=_dedupe_strings(warnings),
            validation=validation,
            redacted_pdf_base64=base64.b64encode(output_bytes).decode("ascii"),
        )

    def validate_output(
        self,
        pdf_bytes: bytes,
        known_redacted_terms: list[str],
    ) -> PDFValidationResult:
        doc = _open_pdf(pdf_bytes)
        try:
            extracted_text = "\n".join(page.get_text("text") or "" for page in doc)
            has_extractable_text = bool(extracted_text.strip())
            unapplied_redaction_annotations = _has_redaction_annotations(doc)
        finally:
            doc.close()

        terms = _unique_nonempty_terms(known_redacted_terms)
        leaked_terms = [
            term for term in terms if term and term in extracted_text
        ]
        redacted_text_absent = not leaked_terms

        if leaked_terms or unapplied_redaction_annotations or has_extractable_text:
            return PDFValidationResult(
                status="failed",
                safe=False,
                message=(
                    "The exported PDF still has extractable text or unapplied "
                    "redaction annotations, so it was not returned."
                ),
                redacted_text_absent=redacted_text_absent,
                unapplied_redaction_annotations=unapplied_redaction_annotations,
                checked_terms_count=len(terms),
                warnings=[],
            )

        if not terms:
            warning = (
                "No detected text strings were available for term-by-term validation; "
                "the exported PDF was still rebuilt as image-only pages with no "
                "extractable text layer."
            )
            return PDFValidationResult(
                status="warning",
                safe=True,
                message=warning,
                redacted_text_absent=True,
                unapplied_redaction_annotations=False,
                checked_terms_count=0,
                warnings=[warning],
            )

        return PDFValidationResult(
            status="passed",
            safe=True,
            message=(
                "Validation passed: known redacted strings were not extractable, "
                "no text layer remained, and no redaction annotations were left unapplied."
            ),
            redacted_text_absent=True,
            unapplied_redaction_annotations=False,
            checked_terms_count=len(terms),
            warnings=[],
        )

    def _analyze(
        self,
        pdf_bytes: bytes,
        *,
        mode: str,
        manual_rectangles: list[PDFManualRectangle],
    ) -> PDFAnalysisInternal:
        doc = _open_pdf(pdf_bytes)
        regions: list[PDFRedactionRegion] = []
        validation_terms: list[str] = []
        page_kinds: list[str] = []
        pages: list[PDFPagePreview] = []
        warnings: list[str] = []

        try:
            for page_index, page in enumerate(doc):
                words, page_text = _extract_page_words(page)
                has_text = bool(page_text.strip())
                has_images = _page_has_images(page)
                page_kinds.append(_page_kind(has_text=has_text, has_images=has_images))

                page_regions, page_terms = self._detect_text_regions(
                    page_index=page_index,
                    page_text=page_text,
                    words=words,
                    mode=mode,
                    next_region_number=len(regions) + 1,
                )
                regions.extend(page_regions)
                validation_terms.extend(page_terms)

                if has_images:
                    ocr_regions, ocr_terms = self._detect_ocr_regions(
                        page=page,
                        page_index=page_index,
                        mode=mode,
                        next_region_number=len(regions) + 1,
                    )
                    regions.extend(ocr_regions)
                    validation_terms.extend(ocr_terms)

                pages.append(self._preview_for_page(page, page_index=page_index))

            manual_regions = self._manual_regions(
                manual_rectangles,
                doc=doc,
                next_region_number=len(regions) + 1,
            )
            regions.extend(manual_regions)
        finally:
            doc.close()

        if not regions:
            warnings.append(
                "No automatic or manual PDF redaction regions were selected."
            )

        summary = dict(sorted(Counter(region.source for region in regions).items()))
        response = PDFRedactionAnalysisResponse(
            document_type=_document_type(page_kinds),
            page_count=len(pages),
            pages=pages,
            redaction_regions=regions,
            summary=summary,
            warnings=warnings,
        )
        return PDFAnalysisInternal(
            response=response,
            validation_terms=validation_terms,
        )

    def _detect_text_regions(
        self,
        *,
        page_index: int,
        page_text: str,
        words: list[PDFWord],
        mode: str,
        next_region_number: int,
    ) -> tuple[list[PDFRedactionRegion], list[str]]:
        if not page_text.strip() or not words:
            return [], []

        result = self.text_pipeline.redact(page_text, mode=mode)
        regions: list[PDFRedactionRegion] = []
        validation_terms: list[str] = []

        for entity in result.entities:
            if entity.action == "allow":
                continue
            matched_words = [
                word
                for word in words
                if _ranges_overlap(entity.start, entity.end, word.start, word.end)
            ]
            if not matched_words:
                continue

            validation_terms.append(entity.text)
            for line_words in _group_words_by_line(matched_words):
                x0 = min(word.x0 for word in line_words)
                y0 = min(word.y0 for word in line_words)
                x1 = max(word.x1 for word in line_words)
                y1 = max(word.y1 for word in line_words)
                regions.append(
                    PDFRedactionRegion(
                        id=f"pdf_reg_{next_region_number + len(regions):04d}",
                        page_index=page_index,
                        x=x0,
                        y=y0,
                        width=x1 - x0,
                        height=y1 - y0,
                        source="text_pdf",
                        reason=f"Detected extractable PDF text: {entity.type}.",
                        text=entity.text,
                        confidence=entity.confidence,
                        entity_types=[entity.type],
                        text_sources=[entity.source],
                    )
                )

        return regions, validation_terms

    def _detect_ocr_regions(
        self,
        *,
        page: Any,
        page_index: int,
        mode: str,
        next_region_number: int,
    ) -> tuple[list[PDFRedactionRegion], list[str]]:
        image, image_bytes = _render_page_image(page, scale=self.ocr_scale)
        try:
            boxes = self.ocr_provider.extract_text_boxes(
                image,
                image_bytes=image_bytes,
                image_format="PNG",
            )
        except OCRUnavailableError as exc:
            raise PDFOCRUnavailableError(
                "PDF image or scanned content requires local OCR. Enable macOS Vision OCR or Tesseract, then try again."
            ) from exc

        regions: list[PDFRedactionRegion] = []
        validation_terms: list[str] = []
        for box in boxes:
            box_text = box.text.strip()
            if not box_text:
                continue
            result = self.text_pipeline.redact(box_text, mode=mode)
            if not result.entities:
                continue

            entity_types = sorted({entity.type for entity in result.entities})
            text_sources = sorted({entity.source for entity in result.entities})
            validation_terms.extend(entity.text for entity in result.entities)
            x, y, width, height = _ocr_box_to_page_rect(
                box,
                page_rect=page.rect,
                scale=self.ocr_scale,
            )
            if width <= 0 or height <= 0:
                continue

            regions.append(
                PDFRedactionRegion(
                    id=f"pdf_reg_{next_region_number + len(regions):04d}",
                    page_index=page_index,
                    x=x,
                    y=y,
                    width=width,
                    height=height,
                    source="ocr",
                    reason=f"Detected sensitive OCR text: {', '.join(entity_types)}.",
                    text=box_text,
                    confidence=box.confidence,
                    entity_types=entity_types,
                    text_sources=text_sources,
                )
            )

        return regions, validation_terms

    def _manual_regions(
        self,
        manual_rectangles: list[PDFManualRectangle],
        *,
        doc: Any,
        next_region_number: int,
    ) -> list[PDFRedactionRegion]:
        regions: list[PDFRedactionRegion] = []
        for rectangle in manual_rectangles:
            if rectangle.page_index >= doc.page_count:
                continue
            page = doc[rectangle.page_index]
            x, y, width, height = _clamp_rect(
                rectangle.x,
                rectangle.y,
                rectangle.width,
                rectangle.height,
                page_rect=page.rect,
            )
            if width <= 0 or height <= 0:
                continue
            regions.append(
                PDFRedactionRegion(
                    id=f"pdf_reg_{next_region_number + len(regions):04d}",
                    page_index=rectangle.page_index,
                    x=x,
                    y=y,
                    width=width,
                    height=height,
                    source="manual",
                    reason="Manual rectangular PDF redaction.",
                )
            )
        return regions

    def _preview_for_page(self, page: Any, *, page_index: int) -> PDFPagePreview:
        image, image_bytes = _render_page_image(page, scale=self.preview_scale)
        return PDFPagePreview(
            page_index=page_index,
            width=float(page.rect.width),
            height=float(page.rect.height),
            image_width=image.width,
            image_height=image.height,
            preview_image_base64=base64.b64encode(image_bytes).decode("ascii"),
        )

    def _create_raster_redacted_pdf(
        self,
        pdf_bytes: bytes,
        regions: list[PDFRedactionRegion],
    ) -> tuple[bytes, list[str]]:
        doc = _open_pdf(pdf_bytes)
        warnings: list[str] = []
        output_pages: list[tuple[Image.Image, float, float]] = []
        try:
            for page_index, page in enumerate(doc):
                page_regions = [
                    region for region in regions if region.page_index == page_index
                ]
                image, _ = _render_page_image(page, scale=self.export_scale)
                if page_regions:
                    _burn_regions_into_image(
                        image,
                        page_regions,
                        page_rect=page.rect,
                        scale=self.export_scale,
                    )
                output_pages.append((image, float(page.rect.width), float(page.rect.height)))
            return create_image_only_pdf(output_pages), warnings
        finally:
            doc.close()


def _open_pdf(pdf_bytes: bytes) -> Any:
    if not pdf_bytes:
        raise InvalidPDFError("PDF file is empty.")

    try:
        doc = open_pdf(pdf_bytes)
    except Exception as exc:
        raise InvalidPDFError("PDF must be a readable PDF file.") from exc

    if doc.needs_pass:
        doc.close()
        raise InvalidPDFError("Password-protected PDFs must be unlocked before redaction.")
    if doc.page_count <= 0:
        doc.close()
        raise InvalidPDFError("PDF has no pages.")
    return doc


def _extract_page_words(page: Any) -> tuple[list[PDFWord], str]:
    words: list[PDFWord] = []
    text_parts: list[str] = []
    offset = 0

    for raw_word in page.get_text("words", sort=True):
        word_text = str(raw_word[4]).strip()
        if not word_text:
            continue

        if text_parts:
            text_parts.append(" ")
            offset += 1
        start = offset
        text_parts.append(word_text)
        offset += len(word_text)
        end = offset

        block_no = int(raw_word[5]) if len(raw_word) > 5 else 0
        line_no = int(raw_word[6]) if len(raw_word) > 6 else len(words)
        words.append(
            PDFWord(
                text=word_text,
                start=start,
                end=end,
                x0=float(raw_word[0]),
                y0=float(raw_word[1]),
                x1=float(raw_word[2]),
                y1=float(raw_word[3]),
                block_no=block_no,
                line_no=line_no,
            )
        )

    return words, "".join(text_parts)


def _page_has_images(page: Any) -> bool:
    try:
        return bool(page.get_images(full=True))
    except Exception:
        return False


def _page_kind(*, has_text: bool, has_images: bool) -> str:
    if has_text and has_images:
        return "mixed"
    if has_text:
        return "text"
    if has_images:
        return "scanned"
    return "text"


def _document_type(page_kinds: list[str]) -> str:
    if not page_kinds:
        return "text"
    if all(kind == "text" for kind in page_kinds):
        return "text"
    if all(kind == "scanned" for kind in page_kinds):
        return "scanned"
    return "mixed"


def _render_page_image(page: Any, *, scale: float) -> tuple[Image.Image, bytes]:
    image = page.render_image(scale=scale)
    output = BytesIO()
    image.save(output, format="PNG")
    image_bytes = output.getvalue()
    return image, image_bytes


def _ocr_box_to_page_rect(
    box: OCRTextBox,
    *,
    page_rect: Any,
    scale: float,
) -> tuple[float, float, float, float]:
    return _clamp_rect(
        float(page_rect.x0) + box.x / scale,
        float(page_rect.y0) + box.y / scale,
        box.width / scale,
        box.height / scale,
        page_rect=page_rect,
    )


def _clamp_rect(
    x: float,
    y: float,
    width: float,
    height: float,
    *,
    page_rect: Any,
) -> tuple[float, float, float, float]:
    left = _clamp(x, float(page_rect.x0), float(page_rect.x1))
    top = _clamp(y, float(page_rect.y0), float(page_rect.y1))
    right = _clamp(x + width, float(page_rect.x0), float(page_rect.x1))
    bottom = _clamp(y + height, float(page_rect.y0), float(page_rect.y1))
    return left, top, max(0, right - left), max(0, bottom - top)


def _burn_regions_into_image(
    image: Image.Image,
    regions: list[PDFRedactionRegion],
    *,
    page_rect: Any,
    scale: float,
) -> None:
    draw = ImageDraw.Draw(image)
    image_width, image_height = image.size
    for region in regions:
        left = int(round((region.x - float(page_rect.x0)) * scale))
        top = int(round((region.y - float(page_rect.y0)) * scale))
        right = int(round((region.x + region.width - float(page_rect.x0)) * scale))
        bottom = int(round((region.y + region.height - float(page_rect.y0)) * scale))
        left = int(_clamp(left, 0, image_width))
        top = int(_clamp(top, 0, image_height))
        right = int(_clamp(right, 0, image_width))
        bottom = int(_clamp(bottom, 0, image_height))
        if right <= left or bottom <= top:
            continue
        draw.rectangle([left, top, right, bottom], fill=(0, 0, 0))


def _strip_pdf_metadata(doc: Any) -> None:
    try:
        doc.set_metadata({})
    except Exception:
        pass
    try:
        doc.del_xml_metadata()
    except Exception:
        pass


def _has_redaction_annotations(doc: Any) -> bool:
    for page in doc:
        if page.has_redaction_annotations():
            return True
    return False


def _group_words_by_line(words: list[PDFWord]) -> list[list[PDFWord]]:
    grouped: dict[tuple[int, int], list[PDFWord]] = {}
    for word in words:
        grouped.setdefault((word.block_no, word.line_no), []).append(word)
    return [grouped[key] for key in sorted(grouped)]


def _ranges_overlap(
    start_a: int,
    end_a: int,
    start_b: int,
    end_b: int,
) -> bool:
    return start_a < end_b and start_b < end_a


def _unique_nonempty_terms(terms: list[str]) -> list[str]:
    unique_terms: list[str] = []
    seen: set[str] = set()
    for term in terms:
        stripped = term.strip()
        if not stripped:
            continue
        key = stripped.casefold()
        if key in seen:
            continue
        seen.add(key)
        unique_terms.append(stripped)
    return unique_terms


def _dedupe_strings(values: list[str]) -> list[str]:
    deduped: list[str] = []
    seen: set[str] = set()
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        deduped.append(value)
    return deduped


def _clamp(value: float, lower: float, upper: float) -> float:
    return max(lower, min(upper, value))
