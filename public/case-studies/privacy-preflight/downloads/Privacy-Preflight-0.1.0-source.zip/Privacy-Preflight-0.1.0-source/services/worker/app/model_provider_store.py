from __future__ import annotations

import json
import platform
import re
import subprocess
from datetime import UTC, datetime
from pathlib import Path
from typing import Protocol
from uuid import uuid4

from .profile_store import default_app_data_dir
from .schemas import (
    GatewaySettings,
    ModelProvider,
    ModelProviderPayload,
    ModelReviewSettings,
)


class ModelProviderStorageError(RuntimeError):
    """Raised when model provider configuration cannot be loaded or saved."""


class ModelProviderValidationError(ValueError):
    """Raised when a model provider update is invalid."""


class ModelProviderNotFoundError(KeyError):
    """Raised when a requested model provider does not exist."""


class SecretStoreError(RuntimeError):
    """Raised when a secret cannot be stored or loaded."""


class SecretStore(Protocol):
    def get_secret(self, account: str) -> str | None:
        """Return a stored secret, if present."""

    def set_secret(self, account: str, secret: str) -> None:
        """Store a secret for an account."""

    def delete_secret(self, account: str) -> None:
        """Delete a stored secret for an account."""


class MacOSKeychainSecretStore:
    service = "Privacy Preflight Model Providers"

    def get_secret(self, account: str) -> str | None:
        command = [
            "/usr/bin/security",
            "find-generic-password",
            "-s",
            self.service,
            "-a",
            account,
            "-w",
        ]
        result = subprocess.run(command, capture_output=True, text=True, check=False)
        if result.returncode == 44:
            return None
        if result.returncode != 0:
            raise SecretStoreError("Model provider API key could not be read.")
        return result.stdout.rstrip("\n")

    def set_secret(self, account: str, secret: str) -> None:
        command = [
            "/usr/bin/security",
            "add-generic-password",
            "-U",
            "-s",
            self.service,
            "-a",
            account,
            "-w",
            secret,
        ]
        result = subprocess.run(command, capture_output=True, text=True, check=False)
        if result.returncode != 0:
            raise SecretStoreError("Model provider API key could not be saved.")

    def delete_secret(self, account: str) -> None:
        command = [
            "/usr/bin/security",
            "delete-generic-password",
            "-s",
            self.service,
            "-a",
            account,
        ]
        result = subprocess.run(command, capture_output=True, text=True, check=False)
        if result.returncode not in {0, 44}:
            raise SecretStoreError("Model provider API key could not be deleted.")


class UnavailableSecretStore:
    def get_secret(self, _account: str) -> str | None:
        return None

    def set_secret(self, _account: str, _secret: str) -> None:
        raise SecretStoreError("API key storage requires macOS Keychain.")

    def delete_secret(self, _account: str) -> None:
        return None


class InMemorySecretStore:
    def __init__(self) -> None:
        self._secrets: dict[str, str] = {}

    def get_secret(self, account: str) -> str | None:
        return self._secrets.get(account)

    def set_secret(self, account: str, secret: str) -> None:
        self._secrets[account] = secret

    def delete_secret(self, account: str) -> None:
        self._secrets.pop(account, None)


class ModelProviderStore:
    def __init__(
        self,
        config_path: str | Path,
        *,
        secret_store: SecretStore | None = None,
    ) -> None:
        self.config_path = Path(config_path).expanduser()
        self.secret_store = secret_store or default_secret_store()

    @classmethod
    def from_settings(cls, settings: object) -> "ModelProviderStore":
        configured_path = getattr(settings, "model_provider_path", None)
        if configured_path:
            return cls(configured_path)

        configured_app_data_dir = getattr(settings, "app_data_dir", None)
        app_data_dir = (
            Path(configured_app_data_dir).expanduser()
            if configured_app_data_dir
            else default_app_data_dir()
        )
        return cls(app_data_dir / "model_providers.json")

    def list_providers(self) -> list[ModelProvider]:
        return self._load_config().providers

    def get_settings(self) -> ModelReviewSettings:
        return self._load_config().settings

    def get_gateway_settings(self) -> GatewaySettings:
        return self._load_config().gateway_settings

    def update_settings(self, settings: ModelReviewSettings) -> ModelReviewSettings:
        config = self._load_config()
        if settings.selected_review_provider_id and not any(
            provider.id == settings.selected_review_provider_id
            for provider in config.providers
        ):
            raise ModelProviderValidationError("Selected review provider was not found.")

        config.settings = settings
        self._save_config(config)
        return settings

    def update_gateway_settings(self, settings: GatewaySettings) -> GatewaySettings:
        config = self._load_config()
        if settings.upstream_provider_id:
            provider = next(
                (
                    provider
                    for provider in config.providers
                    if provider.id == settings.upstream_provider_id
                ),
                None,
            )
            if provider is None:
                raise ModelProviderValidationError(
                    "Gateway upstream provider was not found."
                )
            if provider.provider_type == "ollama":
                raise ModelProviderValidationError(
                    "Gateway upstream provider must be OpenAI-compatible."
                )

        config.gateway_settings = settings
        self._save_config(config)
        return settings

    def add_provider(self, payload: ModelProviderPayload) -> ModelProvider:
        config = self._load_config()
        provider_id = self._new_provider_id(payload.name, {p.id for p in config.providers})
        now = _utc_timestamp()
        api_key_configured = self._set_or_clear_secret(
            provider_id,
            payload.api_key,
            should_update="api_key" in payload.model_fields_set,
        )
        provider = ModelProvider(
            id=provider_id,
            name=payload.name,
            provider_type=payload.provider_type,
            base_url=payload.base_url,
            model=payload.model,
            is_local=payload.is_local,
            supports_json_mode=payload.supports_json_mode,
            timeout=payload.timeout,
            max_tokens=payload.max_tokens,
            api_key_configured=api_key_configured,
            created_at=now,
            updated_at=now,
        )
        config.providers.append(provider)
        self._save_config(config)
        return provider

    def update_provider(
        self,
        provider_id: str,
        payload: ModelProviderPayload,
    ) -> ModelProvider:
        config = self._load_config()
        for index, existing in enumerate(config.providers):
            if existing.id != provider_id:
                continue

            api_key_configured = existing.api_key_configured
            if "api_key" in payload.model_fields_set:
                api_key_configured = self._set_or_clear_secret(
                    provider_id,
                    payload.api_key,
                    should_update=True,
                )

            updated = ModelProvider(
                id=existing.id,
                name=payload.name,
                provider_type=payload.provider_type,
                base_url=payload.base_url,
                model=payload.model,
                is_local=payload.is_local,
                supports_json_mode=payload.supports_json_mode,
                timeout=payload.timeout,
                max_tokens=payload.max_tokens,
                api_key_configured=api_key_configured,
                created_at=existing.created_at,
                updated_at=_utc_timestamp(),
            )
            config.providers[index] = updated
            self._save_config(config)
            return updated

        raise ModelProviderNotFoundError(provider_id)

    def delete_provider(self, provider_id: str) -> None:
        config = self._load_config()
        next_providers = [
            provider for provider in config.providers if provider.id != provider_id
        ]
        if len(next_providers) == len(config.providers):
            raise ModelProviderNotFoundError(provider_id)

        self.secret_store.delete_secret(provider_id)
        config.providers = next_providers
        if config.settings.selected_review_provider_id == provider_id:
            config.settings.selected_review_provider_id = None
            config.settings.enable_llm_review = False
        if config.gateway_settings.upstream_provider_id == provider_id:
            config.gateway_settings.upstream_provider_id = None
            config.gateway_settings.enabled = False
        self._save_config(config)

    def clear_config(self, *, clear_keychain_api_keys: bool = False) -> tuple[bool, int]:
        keychain_entries_cleared = 0
        if clear_keychain_api_keys:
            config = self._load_config()
            for provider in config.providers:
                if not provider.api_key_configured:
                    continue
                self.secret_store.delete_secret(provider.id)
                keychain_entries_cleared += 1

        try:
            if self.config_path.exists():
                self.config_path.unlink()
                return True, keychain_entries_cleared
            return False, keychain_entries_cleared
        except OSError as exc:
            raise ModelProviderStorageError(
                "Model provider configuration could not be cleared."
            ) from exc

    def get_provider(self, provider_id: str, *, include_api_key: bool = False) -> ModelProvider:
        for provider in self.list_providers():
            if provider.id != provider_id:
                continue
            if not include_api_key:
                return provider
            return provider.model_copy(
                update={"api_key": self._load_provider_api_key(provider)}
            )
        raise ModelProviderNotFoundError(provider_id)

    def _load_provider_api_key(self, provider: ModelProvider) -> str | None:
        if not provider.api_key_configured:
            return None
        return self.secret_store.get_secret(provider.id)

    def _set_or_clear_secret(
        self,
        provider_id: str,
        api_key: str | None,
        *,
        should_update: bool,
    ) -> bool:
        if not should_update:
            return False
        if api_key:
            self.secret_store.set_secret(provider_id, api_key)
            return True
        self.secret_store.delete_secret(provider_id)
        return False

    def _load_config(self) -> "_StoredModelConfig":
        if not self.config_path.exists():
            return _StoredModelConfig()

        try:
            raw_json = self.config_path.read_text(encoding="utf-8")
            raw = json.loads(raw_json)
            return _StoredModelConfig.from_json(raw)
        except OSError as exc:
            raise ModelProviderStorageError(
                "Model provider configuration could not be read."
            ) from exc
        except ValueError as exc:
            raise ModelProviderStorageError(
                "Model provider configuration is not valid JSON."
            ) from exc

    def _save_config(self, config: "_StoredModelConfig") -> None:
        data = config.to_json()
        try:
            self.config_path.parent.mkdir(parents=True, exist_ok=True)
            temp_path = self.config_path.with_name(f"{self.config_path.name}.tmp")
            temp_path.write_text(
                json.dumps(data, ensure_ascii=False, indent=2) + "\n",
                encoding="utf-8",
            )
            temp_path.replace(self.config_path)
        except OSError as exc:
            raise ModelProviderStorageError(
                "Model provider configuration could not be saved."
            ) from exc

    def _new_provider_id(self, name: str, existing_ids: set[str]) -> str:
        slug = re.sub(r"[^a-z0-9]+", "_", name.casefold()).strip("_")[:40]
        if not slug:
            slug = "provider"

        for _ in range(10):
            candidate = f"model_{slug}_{uuid4().hex[:8]}"
            if candidate not in existing_ids:
                return candidate

        raise ModelProviderValidationError("Could not allocate a unique provider id.")


class _StoredModelConfig:
    def __init__(
        self,
        *,
        providers: list[ModelProvider] | None = None,
        settings: ModelReviewSettings | None = None,
        gateway_settings: GatewaySettings | None = None,
    ) -> None:
        self.providers = providers or []
        self.settings = settings or ModelReviewSettings()
        self.gateway_settings = gateway_settings or GatewaySettings()

    @classmethod
    def from_json(cls, raw: object) -> "_StoredModelConfig":
        if not isinstance(raw, dict):
            raise ValueError("Model provider configuration must be a JSON object.")

        providers = [
            ModelProvider.model_validate(provider)
            for provider in raw.get("providers", [])
        ]
        settings = ModelReviewSettings.model_validate(raw.get("settings", {}))
        gateway_settings = GatewaySettings.model_validate(
            raw.get("gateway_settings", {})
        )
        return cls(
            providers=providers,
            settings=settings,
            gateway_settings=gateway_settings,
        )

    def to_json(self) -> dict[str, object]:
        return {
            "version": 1,
            "providers": [
                provider.model_dump(mode="json", exclude={"api_key"})
                for provider in self.providers
            ],
            "settings": self.settings.model_dump(mode="json"),
            "gateway_settings": self.gateway_settings.model_dump(mode="json"),
        }


def default_secret_store() -> SecretStore:
    if platform.system() == "Darwin":
        return MacOSKeychainSecretStore()
    return UnavailableSecretStore()


def _utc_timestamp() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")
