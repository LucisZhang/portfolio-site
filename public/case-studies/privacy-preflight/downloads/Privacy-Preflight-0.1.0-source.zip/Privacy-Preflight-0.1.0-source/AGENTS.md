# AGENTS.md

You are working on Privacy Preflight, a local-first macOS privacy redaction app.

## Core Product Goal

Build a Mac app that helps users redact sensitive information from text, images, and PDFs before sending content to external AI tools.

## Architecture

- SwiftUI macOS frontend under `apps/macos`.
- Python FastAPI local worker under `services/worker`.
- Local-first privacy principle: raw user content stays on the Mac by default.
- Deterministic detectors run first; model review is optional and suggestion-only.
- No external model calls unless explicitly configured by the user.
- External or generic model providers must not receive raw sensitive text by default.

## Current Completed State

- Phase 0 completed: repository scaffold, FastAPI worker, SwiftUI SwiftPM scaffold.
- Phase 1 completed: regex text redaction backend MVP.
- Phase 1.5 completed: optional Microsoft Presidio integration.
- Phase 1.6 completed: Chinese and mixed-language detector baseline.
- Phase 1.7 completed: configurable local dictionaries and Chinese evaluation fixtures.
- Phase 2 completed: SwiftUI text workspace connected to `POST /redact/text`.
- Phase 2.5 completed: highlight preview, entity list, entity inspector, and Unicode-safe offset mapping.
- Phase 3 completed: backend profile rule schema/storage/endpoints, redaction pipeline profile integration, and basic SwiftUI Profile settings UI.
  - Profile actions are `mask`, `ask`, and `allow`.
  - Profile rules are stored locally under the app data directory as human-readable JSON.
  - Profile matches return `source = "profile"` and `profile_rule_id`.
  - Explicit allow rules suppress ordinary matches, while high-risk regex API-key detections remain protected.
- Phase 3.5 completed: Profile sample learning and result-page quick rule capture.
  - Sample learning stores generalized patterns and does not persist raw sample text.
  - Result-page quick capture can create profile rules from detected entities.
- Phase 4 completed: local/generic model provider layer and optional LLM review loop.
  - Supported provider scope is Ollama, LM Studio/local OpenAI-compatible servers, and one Generic OpenAI-compatible path.
  - External/generic providers default to redacted-only review.
  - Raw text to external providers requires explicit opt-in and warning.
  - LLM review returns structured JSON suggestions only and must not free-form rewrite the user's full text.
- Phase 4.1 completed: optional OpenAI Privacy Filter detector adapter.
  - OpenAI Privacy Filter is integrated as a detector-layer adapter, not as a chat/review provider.
  - Privacy Filter matches return `source = "privacy_filter"`.
  - The optional runtime dependency is not required for normal app startup or tests.
- Offset safety patch completed:
  - Backend offsets are documented as Python Unicode code point offsets.
  - Swift maps backend offsets through `String.unicodeScalars`.
  - Swift validates the mapped substring against `entity.text`.
  - Failed offset mapping skips the highlight and reports a diagnostic instead of crashing or highlighting the wrong span.

## Current Next Phase

- Phase 5: Natural Language Revision Loop.

Do not start Phase 5 unless the user explicitly asks for it. Do not re-run completed phases unless the user explicitly asks for that. Do not treat Phase 1.6, Phase 1.7, Phase 2, Phase 2.5, Phase 3, Phase 3.5, Phase 4, or Phase 4.1 as missing.

## Planned Remaining Phases

- Phase 5: Natural language revision loop.
- Phase 5.5: Local AI preflight gateway MVP.
- Phase 6: Image redaction MVP.
- Phase 7: PDF redaction MVP.
- Phase 8: Mac packaging, app bundle, worker lifecycle, and privacy hardening.

## Product Decisions

- Text redaction should mainly use placeholder replacement such as `[EMAIL]`, `[SCHOOL]`, and `[LOCAL_PATH]`.
- Do not prioritize text remove/delete as a core MVP action.
- Do not add clipboard shortcuts, global hotkeys, or quick clipboard redaction.
- Do not implement model comparison.
- Do not add OpenRouter-, DashScope-, or Gemini-specific provider phases.
- Keep model support local-first:
  - Ollama.
  - LM Studio or another local OpenAI-compatible server.
  - Generic OpenAI-compatible provider.
- External/generic providers must default to redacted-only forwarding.
- Raw text to external providers requires explicit opt-in and warning.
- Keep an optional local AI preflight gateway for a later phase, defaulting to redacted-only forwarding.
- Do not prioritize full-image panic mode.
- Image/PDF redaction export must be destructive and non-recoverable, not just visual black overlays.
- Mac packaging, `.app` bundling, and local worker lifecycle remain important later-phase requirements.

## Detector Stack

- Regex detectors remain the first line of defense for obvious PII and high-risk secrets.
- Optional Microsoft Presidio detection remains available when installed.
- Chinese and mixed-language detectors remain available.
- Configurable local dictionaries remain available.
- Profile rules remain available and can `mask`, `ask`, or `allow`.
- Optional OpenAI Privacy Filter detection may add entities with `source = "privacy_filter"`.
- LLM review is suggestion-only and must not be the sole detector.
- Do not weaken deterministic high-risk regex detections, especially API keys and secrets.

## Reference-First Rule

Before implementing any major module, inspect relevant existing open-source projects listed in `docs/references.md`. Prefer proven architecture and safety patterns over inventing from scratch, but reuse concepts rather than large code blocks.

For each phase:

1. Read `docs/references.md` if it exists.
2. Update `docs/references.md` if new references are discovered.
3. Check license compatibility and dependency risks before integrating new dependencies.
4. State which reference projects informed the implementation.
5. State what was intentionally not reused and why.

Current reference findings include RedactDesk, Microsoft Presidio, doc_redaction, LLM Guard, HanLP, Baidu LAC, HIT LTP/N-LTP, Chinese address parsing projects, CLUENER2020, related Chinese NER references, Cherry Studio's PII redaction proposal, and OpenAI Privacy Filter. See `docs/references.md` for license notes and conceptual reuse decisions.

## Phase Execution Rules

1. Keep phases small and verifiable.
2. Do not re-run completed phases unless explicitly requested.
3. Do not implement future phases early unless explicitly requested.
4. Commit and push after each accepted phase before starting the next phase.
5. Prefer deterministic detection for obvious PII.
6. Use LLMs for review and command parsing, not as the sole redaction engine.
7. Validate all model outputs.
8. Do not store raw user content by default.
9. Add tests for every backend feature.
10. Update README/docs whenever behavior changes.

At the end of each phase, report:

- Files changed.
- Commands run.
- Test results.
- Manual verification performed.
- Latest commit hash.
- `git status` and working tree state.
- What is implemented.
- What is intentionally not implemented.
- Risks and assumptions.

## Privacy Constraints

- Raw text, images, and PDFs should remain local by default.
- Local models may process raw text.
- External/cloud/generic providers must receive only redacted text or summaries unless the user explicitly enables raw-text sharing.
- Do not log raw sensitive content.
- Do not store raw input or raw sensitive content in history by default.
- Do not expose API keys in logs, errors, diagnostics, fixtures, or test output.
- Do not expose API keys in API responses or UI error details.
- Profile and sample-learning features must not persist raw sample text.
- Optional external provider support must be opt-in and must make redacted-only forwarding the default.
- LLM output must be structured suggestions or commands only, not free-form rewrites of the user's full text.

## Testing Expectations

- Run worker tests when backend changes: `scripts/test_worker.sh`.
- Run Swift build when frontend changes: `cd apps/macos && swift build`.
- Run `git diff --check` before reporting completion.
- Preserve existing Chinese and mixed-language fixture tests.
- Preserve offset-safety behavior for Unicode, emoji, accented text, and mixed Chinese/English input.
- Preserve existing Privacy Filter adapter tests.
- For manual UI verification, start the worker with `scripts/dev_worker.sh`, run the SwiftUI app, redact mixed-language text, inspect highlights and entity details, and verify the offline worker error remains understandable.
